import json
import os
import random
import sys
import pytest


if __name__ == '__main__':
    length = len(sys.argv)
    if length == 1:
        pytest.main(['--alluredir', './report', '--clean-alluredir'])
    else:
        models = sys.argv[1]
        for item in sys.argv[2:]:
            models += ' or ' + item
        pytest.main(['--alluredir', './report', '-m', models, '--clean-alluredir'])
    # pytest.main(['--alluredir', './report', '-m', "es and L0", '--clean-alluredir'])
    os.system('allure generate ./report -o ./report/html --clean')
