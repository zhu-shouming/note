import datetime
import pytest
import os
import yaml
from elasticsearch import Elasticsearch
from elasticsearch import helpers

from resource.utils.user import PAASLogin
from scripts.apis.handler_mqs import *
from scripts.es.handler_es import *

cur_path = os.path.dirname(os.path.realpath(__file__))
datafile = os.path.join(cur_path, 'data_admin.yaml')

with open(datafile, encoding='utf-8') as f:
    data_file = yaml.safe_load(f)

SERVICE_NAME = "elasticsearch"


@pytest.mark.es
@allure.feature("分析搜索引擎ElasticSearch")
@allure.story("分析搜索引擎ElasticSearch")
class TestEs:

    """ 初始化：创建ES集群 """
    def setup_class(self):
        paas_admin_login = PAASClient(PAASLogin(settings.USERNAME, settings.PASSWORD, settings.HOST, settings.PORT))
        cluster_name = "auto" + get_random_string(5, char_type=0).lower()
        label_name = settings['LABEL_NAME']
        net_name = settings['NET_NAME']
        kp_name = settings['KP_ADMIN_NAME']
        flavor = settings['ES_FLAVOR']
        es_nodes = int(settings['ES_NODES'])
        es_version = settings['ES_VERSION']
        es_pwd = settings['PASSWORD']
        create_es_vm_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor, es_pwd, es_nodes,
                             es_version)
        with allure.step("2.检查集群状态"):  # 等待30min
            temp = 180
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                cluster_info = get_cluster_by_name(paas_admin_login, SERVICE_NAME, cluster_name)
                assert cluster_name, f"未找到ES集群：{cluster_name}"
                if cluster_info['status'] == "ACTIVE":
                    break
                cnt += 1
            if cnt > temp:
                raise Exception("创建ES集群超时")
        self.es_name = cluster_name

    """ 清理：ES集群 """
    def teardown_class(self):
        paas_admin_login = PAASClient(PAASLogin(settings.USERNAME, settings.PASSWORD, settings.HOST, settings.PORT))
        delete_cluster(paas_admin_login, SERVICE_NAME, self.es_name)

    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_create_single_es'])
    def test_create_single_es(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("1.创建ES单机"):
            cluster_name = "auto" + get_random_string(5, char_type=0).lower()
            label_name = settings['LABEL_NAME']
            net_name = settings['NET_NAME']
            kp_name = settings['KP_ADMIN_NAME']
            flavor = settings['ES_FLAVOR']
            es_nodes = int(args['es_nodes'])
            es_version = args['es_version']
            es_pwd = args['es_pwd']
            create_es_vm_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor, es_pwd, es_nodes,
                                 es_version)
        with allure.step("2.检查集群状态"):       # 等待10min
            temp = 180
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                cluster_info = get_cluster_by_name(paas_admin_login, SERVICE_NAME, cluster_name)
                if cluster_info['status'] == "ACTIVE":
                    break
                cnt += 1
            if cnt > temp:
                raise Exception("创建ES单机超时")
        with allure.step("TEARDOWN: 删除ES单机"):
            delete_cluster(paas_admin_login, SERVICE_NAME, cluster_name)

    @pytest.mark.skip(reason="初始化中已有创建ES集群")
    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_create_multiple_es_cluster'])
    def test_create_multiple_es_cluster(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("1.创建ES集群"):
            cluster_name = "auto" + get_random_string(5, char_type=0).lower()
            label_name = settings['LABEL_NAME']
            net_name = settings['NET_NAME']
            kp_name = settings['KP_ADMIN_NAME']
            flavor = settings['ES_FLAVOR']
            es_nodes = int(args['es_nodes'])
            es_version = args['es_version']
            es_pwd = args['es_pwd']
            create_es_vm_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor, es_pwd,
                                 es_nodes, es_version)
        with allure.step("2.检查集群状态"):  # 等待10min
            temp = 180
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                cluster_info = get_cluster_by_name(paas_admin_login, SERVICE_NAME, cluster_name)
                assert cluster_name, f"未找到ES集群：{cluster_name}"
                if cluster_info['status'] == "ACTIVE":
                    break
                cnt += 1
            if cnt > temp:
                raise Exception("创建ES集群超时")
        with allure.step("TEARDOWN: 删除ES集群"):
            delete_cluster(paas_admin_login, SERVICE_NAME, cluster_name)

    @pytest.mark.L5
    @allure.description("创建/删除INDEX")
    def test_create_index(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 创建INDEX")
        with allure.step("1. 创建INDEX"):
            index_name = "auto" + get_random_string(5, char_type=0).lower()
            replicas = 1
            shards = 1
            create_es_index(paas_admin_login, SERVICE_NAME, self.es_name, index_name, replicas, shards)
        with allure.step("2. 页面确认INDEX创建成功"):
            temp = 30
            cnt = 1
            while cnt <= temp:
                index_info = get_es_index_by_name(paas_admin_login, SERVICE_NAME, self.es_name, index_name)
                assert index_info, f"未找到INDEX：{index_name}"
                act_health = index_info['health']
                act_status = index_info['status']
                if (act_health == "green") and (act_status == "open"):
                    break
                time.sleep(6)
                cnt += 1
            if cnt > temp:
                raise Exception(f"创建INDEX后状态超时")
            act_replicas = index_info['pri']
            act_shards = index_info['rep']
            act_health = index_info['health']
            assert act_replicas == str(replicas), f"分片数量不匹配。实际：{act_replicas}，期望：{str(replicas)}"
            assert act_shards == str(shards), f"副本数量不匹配。实际：{act_shards}，期望：{str(shards)}"
            assert act_health == "green", f"索引健康状态不正确。实际：{act_health}，期望：green"
        with allure.step("3. 后台确认INDEX创建成功，分区数正确"):
            es_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.es_name)
            es_vip = es_info['data']['realIp']
            config_info = get_cluster_config_detail(paas_admin_login, SERVICE_NAME, self.es_name,
                                                    config_name="http.port", service=SERVICE_NAME.upper())
            es_http_port = config_info['value']
            es_client = Elasticsearch(["http://" + es_vip + ":" + es_http_port],
                                      http_auth=('elastic', settings['PASSWORD']))
            assert es_client.indices.exists(index_name), f"后台未找到索引：{index_name}"
            bak_index = es_client.indices.get(index_name)
            act_replicas = bak_index[index_name]['settings']['index']['number_of_replicas']
            act_shards = bak_index[index_name]['settings']['index']['number_of_shards']
            assert act_replicas == str(replicas), f"分片数量不匹配。实际：{act_replicas}，期望：{str(replicas)}"
            assert act_shards == str(shards), f"分片数量不匹配。实际：{act_replicas}，期望：{str(shards)}"
        with allure.step("TEARDOWN: 删除INDEX"):
            delete_es_index(paas_admin_login, SERVICE_NAME, self.es_name, [index_name])

    @pytest.mark.L5
    @allure.description("批量删除INDEX")
    def test_patch_delete_indexes(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 批量删除INDEX")
        with allure.step("SETUP: 创建INDEX"):
            index_names = []
            count = random.randint(1, 5)
            for i in range(1, count + 1):
                index_name = "auto" + get_random_string(5, char_type=0).lower()
                create_es_index(paas_admin_login, SERVICE_NAME, self.es_name, index_name, replicas=1, shards=1)
                temp = 30
                cnt = 1
                while cnt <= temp:
                    index_info = get_es_index_by_name(paas_admin_login, SERVICE_NAME, self.es_name, index_name)
                    assert index_info, f"未找到INDEX：{index_name}"
                    act_health = index_info['health']
                    act_status = index_info['status']
                    if (act_health == "green") and (act_status == "open"):
                        break
                    time.sleep(6)
                    cnt += 1
                if cnt > temp:
                    raise Exception(f"创建INDEX后状态超时")
                index_names.append(index_name)
        with allure.step("批量删除INDEX"):
            delete_es_index(paas_admin_login, SERVICE_NAME, self.es_name, index_names)

    @pytest.mark.L5
    @allure.description("关闭/开启INDEX")
    def test_action_index(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 关闭/开启INDEX")
        with allure.step("SETUP：创建INDEX"):
            index_name = "auto" + get_random_string(5, char_type=0).lower()
            replicas = 1
            shards = 1
            create_es_index(paas_admin_login, SERVICE_NAME, self.es_name, index_name, replicas, shards)
            temp = 30
            cnt = 1
            while cnt <= temp:
                index_info = get_es_index_by_name(paas_admin_login, SERVICE_NAME, self.es_name, index_name)
                assert index_info, f"未找到INDEX：{index_name}"
                act_health = index_info['health']
                act_status = index_info['status']
                if (act_health == "green") and (act_status == "open"):
                    break
                time.sleep(6)
                cnt += 1
            if cnt > temp:
                raise Exception(f"创建INDEX后状态超时")
            es_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.es_name)
            es_vip = es_info['data']['realIp']
            config_info = get_cluster_config_detail(paas_admin_login, SERVICE_NAME, self.es_name,
                                                    config_name="http.port", service=SERVICE_NAME.upper())
            es_http_port = config_info['value']
            es_client = Elasticsearch(["http://" + es_vip + ":" + es_http_port],
                                      http_auth=('elastic', settings['PASSWORD']))
            assert es_client.indices.exists(index_name), f"后台未找到索引：{index_name}"
        with allure.step("1: 关闭INDEX"):
            close_es_index(paas_admin_login, SERVICE_NAME, self.es_name, [index_name])
            try:
                result = es_client.search(index=index_name)
                assert len(result['hits']['hits']) > 0, "查询INDEX失败"
            except Exception as e:
                assert 'index_closed_exception' in e.args, f"{print(e)}"
        with allure.step("2: 开启INDEX"):
            open_es_index(paas_admin_login, SERVICE_NAME, self.es_name, [index_name])
            try:
                result = es_client.search(index=index_name)
                assert len(result['hits']['hits']) == 0, "查询INDEX失败"
            except Exception as e:
                assert 'index_closed_exception' in e.args, f"{print(e)}"
        with allure.step("删除INDEX"):
            delete_es_index(paas_admin_login, SERVICE_NAME, self.es_name, [index_name])

    @pytest.mark.L5
    @allure.description("增删改查")
    def test_ciud_data(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 增删改查")
        with allure.step("SETUP: 创建INDEX"):
            index_name = "auto" + get_random_string(5, char_type=0).lower()
            replicas = 1
            shards = 1
            create_es_index(paas_admin_login, SERVICE_NAME, self.es_name, index_name, replicas, shards)
            temp = 30
            cnt = 1
            while cnt <= temp:
                index_info = get_es_index_by_name(paas_admin_login, SERVICE_NAME, self.es_name, index_name)
                assert index_info, f"未找到INDEX：{index_name}"
                act_health = index_info['health']
                act_status = index_info['status']
                if (act_health == "green") and (act_status == "open"):
                    break
                time.sleep(6)
                cnt += 1
            if cnt > temp:
                raise Exception(f"创建INDEX后状态超时")
            es_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.es_name)
            es_vip = es_info['data']['realIp']
            config_info = get_cluster_config_detail(paas_admin_login, SERVICE_NAME, self.es_name,
                                                    config_name="http.port", service=SERVICE_NAME.upper())
            es_http_port = config_info['value']
            es_client = Elasticsearch(["http://" + es_vip + ":" + es_http_port],
                                      http_auth=('elastic', settings['PASSWORD']))
            assert es_client.indices.exists(index_name), f"后台未找到索引：{index_name}"
        with allure.step("1.写入数据"):
            count = random.randint(1, 11)
            for i in range(1, count + 1):
                data = {
                    "key": "k" + str(i),
                    "value": i
                }

                es_client.index(index=index_name, doc_type='json', body=data)
            # 后台确认数据写入正确
            temp = 30
            cnt = 1
            while cnt < temp:
                time.sleep(6)
                index_info = es_client.search(index=index_name)
                act_docs_count = len(index_info['hits']['hits'])
                if act_docs_count == count:
                    break
                cnt += 1
            if cnt > temp:
                raise Exception(f"写入数据超时。实际：{act_docs_count}，期望：{count}")
            with allure.step("页面确认数据写入量正确"):
                temp = 30
                cnt = 1
                while cnt < temp:
                    time.sleep(6)
                    index_info = get_es_index_by_name(paas_admin_login, SERVICE_NAME, self.es_name, index_name)
                    assert index_info, f"未找到INDEX：{index_name}"
                    act_docs_count = index_info['docs.count']
                    if int(act_docs_count) == count:
                        break
                    cnt += 1
                if cnt > temp:
                    raise Exception(f"写入数据超时。实际：{act_docs_count}，期望：{count}")
        with allure.step("2.查询数据"):
            body = {
                'query': {
                    'prefix': {
                        'key.keyword': 'k'
                    }
                },

                'size': 10
            }
            filter_path = ['hits.hits._source.key',
                           'hits.hits._source.value']
            result = es_client.search(index=index_name, filter_path=filter_path, body=body)
            assert result != {}, \
                f"未找到指定的数据。实际：{es_client.search(index=index_name, filter_path=filter_path)}"
        with allure.step("3.修改数据"):
            count = 3
            num = int(count / 2)
            body = {
                'query': {
                    'term': {
                        'key.keyword': 'k' + str(num)
                    }
                }
            }

            old_data = es_client.search(index=index_name, body=body)
            assert len(old_data['hits']['hits']) > 0, f"未找到指定的数据。实际：{es_client.search(index=index_name)}"
            doc_id = old_data['hits']['hits'][0]['_id']
            old_value = old_data['hits']['hits'][0]['_source']['value']
            new_value = int(old_value * 2)
            new_body = {
                'doc': {
                    'key': 'k' + str(num),
                    'value': new_value
                }
            }

            # 更新数据
            es_client.update(index=index_name, doc_type='json', id=doc_id, body=new_body)

            temp = 30
            cnt = 1
            while cnt < temp:
                time.sleep(6)
                new_data = es_client.search(index=index_name, body=body)
                act_value = new_data['hits']['hits'][0]['_source']['value']
                if act_value == new_value:
                    break
                cnt += 1
            if cnt > temp:
                raise Exception(f"更新数据超时。实际：{act_value}，期望：{new_value}")
        with allure.step("4.删除数据"):
            all_data = es_client.search(index=index_name)
            hits = all_data['hits']['hits']
            for item in hits:
                es_client.delete(index=index_name, doc_type='json', id=item['_id'])
            with allure.step("页面确认删除数据正确"):
                temp = 30
                cnt = 1
                while cnt < temp:
                    time.sleep(6)
                    result = es_client.search(index=index_name)
                    if len(result['hits']['hits']) == 0:
                        index_info = get_es_index_by_name(paas_admin_login, SERVICE_NAME, self.es_name, index_name)
                        assert index_info, f"未找到INDEX：{index_name}"
                        act_docs_count = index_info['docs.count']
                        assert act_docs_count == str(0), "删除数据失败"
                        break
                    cnt += 1
                if cnt > temp:
                    raise Exception("删除INDEX中的数据超时")
        with allure.step("TEARDOWN: 删除INDEX"):
            delete_es_index(paas_admin_login, SERVICE_NAME, self.es_name, [index_name])

    @pytest.mark.L5
    @allure.description("批量增删改查")
    def test_patch_ciud_index(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 批量增删改查")
        with allure.step("SETUP: 创建INDEX"):
            index_name = "auto" + get_random_string(5, char_type=0).lower()
            replicas = 1
            shards = 1
            create_es_index(paas_admin_login, SERVICE_NAME, self.es_name, index_name, replicas, shards)
            temp = 30
            cnt = 1
            while cnt <= temp:
                index_info = get_es_index_by_name(paas_admin_login, SERVICE_NAME, self.es_name, index_name)
                assert index_info, f"未找到INDEX：{index_name}"
                act_health = index_info['health']
                act_status = index_info['status']
                if (act_health == "green") and (act_status == "open"):
                    break
                time.sleep(6)
                cnt += 1
            if cnt > temp:
                raise Exception(f"创建INDEX后状态超时")
            es_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.es_name)
            es_vip = es_info['data']['realIp']
            config_info = get_cluster_config_detail(paas_admin_login, SERVICE_NAME, self.es_name,
                                                    config_name="http.port", service=SERVICE_NAME.upper())
            es_http_port = config_info['value']
            es_client = Elasticsearch(["http://" + es_vip + ":" + es_http_port],
                                      http_auth=('elastic', settings['PASSWORD']))
            assert es_client.indices.exists(index_name), f"后台未找到索引：{index_name}"
        with allure.step("1.批量写入数据"):
            data_list = []
            num = 100
            for i in range(num):
                body = {
                    '_op_type': 'create',
                    '_index': index_name,
                    '_type': 'doc',
                    '_id': str(i),
                    '_source': {'key': 'k' + str(i), 'value': i}
                }
                data_list.append(body)
            result = helpers.bulk(es_client, data_list)
            assert num in result, f"批量插入数据不正确。实际：{result}, 期望：{num}"
        with allure.step("2.批量更新数据"):
            data_list = []
            num = 100
            for i in range(num):
                body = {
                    '_op_type': 'index',
                    '_index': index_name,
                    '_type': 'doc',
                    '_id': str(i),
                    '_source': {'key': 'k' + str(i), 'value': int(i*2)}
                }
                data_list.append(body)
            result = helpers.bulk(es_client, data_list)
            assert num in result, f"批量更新数据不正确。实际：{result}, 期望：{num}"
        with allure.step("3.另一种批量更新数据"):
            data_list = []
            num = 100
            for i in range(num):
                body = {
                    '_op_type': 'update',
                    '_index': index_name,
                    '_type': 'doc',
                    '_id': str(i),
                    'doc': {'key': 'kk' + str(i), 'value': i+1}
                }
                data_list.append(body)
            result = helpers.bulk(es_client, data_list)
            assert num in result, f"另一种批量更新数据不正确。实际：{result}, 期望：{num}"
        with allure.step("4.批量删除数据"):
            data_list = []
            num = 100
            for i in range(num):
                body = {
                    '_op_type': 'delete',
                    '_index': index_name,
                    '_type': 'doc',
                    '_id': str(i)
                }
                data_list.append(body)
            result = helpers.bulk(es_client, data_list)
            assert num in result, f"批量删除数据不正确。实际：{result}, 期望：{num}"
        with allure.step("TEARDOWN: 删除INDEX"):
            delete_es_index(paas_admin_login, SERVICE_NAME, self.es_name, [index_name])

    @pytest.mark.L5
    @allure.description("运行日志收集")
    def test_download_es_server_log(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- ES运行日志收集")
        begin_date = (datetime.datetime.now() - datetime.timedelta(hours=24)).strftime('%Y-%m-%d')
        end_date = datetime.datetime.now().strftime('%Y-%m-%d')
        collect_server_log(paas_admin_login, SERVICE_NAME, begin_date, end_date)

    @pytest.mark.L5
    @allure.description("集群日志收集")
    def test_download_es_cluster_log(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- ES集群日志收集")
        collect_cluster_log(paas_admin_login, SERVICE_NAME, self.es_name)

    @pytest.mark.L5
    @allure.description("主机扩容")
    def test_scale_es(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- ES主机扩容")
        with allure.step("1. 原有节点数量"):
            cluster_info = get_cluster_by_name(paas_admin_login, SERVICE_NAME, self.es_name)
            assert cluster_info, f"未找到：{self.es_name}"
            origin_node_count = cluster_info['nodeCount']
        with allure.step("2.主机扩容"):
            step_node_count = 1
            scale_es_cluster(paas_admin_login, SERVICE_NAME, self.es_name, step_node_count)
            temp = 180
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                cluster_info = get_cluster_by_name(paas_admin_login, SERVICE_NAME, self.es_name)
                if cluster_info['status'] == "ACTIVE":
                    break
                cnt = cnt + 1
            if cnt > temp:
                raise Exception("主机扩容超时")
        with allure.step("3.校验扩容结果"):
            cluster_info = get_cluster_by_name(paas_admin_login, SERVICE_NAME, self.es_name)
            new_node_count = cluster_info['nodeCount']
            assert (origin_node_count + step_node_count) == new_node_count, \
                f"扩容失败。实际节点数量：{new_node_count}, 期望：{origin_node_count}"

    @pytest.mark.L5
    @allure.description("更改ES配置")
    def test_update_config(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 修改配置文件中http.port")
        with allure.step("1. 查询默认端口"):
            config_info = get_cluster_config_detail(paas_admin_login, SERVICE_NAME, self.es_name,
                                                    config_name="http.port", service=SERVICE_NAME.upper())
            origin_es_http_port = config_info['value']
        with allure.step("2. 修改端口"):
            for i in range(3):
                new_es_http_port = str(random.randint(9201, 9300))
                if new_es_http_port != origin_es_http_port:
                    break
            update_es_config(paas_admin_login, SERVICE_NAME, self.es_name, http_port=new_es_http_port)
        with allure.step("3. 重启集群"):
            restart_es_cluster(paas_admin_login, SERVICE_NAME, self.es_name)
        with allure.step("4. 确认端口已修改"):
            config_info = get_cluster_config_detail(paas_admin_login, SERVICE_NAME, self.es_name,
                                                    config_name="http.port", service=SERVICE_NAME.upper())
            current_es_http_port = config_info['value']
            assert current_es_http_port == new_es_http_port, \
                f"端口修改失败。实际：{current_es_http_port}，期望：{new_es_http_port}"
        with allure.step("5. 后台连接测试"):
            es_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.es_name)
            es_vip = es_info['data']['realIp']
            temp = 10
            cnt = 1
            while cnt < temp:
                time.sleep(6)
                conn = Elasticsearch(["http://" + es_vip + ":" + new_es_http_port],
                                     http_auth=('elastic', settings['PASSWORD'])).ping()
                if conn:
                    break
                cnt += 1
            if cnt > temp:
                raise Exception("集群未启动")
        with allure.step("TEARDOWN:"):
            with allure.step("1. 恢复端口"):
                update_es_config(paas_admin_login, SERVICE_NAME, self.es_name, http_port=origin_es_http_port)
            with allure.step("2. 重启集群"):
                restart_es_cluster(paas_admin_login, SERVICE_NAME, self.es_name)
            with allure.step("3. 确认端口已修改"):
                config_info = get_cluster_config_detail(paas_admin_login, SERVICE_NAME, self.es_name,
                                                        config_name="http.port", service=SERVICE_NAME.upper())
                current_es_http_port = config_info['value']
                assert current_es_http_port == origin_es_http_port, \
                    f"端口修改失败。实际：{current_es_http_port}，期望：{origin_es_http_port}"
            with allure.step("4. 后台连接测试"):
                temp = 10
                cnt = 1
                while cnt < temp:
                    time.sleep(6)
                    conn = Elasticsearch(["http://" + es_vip + ":" + new_es_http_port],
                                         http_auth=('elastic', settings['PASSWORD'])).ping()
                    if conn:
                        break
                    cnt += 1
                if cnt > temp:
                    raise Exception("集群未启动")

    @pytest.mark.L5
    @allure.description("ES组件关闭/开启/重启")
    def test_action_components(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- ES组件关闭/开启/重启")
        es_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.es_name)
        es_vip = es_info['data']['realIp']
        config_info = get_cluster_config_detail(paas_admin_login, SERVICE_NAME, self.es_name,
                                                config_name="http.port", service=SERVICE_NAME.upper())
        es_http_port = config_info['value']
        with allure.step("1.关闭组件"):
            stop_es_components(paas_admin_login, SERVICE_NAME, self.es_name)
            temp = 10
            cnt = 1
            while cnt < temp:
                time.sleep(6)
                conn = Elasticsearch(["http://" + es_vip + ":" + es_http_port],
                                     http_auth=('elastic', settings['PASSWORD'])).ping()
                if not conn:
                    break
                cnt += 1
            if cnt > temp:
                raise Exception("集群停止超时")
        with allure.step("2.开启组件"):
            start_es_components(paas_admin_login, SERVICE_NAME, self.es_name)
            temp = 10
            cnt = 1
            while cnt < temp:
                time.sleep(6)
                conn = Elasticsearch(["http://" + es_vip + ":" + es_http_port],
                                     http_auth=('elastic', settings['PASSWORD'])).ping()
                if conn:
                    break
                cnt += 1
            if cnt > temp:
                raise Exception("集群启动超时")
        with allure.step("3.重启组件"):
            restart_es_cluster(paas_admin_login, SERVICE_NAME, self.es_name)
            temp = 10
            cnt = 1
            while cnt < temp:
                time.sleep(6)
                conn = Elasticsearch(["http://" + es_vip + ":" + es_http_port],
                                     http_auth=('elastic', settings['PASSWORD'])).ping()
                if conn:
                    break
                cnt += 1
            if cnt > temp:
                raise Exception("集群启动超时")
