from resource.base.rest_api_base import RestAPIBase
from urllib.parse import urlencode


class EsAPI(RestAPIBase):

    def create_es_cluster(self, cluster_name, zone_info, network_info, keypair_name, flavor_info, image_id, es_pwd,
                          es_nodes, es_version, monitor_on=1, monitor_interval="15s", **kwargs):

        """
        创建elasticsearch虚拟机集群

        :param cluster_name: 集群名称
        :param zone_info: 可用域信息
        :param network_info: 网络信息
        :param keypair_name: 密钥对名称
        :param flavor_info: 规格信息
        :param image_id: 镜像ID
        :param es_pwd: es密码
        :param es_nodes: es节点数
        :param es_version: es版本
        :param monitor_on: 是否开启监控。1（是）/0（否）
        :param monitor_interval: 监控间隔
        :param kwargs:
        :return:

        """

        uri = "/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster"

        data = {
            "type": "elasticsearch",
            "name": cluster_name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": "admin@123",
            "description": kwargs['description'] if 'description' in kwargs.keys() else "",
            "whether_ha": True if (es_nodes > 1) else False,
            "availability_zone": {
                "id": zone_info['id'],
                "name": zone_info['zone_name'],
                "virtType": zone_info['virt_type'],
            },
            "neutron_management_network_id": network_info['id'],
            "keypair_name": keypair_name,
            "anti_affinity": kwargs['anti_affinity'] if 'anti_affinity' in kwargs.keys() else False,
            "service": [
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"]
                }
            ],
            "monitor_interval": monitor_interval,
            "monitor_on": monitor_on,
            "master": {
                "size": 2 if (es_nodes > 1) else 1,
                "flavor_id": ""
            },
            "core": {
                "size": (es_nodes - 2) if (es_nodes > 1) else 0,
                "flavor_id": ""
            },
            "task": {"size": "0"},
            "elasticsearch": {"size": "0"},
            "instanceInfo": [
                {
                    "roleNameList": ["master-1"],
                    "title": "数据节点",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": ""
                }
            ],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "manager_virtual_ip": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "neutron_management_network_name": network_info['name'],
            "elasticsearch_master": [],
            "elasticsearch_data": ["master-1"],
            "elasticsearch_client": [],
            "imageId": image_id,
            "version": {
                "ELASTICSEARCH": es_version
            },
            "elastic_password": es_pwd
        }

        service_sub1 = {
            "display": True,
            "component": "ELASTICSEARCH",
            "relation": "",
            "host_roles_default": ["master"],
            "optional_host_roles": [],
            "hosts": ["master-1"],
            "service": "ELASTICSEARCH"
        }

        service_sub2 = {
            "component": "AMBARI_SLAVE",
            "display": False,
            "service": "AMBARI",
            "relation": "",
            "host_roles_default": ["master"],
            "hosts": ["master-2"]
        }

        instance_subs = {
            "roleNameList": [],
            "title": "数据节点",
            "azoneId": zone_info['id'],
            "labelName": zone_info['label_name'],
            "azoneName": zone_info['zone_name'],
            "virtType": zone_info['virt_type'],
            "flavorId": flavor_info['id'],
            "name": flavor_info['name'],
            "storageTypeId": None,
            "fixIp": "",
            "fixManagementIp": "",
        }

        if es_nodes > 1:
            service_sub1['host_roles_default'].append("core")
            service_sub1['hosts'].append("master-2")
            instance_sub1 = instance_subs
            instance_sub1['roleNameList'].append("master-2")
            data['instanceInfo'].append(instance_sub1)
            data['elasticsearch_data'].append("master-2")

            for i in range(1, es_nodes - 1):
                service_sub1['hosts'].append("core-" + str(i))
                instance_sub2 = instance_subs
                instance_sub2['roleNameList'].append("core-" + str(i))
                data['instanceInfo'].append(instance_sub2)
                data['elasticsearch_data'].append("core-" + str(i))

            data['service'].append(service_sub1)
            data['service'].append(service_sub2)
        else:
            data['service'].append(service_sub1)

        headers = self.ss.headers
        headers['servicename'] = 'elasticsearch'
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def apply_for_create_es_cluster(self, cluster_name, zone_info, network_info, keypair_name, flavor_info, image_id,
                                    es_pwd, es_nodes, es_version, monitor_on=1, monitor_interval="15s", **kwargs):

        """
        申请创建elasticsearch虚拟机集群

        :param cluster_name: 集群名称
        :param zone_info: 可用域信息
        :param network_info: 网络信息
        :param keypair_name: 密钥对名称
        :param flavor_info: 规格信息
        :param image_id: 镜像ID
        :param es_pwd: es密码
        :param es_nodes: es节点数
        :param es_version: es版本
        :param monitor_on: 是否开启监控。1（是）/0（否）
        :param monitor_interval: 监控间隔
        :param kwargs:
        :return:

        """

        uri = "/api/mqs/app/v1.0/cluster/deployment/v1/deployment/cluster/iaas/process"

        data = {
            "type": "elasticsearch",
            "name": cluster_name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": "admin@123",
            "description": kwargs['description'] if 'description' in kwargs.keys() else "",
            "whether_ha": True if (es_nodes > 1) else False,
            "availability_zone": {
                "id": zone_info['id'],
                "name": zone_info['zone_name'],
                "virtType": zone_info['virt_type'],
            },
            "neutron_management_network_id": network_info['id'],
            "keypair_name": keypair_name,
            "anti_affinity": kwargs['anti_affinity'] if 'anti_affinity' in kwargs.keys() else False,
            "service": [
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"]
                }
            ],
            "monitor_interval": monitor_interval,
            "monitor_on": monitor_on,
            "master": {
                "size": 2 if (es_nodes > 1) else 1,
                "flavor_id": ""
            },
            "core": {
                "size": (es_nodes - 2) if (es_nodes > 1) else 0,
                "flavor_id": ""
            },
            "task": {"size": "0"},
            "elasticsearch": {"size": "0"},
            "instanceInfo": [
                {
                    "roleNameList": ["master-1"],
                    "title": "数据节点",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": ""
                }
            ],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "manager_virtual_ip": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "neutron_management_network_name": network_info['name'],
            "elasticsearch_master": [],
            "elasticsearch_data": ["master-1"],
            "elasticsearch_client": [],
            "imageId": image_id,
            "version": {
                "ELASTICSEARCH": es_version
            },
            "elastic_password": es_pwd
        }

        service_sub1 = {
            "display": True,
            "component": "ELASTICSEARCH",
            "relation": "",
            "host_roles_default": ["master"],
            "optional_host_roles": [],
            "hosts": ["master-1"],
            "service": "ELASTICSEARCH"
        }

        service_sub2 = {
            "component": "AMBARI_SLAVE",
            "display": False,
            "service": "AMBARI",
            "relation": "",
            "host_roles_default": ["master"],
            "hosts": ["master-2"]
        }

        instance_subs = {
            "roleNameList": [],
            "title": "数据节点",
            "azoneId": zone_info['id'],
            "labelName": zone_info['label_name'],
            "azoneName": zone_info['zone_name'],
            "virtType": zone_info['virt_type'],
            "flavorId": flavor_info['id'],
            "name": flavor_info['name'],
            "storageTypeId": None,
            "fixIp": "",
            "fixManagementIp": "",
        }

        if es_nodes > 1:
            service_sub1['host_roles_default'].append("core")
            service_sub1['hosts'].append("master-2")
            instance_sub1 = instance_subs
            instance_sub1['roleNameList'].append("master-2")
            data['instanceInfo'].append(instance_sub1)
            data['elasticsearch_data'].append("master-2")

            for i in range(1, es_nodes - 1):
                service_sub1['hosts'].append("core-" + str(i))
                instance_sub2 = instance_subs
                instance_sub2['roleNameList'].append("core-" + str(i))
                data['instanceInfo'].append(instance_sub2)
                data['elasticsearch_data'].append("core-" + str(i))

            data['service'].append(service_sub1)
            data['service'].append(service_sub2)
        else:
            data['service'].append(service_sub1)

        headers = self.ss.headers
        headers['servicename'] = 'elasticsearch'
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def scale_es_cluster(self, servicename, cluster_id, cluster_name, zone_info, network_info, flavor_info, node_count,
                         **kwargs):
        """
        es主机扩容

        :param servicename: 服务名称 比如：zookeeper  rabbitmq
        :param cluster_id: 集群ID
        :param cluster_name: 集群名称
        :param zone_info: 可用域信息
        :param network_info: 网络信息
        :param flavor_info: 规格信息
        :param node_count: kafka扩容节点个数
        :param kwargs
        :return:

        """

        uri = f"/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster/{cluster_id}"

        data = {
            "expand": True,
            "node_count": node_count,
            "cluster_name": cluster_name,
            "flavor_id": flavor_info['id'],
            "storageTypeId": None,
            "node_processes": ["ELASTICSEARCH"],
            "instanceInfo": [],
            "clusterData": [],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "neutron_management_network_id": network_info['id'],
            "neutron_management_network_name": network_info['name'],
            "managerNetwork": network_info['id'],
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "quota": 99,
            "quotaText": "可用999969750G / 全部1000000000G",
            "replicates": 1,
            "leader_count": 0,
            "extend_observer_count": 0
        }

        for i in range(node_count):
            sub_data = {
                "roleNameList": [],
                "title": "数据节点",
                "azoneId": zone_info['id'],
                "azoneName": zone_info['name'],
                "virtType": zone_info['virt_type'],
                "flavorId": flavor_info['id'],
                "storageTypeId": None,
                "onlyId": flavor_info['id'] + "_",
                "name": flavor_info['name'],
                "fixIp": "",
                "fixManagementIp": ""
            }
            sub_data['roleNameList'].append("extend-" + str(i + 1))
            data['instanceInfo'].append(sub_data)
            data['clusterData'].append(sub_data)

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def create_index(self, virtual_ip, index_name, replicas=1, shards=1):
        """
        创建索引

        :param virtual_ip: ES集群vip
        :param index_name: 索引名称
        :param replicas: 分片数量
        :param shards: 副本数量
        :return:

        """

        uri = "/api/mqs/app/v1.0/elasticsearch/manage/v1/elasticsearch/index"

        data = {
            "ip": virtual_ip,
            "name": index_name,
            "replicas": replicas,
            "shards": shards
        }

        headers = self.ss.headers
        headers['servicename'] = 'elasticsearch'
        response = self._put(uri=uri, data=data, headers=headers)
        return response

    def get_index_list(self, virtual_ip):
        """
         获取索引列表

         :param virtual_ip: ES集群vip
         :return:

         """

        uri = f"/api/mqs/app/v1.0/elasticsearch/manage/v1/elasticsearch/index?ip={virtual_ip}"

        headers = self.ss.headers
        headers['servicename'] = 'elasticsearch'
        response = self._get(uri=uri, headers=headers)
        return response

    def action_index(self, virtual_ip, index_names: list, action):
        """
        操作INDEX

        :param virtual_ip: ES集群vip
        :param index_names: INDEX列表
        :param action: 操作。例如：删除(delete)/ 关闭(close)/ 开启(open)
        :return:

        """

        uri = f"/api/mqs/app/v1.0/elasticsearch/manage/v1/elasticsearch/index?action={action}"

        data = {
            "ip": virtual_ip,
            "indexes": index_names
        }

        headers = self.ss.headers
        headers['servicename'] = 'elasticsearch'
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def update_es_config(self, servicename, es_name, es_node_names, **kwargs):
        """
        修改es配置

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param es_name: kafka名称
        :param es_node_names: es主机名
        :param kwargs:
        :return:
        """

        uri = f"/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{es_name}/update/configs"

        data = {
            "Clusters": {
                "desired_config": [
                    {
                        "type": "elasticsearch-config",
                        "properties": {
                            "action.destructive.requires.name": "true",
                            "bootstrap.memory.lock": "true",
                            "cluster.initial_master_nodes": es_node_names,
                            "cluster.name": "my_es_cluster",
                            "content": "\n##########################################################################\n##add other configs for Elasticsearch",
                            "discovery.seed_hosts": es_node_names,
                            "gateway.recover.after.nodes": "1",
                            "http.port": kwargs['http_port'] if 'http_port' in kwargs.keys() else "9200",
                            "node.attr.rack": "rack01",
                            "node.max.local.storage.nodes": "1",
                            "path.backup.logs": "/var/log/elasticsearch",
                            "path.data": "/var/lib/elasticsearch",
                            "path.logs": "/var/log/elasticsearch",
                            "superuser.password": "Passw0rd@_",
                            "transport.port": "9300"
                        },
                        "service_config_version_note": ""
                    },
                    {
                        "type": "elasticsearch-log4j",
                        "properties": {
                            "content": "\n# log action execution errors for easier debugging\nlogger.action.name = org.elasticsearch.action\n\nappender.console.type = Console\nappender.console.name = console\nappender.console.layout.type = PatternLayout\nappender.console.layout.pattern = [%d{ISO8601}][%-5p][%-25c{1.}] [%node_name]%marker %m%n\n\nappender.rolling.type = RollingFile\nappender.rolling.name = rolling\nappender.rolling.fileName = ${elasticsearch.log.dir}/${elasticsearch.log.file}.log\nappender.rolling.layout.type = PatternLayout\nappender.rolling.layout.pattern = %d{yyyy-MM-dd HH:mm:ss,SSS} %-5p %c{2} (%F:%M(%L)) - %m%n\nappender.rolling.filePattern = ${elasticsearch.log.bak.dir}/${elasticsearch.log.file}-%d{yyyy-MM-dd}-%i.log.gz\nappender.rolling.policies.type = Policies\nappender.rolling.policies.time.type = TimeBasedTriggeringPolicy\nappender.rolling.policies.time.interval = 1\nappender.rolling.policies.time.modulate = true\nappender.rolling.policies.size.type = SizeBasedTriggeringPolicy\nappender.rolling.policies.size.size = ${elasticsearch.log.maxfilesize}\nappender.rolling.strategy.type = DefaultRolloverStrategy\nappender.rolling.strategy.max = ${elasticsearch.log.maxbackup_oneday}\n\nappender.rolling.strategy.delete.type = Delete\nappender.rolling.strategy.delete.basePath = ${elasticsearch.log.bak.dir}\nappender.rolling.strategy.delete.maxDepth = 2\nappender.rolling.strategy.delete.iffile.type = IfFileName\nappender.rolling.strategy.delete.iffile.glob = *.gz\nappender.rolling.strategy.delete.iflastmodify.type = IfLastModified\nappender.rolling.strategy.delete.iflastmodify.age = ${elasticsearch.log.maxbackup_days}\n\nrootLogger.level = ${elasticsearch.log.level}\nrootLogger.appenderRef.console.ref = console\nrootLogger.appenderRef.rolling.ref = rolling\n\nappender.deprecation_rolling.type = RollingFile\nappender.deprecation_rolling.name = deprecation_rolling\nappender.deprecation_rolling.fileName = ${elasticsearch.log.dir}/${elasticsearch.log.file}_deprecation.log\nappender.deprecation_rolling.layout.type = PatternLayout\nappender.deprecation_rolling.layout.pattern = [%d{ISO8601}][%-5p][%-25c{1.}] [%node_name]%marker %.-10000m%n\nappender.deprecation_rolling.filePattern = ${elasticsearch.log.bak.dir}/${elasticsearch.log.file}_deprecation-%d{yyyy-MM-dd}-%i.log.gz\nappender.deprecation_rolling.policies.type = Policies\nappender.deprecation_rolling.policies.time.type = TimeBasedTriggeringPolicy\nappender.deprecation_rolling.policies.time.interval = 1\nappender.deprecation_rolling.policies.time.modulate = true\nappender.deprecation_rolling.policies.size.type = SizeBasedTriggeringPolicy\nappender.deprecation_rolling.policies.size.size = ${elasticsearch.log.maxfilesize}\nappender.deprecation_rolling.strategy.type = DefaultRolloverStrategy\nappender.deprecation_rolling.strategy.max = ${elasticsearch.log.maxbackup_oneday}\n\nappender.deprecation_rolling.strategy.delete.type = Delete\nappender.deprecation_rolling.strategy.delete.basePath = ${elasticsearch.log.bak.dir}\nappender.deprecation_rolling.strategy.delete.maxDepth = 2\nappender.deprecation_rolling.strategy.delete.iffile.type = IfFileName\nappender.deprecation_rolling.strategy.delete.iffile.glob = *.gz\nappender.deprecation_rolling.strategy.delete.iflastmodify.type = IfLastModified\nappender.deprecation_rolling.strategy.delete.iflastmodify.age = ${elasticsearch.log.maxbackup_days}\n\nlogger.deprecation.name = org.elasticsearch.deprecation\nlogger.deprecation.level = warn\nlogger.deprecation.appenderRef.deprecation_rolling.ref = deprecation_rolling\nlogger.deprecation.additivity = false\n\nappender.index_search_slowlog_rolling.type = RollingFile\nappender.index_search_slowlog_rolling.name = index_search_slowlog_rolling\nappender.index_search_slowlog_rolling.fileName = ${elasticsearch.log.dir}/${elasticsearch.log.file}_index_search_slowlog.log\nappender.index_search_slowlog_rolling.layout.type = PatternLayout\nappender.index_search_slowlog_rolling.layout.pattern = [%d{ISO8601}][%-5p][%-25c] [%node_name]%marker %.-10000m%n\nappender.index_search_slowlog_rolling.filePattern = ${elasticsearch.log.bak.dir}/${elasticsearch.log.file}_index_search_slowlog-%d{yyyy-MM-dd}-%i.log.gz\nappender.index_search_slowlog_rolling.policies.type = Policies\nappender.index_search_slowlog_rolling.policies.time.type = TimeBasedTriggeringPolicy\nappender.index_search_slowlog_rolling.policies.time.interval = 1\nappender.index_search_slowlog_rolling.policies.time.modulate = true\nappender.index_search_slowlog_rolling.policies.size.type = SizeBasedTriggeringPolicy\nappender.index_search_slowlog_rolling.policies.size.size = ${elasticsearch.log.maxfilesize}\nappender.index_search_slowlog_rolling.strategy.type = DefaultRolloverStrategy\nappender.index_search_slowlog_rolling.strategy.max = ${elasticsearch.log.maxbackup_oneday}\n\nappender.index_search_slowlog_rolling.strategy.delete.type = Delete\nappender.index_search_slowlog_rolling.strategy.delete.basePath = ${elasticsearch.log.bak.dir}\nappender.index_search_slowlog_rolling.strategy.delete.maxDepth = 2\nappender.index_search_slowlog_rolling.strategy.delete.iffile.type = IfFileName\nappender.index_search_slowlog_rolling.strategy.delete.iffile.glob = *.gz\nappender.index_search_slowlog_rolling.strategy.delete.iflastmodify.type = IfLastModified\nappender.index_search_slowlog_rolling.strategy.delete.iflastmodify.age = ${elasticsearch.log.maxbackup_days}\n\nlogger.index_search_slowlog_rolling.name = index.search.slowlog\nlogger.index_search_slowlog_rolling.level = trace\nlogger.index_search_slowlog_rolling.appenderRef.index_search_slowlog_rolling.ref = index_search_slowlog_rolling\nlogger.index_search_slowlog_rolling.additivity = false\n\nappender.index_indexing_slowlog_rolling.type = RollingFile\nappender.index_indexing_slowlog_rolling.name = index_indexing_slowlog_rolling\nappender.index_indexing_slowlog_rolling.fileName = ${elasticsearch.log.dir}/${elasticsearch.log.file}_index_indexing_slowlog.log\nappender.index_indexing_slowlog_rolling.layout.type = PatternLayout\nappender.index_indexing_slowlog_rolling.layout.pattern = [%d{ISO8601}][%-5p][%-25c] [%node_name]%marker %.-10000m%n\nappender.index_indexing_slowlog_rolling.filePattern = ${elasticsearch.log.bak.dir}/${elasticsearch.log.file}_index_indexing_slowlog-%d{yyyy-MM-dd}-%i.log.gz\nappender.index_indexing_slowlog_rolling.policies.type = Policies\nappender.index_indexing_slowlog_rolling.policies.time.type = TimeBasedTriggeringPolicy\nappender.index_indexing_slowlog_rolling.policies.time.interval = 1\nappender.index_indexing_slowlog_rolling.policies.time.modulate = true\nappender.index_indexing_slowlog_rolling.policies.size.type = SizeBasedTriggeringPolicy\nappender.index_indexing_slowlog_rolling.policies.size.size = ${elasticsearch.log.maxfilesize}\nappender.index_indexing_slowlog_rolling.strategy.type = DefaultRolloverStrategy\nappender.index_indexing_slowlog_rolling.strategy.max = ${elasticsearch.log.maxbackup_oneday}\n\nappender.index_indexing_slowlog_rolling.strategy.delete.type = Delete\nappender.index_indexing_slowlog_rolling.strategy.delete.basePath = ${elasticsearch.log.bak.dir}\nappender.index_indexing_slowlog_rolling.strategy.delete.maxDepth = 2\nappender.index_indexing_slowlog_rolling.strategy.delete.iffile.type = IfFileName\nappender.index_indexing_slowlog_rolling.strategy.delete.iffile.glob = *.gz\nappender.index_indexing_slowlog_rolling.strategy.delete.iflastmodify.type = IfLastModified\nappender.index_indexing_slowlog_rolling.strategy.delete.iflastmodify.age = ${elasticsearch.log.maxbackup_days}\n\nlogger.index_indexing_slowlog.name = index.indexing.slowlog.index\nlogger.index_indexing_slowlog.level = trace\nlogger.index_indexing_slowlog.appenderRef.index_indexing_slowlog_rolling.ref = index_indexing_slowlog_rolling\nlogger.index_indexing_slowlog.additivity = false\n\n\nappender.audit_rolling.type = RollingFile\nappender.audit_rolling.name = audit_rolling\nappender.audit_rolling.fileName = ${elasticsearch.log.dir}/${elasticsearch.log.file}_audit.log\nappender.audit_rolling.layout.type = PatternLayout\nappender.audit_rolling.layout.pattern = {\\\n        \"@timestamp\":\"%d{ISO8601}\"\\\n        %varsNotEmpty{, \"node.name\":\"%enc{%map{node.name}}{JSON}\"}\\\n        %varsNotEmpty{, \"node.id\":\"%enc{%map{node.id}}{JSON}\"}\\\n        %varsNotEmpty{, \"host.name\":\"%enc{%map{host.name}}{JSON}\"}\\\n        %varsNotEmpty{, \"host.ip\":\"%enc{%map{host.ip}}{JSON}\"}\\\n        %varsNotEmpty{, \"event.type\":\"%enc{%map{event.type}}{JSON}\"}\\\n        %varsNotEmpty{, \"event.action\":\"%enc{%map{event.action}}{JSON}\"}\\\n        %varsNotEmpty{, \"user.name\":\"%enc{%map{user.name}}{JSON}\"}\\\n        %varsNotEmpty{, \"user.run_by.name\":\"%enc{%map{user.run_by.name}}{JSON}\"}\\\n        %varsNotEmpty{, \"user.run_as.name\":\"%enc{%map{user.run_as.name}}{JSON}\"}\\\n        %varsNotEmpty{, \"user.realm\":\"%enc{%map{user.realm}}{JSON}\"}\\\n        %varsNotEmpty{, \"user.run_by.realm\":\"%enc{%map{user.run_by.realm}}{JSON}\"}\\\n        %varsNotEmpty{, \"user.run_as.realm\":\"%enc{%map{user.run_as.realm}}{JSON}\"}\\\n        %varsNotEmpty{, \"user.roles\":%map{user.roles}}\\\n        %varsNotEmpty{, \"origin.type\":\"%enc{%map{origin.type}}{JSON}\"}\\\n        %varsNotEmpty{, \"origin.address\":\"%enc{%map{origin.address}}{JSON}\"}\\\n        %varsNotEmpty{, \"realm\":\"%enc{%map{realm}}{JSON}\"}\\\n        %varsNotEmpty{, \"url.path\":\"%enc{%map{url.path}}{JSON}\"}\\\n        %varsNotEmpty{, \"url.query\":\"%enc{%map{url.query}}{JSON}\"}\\\n        %varsNotEmpty{, \"request.method\":\"%enc{%map{request.method}}{JSON}\"}\\\n        %varsNotEmpty{, \"request.body\":\"%enc{%map{request.body}}{JSON}\"}\\\n        %varsNotEmpty{, \"request.id\":\"%enc{%map{request.id}}{JSON}\"}\\\n        %varsNotEmpty{, \"action\":\"%enc{%map{action}}{JSON}\"}\\\n        %varsNotEmpty{, \"request.name\":\"%enc{%map{request.name}}{JSON}\"}\\\n        %varsNotEmpty{, \"indices\":%map{indices}}\\\n        %varsNotEmpty{, \"opaque_id\":\"%enc{%map{opaque_id}}{JSON}\"}\\\n        %varsNotEmpty{, \"x_forwarded_for\":\"%enc{%map{x_forwarded_for}}{JSON}\"}\\\n        %varsNotEmpty{, \"transport.profile\":\"%enc{%map{transport.profile}}{JSON}\"}\\\n        %varsNotEmpty{, \"rule\":\"%enc{%map{rule}}{JSON}\"}\\\n        %varsNotEmpty{, \"event.category\":\"%enc{%map{event.category}}{JSON}\"}\\\n        }%n\n# \"node.name\" node name from the `elasticsearch.yml` settings\n# \"node.id\" node id which should not change between cluster restarts\n# \"host.name\" unresolved hostname of the local node\n# \"host.ip\" the local bound ip (i.e. the ip listening for connections)\n# \"event.type\" a received REST request is translated into one or more transport requests. This indicates which processing layer generated the event \"rest\" or \"transport\" (internal)\n# \"event.action\" the name of the audited event, eg. \"authentication_failed\", \"access_granted\", \"run_as_granted\", etc.\n# \"user.name\" the subject name as authenticated by a realm\n# \"user.run_by.name\" the original authenticated subject name that is impersonating another one.\n# \"user.run_as.name\" if this \"event.action\" is of a run_as type, this is the subject name to be impersonated as.\n# \"user.realm\" the name of the realm that authenticated \"user.name\"\n# \"user.run_by.realm\" the realm name of the impersonating subject (\"user.run_by.name\")\n# \"user.run_as.realm\" if this \"event.action\" is of a run_as type, this is the realm name the impersonated user is looked up from\n# \"user.roles\" the roles array of the user; these are the roles that are granting privileges\n# \"origin.type\" it is \"rest\" if the event is originating (is in relation to) a REST request; possible other values are \"transport\" and \"ip_filter\"\n# \"origin.address\" the remote address and port of the first network hop, i.e. a REST proxy or another cluster node\n# \"realm\" name of a realm that has generated an \"authentication_failed\" or an \"authentication_successful\"; the subject is not yet authenticated\n# \"url.path\" the URI component between the port and the query string; it is percent (URL) encoded\n# \"url.query\" the URI component after the path and before the fragment; it is percent (URL) encoded\n# \"request.method\" the method of the HTTP request, i.e. one of GET, POST, PUT, DELETE, OPTIONS, HEAD, PATCH, TRACE, CONNECT\n# \"request.body\" the content of the request body entity, JSON escaped\n# \"request.id\" a synthentic identifier for the incoming request, this is unique per incoming request, and consistent across all audit events generated by that request\n# \"action\" an action is the most granular operation that is authorized and this identifies it in a namespaced way (internal)\n# \"request.name\" if the event is in connection to a transport message this is the name of the request class, similar to how rest requests are identified by the url path (internal)\n# \"indices\" the array of indices that the \"action\" is acting upon\n# \"opaque_id\" opaque value conveyed by the \"X-Opaque-Id\" request header\n# \"x_forwarded_for\" the addresses from the \"X-Forwarded-For\" request header, as a verbatim string value (not an array)\n# \"transport.profile\" name of the transport profile in case this is a \"connection_granted\" or \"connection_denied\" event\n# \"rule\" name of the applied rulee if the \"origin.type\" is \"ip_filter\"\n# \"event.category\" fixed value \"elasticsearch-audit\"\n\nappender.audit_rolling.filePattern = ${elasticsearch.log.bak.dir}/${elasticsearch.log.file}_audit-%d{yyyy-MM-dd}-%i.log.gz\nappender.audit_rolling.policies.type = Policies\nappender.audit_rolling.policies.time.type = TimeBasedTriggeringPolicy\nappender.audit_rolling.policies.time.interval = 1\nappender.audit_rolling.policies.time.modulate = true\nappender.audit_rolling.policies.size.type = SizeBasedTriggeringPolicy\nappender.audit_rolling.policies.size.size = ${elasticsearch.log.maxfilesize}\nappender.audit_rolling.strategy.type = DefaultRolloverStrategy\nappender.audit_rolling.strategy.max = ${elasticsearch.log.maxbackup_oneday}\n\nappender.audit_rolling.strategy.delete.type = Delete\nappender.audit_rolling.strategy.delete.basePath = ${elasticsearch.log.bak.dir}\nappender.audit_rolling.strategy.delete.maxDepth = 2\nappender.audit_rolling.strategy.delete.iffile.type = IfFileName\nappender.audit_rolling.strategy.delete.iffile.glob = *.gz\nappender.audit_rolling.strategy.delete.iflastmodify.type = IfLastModified\nappender.audit_rolling.strategy.delete.iflastmodify.age = ${elasticsearch.log.maxbackup_days}\n\n\nappender.deprecated_audit_rolling.type = RollingFile\nappender.deprecated_audit_rolling.name = deprecated_audit_rolling\nappender.deprecated_audit_rolling.fileName = ${elasticsearch.log.dir}/${elasticsearch.log.file}_access.log\nappender.deprecated_audit_rolling.layout.type = PatternLayout\nappender.deprecated_audit_rolling.layout.pattern = [%d{ISO8601}] %m%n\nappender.deprecated_audit_rolling.filePattern = ${elasticsearch.log.bak.dir}/${elasticsearch.log.file}_access-%d{yyyy-MM-dd}-%i.log.gz\nappender.deprecated_audit_rolling.policies.type = Policies\nappender.deprecated_audit_rolling.policies.time.type = TimeBasedTriggeringPolicy\nappender.deprecated_audit_rolling.policies.time.interval = 1\nappender.deprecated_audit_rolling.policies.time.modulate = true\nappender.deprecated_audit_rolling.policies.size.type = SizeBasedTriggeringPolicy\nappender.deprecated_audit_rolling.policies.size.size = ${elasticsearch.log.maxfilesize}\nappender.deprecated_audit_rolling.strategy.type = DefaultRolloverStrategy\nappender.deprecated_audit_rolling.strategy.max = ${elasticsearch.log.maxbackup_oneday}\n\nappender.deprecated_audit_rolling.strategy.delete.type = Delete\nappender.deprecated_audit_rolling.strategy.delete.basePath = ${elasticsearch.log.bak.dir}\nappender.deprecated_audit_rolling.strategy.delete.maxDepth = 2\nappender.deprecated_audit_rolling.strategy.delete.iffile.type = IfFileName\nappender.deprecated_audit_rolling.strategy.delete.iffile.glob = *.gz\nappender.deprecated_audit_rolling.strategy.delete.iflastmodify.type = IfLastModified\nappender.deprecated_audit_rolling.strategy.delete.iflastmodify.age = ${elasticsearch.log.maxbackup_days}\n\nlogger.xpack_security_audit_logfile.name = org.elasticsearch.xpack.security.audit.logfile.LoggingAuditTrail\nlogger.xpack_security_audit_logfile.level = info\nlogger.xpack_security_audit_logfile.appenderRef.audit_rolling.ref = audit_rolling\nlogger.xpack_security_audit_logfile.additivity = false\n\nlogger.xpack_security_audit_deprecated_logfile.name = org.elasticsearch.xpack.security.audit.logfile.DeprecatedLoggingAuditTrail\n# set this to \"off\" instead of \"info\" to disable the deprecated appender\n# in the 6.x releases both the new and the previous appenders are enabled\n# for the logfile auditing\nlogger.xpack_security_audit_deprecated_logfile.level = info\nlogger.xpack_security_audit_deprecated_logfile.appenderRef.deprecated_audit_rolling.ref = deprecated_audit_rolling\nlogger.xpack_security_audit_deprecated_logfile.additivity = false\n\nlogger.xmlsig.name = org.apache.xml.security.signature.XMLSignature\nlogger.xmlsig.level = error\nlogger.samlxml_decrypt.name = org.opensaml.xmlsec.encryption.support.Decrypter\nlogger.samlxml_decrypt.level = fatal\nlogger.saml2_decrypt.name = org.opensaml.saml.saml2.encryption.Decrypter\nlogger.saml2_decrypt.level = fatal",
                            "elasticsearch_log_level": "info",
                            "elasticsearch_log_maxbackup_days": "10",
                            "elasticsearch_log_maxbackup_oneday": "3",
                            "elasticsearch_log_maxfilesize": "50"
                        },
                        "service_config_version_note": ""
                    },
                    {
                        "type": "elasticsearch-env",
                        "properties": {
                            "elasticsearch.base.dir": "/usr/hdp/current/elasticsearch",
                            "elasticsearch.group": "elasticsearch",
                            "elasticsearch.heap.size.percentage": "50",
                            "elasticsearch.pid.dir": "/var/run/elasticsearch",
                            "elasticsearch.user": "elasticsearch",
                            "jvm.opts": "\n################################################################\n## Expert settings\n################################################################\n##\n## All settings below this section are considered\n## expert settings. Don't tamper with them unless\n## you understand what you are doing\n##\n################################################################\n\n## GC configuration\n-XX:+UseConcMarkSweepGC\n-XX:CMSInitiatingOccupancyFraction=75\n-XX:+UseCMSInitiatingOccupancyOnly\n\n## optimizations\n\n# pre-touch memory pages used by the JVM during initialization\n-XX:+AlwaysPreTouch\n\n## basic\n\n# explicitly set the stack size\n-Xss1m\n\n# set to headless, just in case\n-Djava.awt.headless=true\n\n# ensure UTF-8 encoding by default (e.g. filenames)\n-Dfile.encoding=UTF-8\n\n# use our provided JNA always versus the system one\n-Djna.nosys=true\n\n# turn off a JDK optimization that throws away stack traces for common\n# exceptions because stack traces are important for debugging\n-XX:-OmitStackTraceInFastThrow\n\n# flags to configure Netty\n-Dio.netty.noUnsafe=true\n-Dio.netty.noKeySetOptimization=true\n-Dio.netty.recycler.maxCapacityPerThread=0\n\n# log4j 2\n-Dlog4j.shutdownHookEnabled=false\n-Dlog4j2.disable.jmx=true\n\n-Djava.io.tmpdir=${ES_TMPDIR}\n\n## heap dumps\n\n# generate a heap dump when an allocation from the Java heap fails\n# heap dumps are created in the working directory of the JVM\n-XX:+HeapDumpOnOutOfMemoryError\n\n# specify an alternative path for heap dumps; ensure the directory exists and\n# has sufficient space\n-XX:HeapDumpPath=data\n\n# specify an alternative path for JVM fatal error logs\n-XX:ErrorFile=logs/hs_err_pid%p.log\n\n## JDK 8 GC logging\n\n8:-XX:+PrintGCDetails\n8:-XX:+PrintGCDateStamps\n8:-XX:+PrintTenuringDistribution\n8:-XX:+PrintGCApplicationStoppedTime\n8:-Xloggc:logs/gc.log\n8:-XX:+UseGCLogFileRotation\n8:-XX:NumberOfGCLogFiles=32\n8:-XX:GCLogFileSize=64m\n\n# JDK 9+ GC logging\n9-:-Xlog:gc*,gc+age=trace,safepoint:file=logs/gc.log:utctime,pid,tags:filecount=10,filesize=10m\n# due to internationalization enhancements in JDK 9 Elasticsearch need to set the provider to COMPAT otherwise\n# time/date parsing will break in an incompatible way for some date patterns and locals\n9-:-Djava.locale.providers=COMPAT\n\n# temporary workaround for C2 bug with JDK 10 on hardware with AVX-512\n10-:-XX:UseAVX=2"
                        },
                        "service_config_version_note": ""
                    }
                ]
            }
        }

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._put(uri=uri, data=data, headers=headers)
        return response

    def restart_es_cluster(self, servicename, es_name, hosts):
        """
        重启es集群

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param es_name: ES集群名称
        :param hosts: 主机IP
        :return:
        """
        uri = f"/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{es_name}/restart/all/effected/components"

        data = {
            "RequestInfo": {
                "command": "RESTART",
                "context": "Restart all components with Stale Configs for ELASTICSEARCH",
                "operation_level": {
                    "level": "SERVICE",
                    "cluster_name": es_name,
                    "service_name": "ELASTICSEARCH"
                }
            },
            "Requests/resource_filters": [
                {
                    "service_name": "ELASTICSEARCH",
                    "component_name": "ELASTICSEARCH",
                    "hosts": hosts
                }
            ]
        }

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def action_es_components(self, cluster_name, action):
        """
        操作es组件

        :param cluster_name: 集群名称
        :param action: 操作。例如：停止(stop)/ 开启(start)/ 重启()
        :return:
        """
        uri = f"/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/service/ELASTICSEARCH/{action}"

        headers = self.ss.headers
        headers['servicename'] = 'elasticsearch'
        if action == 'restart':
            response = self._post(uri=uri, headers=headers)
        else:
            response = self._put(uri=uri, headers=headers)
        return response
