import allure

from resource.base.client import PAASClient
from resource.utils.common import *
from scripts.apis.handler_mqs import *

EXP_RESPONSE = {
    "code": ""
}


def create_es_vm_cluster(paas_client: PAASClient, cluster_name, label_name, net_name, kp_name, flavor, admin_pwd,
                         es_nodes, es_version, **kwargs):
    """ 创建elasticsearch虚拟机集群 """
    with allure.step("create_es_vm_cluster()"):
        # with allure.step("1.查询es版本信息"):
        #     version_response = paas_client.mqs_client.get_deploy_service()
        #     check_status_code(version_response)
        #     get_value_from_json(version_response, f"$...componentList[?(@.server_version=='{es_version}')]")
        with allure.step("1.查询网络信息"):
            prepare_info_response = paas_client.mqs_client.get_prepare_info('elasticsearch')
            check_status_code(prepare_info_response)
            zone_info = get_value_from_json(prepare_info_response, f"$..azones[?(@.labelName=='{label_name}')]")
            network_info = get_value_from_json(prepare_info_response, f"$..networkAndAzone[?(@.networkName=='{net_name}')]")
            keypair_name = get_value_from_json(prepare_info_response, f"$..keypairs[?(@.name=='{kp_name}')]")
            assert (zone_info and network_info and keypair_name), f"未找到 {label_name} 或 {net_name} 或 {kp_name}"
            zone_info = {
                "id": zone_info['id'],
                "label_name": zone_info['labelName'],
                "zone_name": zone_info['zone'],
                "virt_type": zone_info['virtType']
            }

            network_info = {
                "id": network_info['networkId'],
                "name": network_info['networkName']
            }

            keypair_name = keypair_name['name']
        with allure.step("2.查询规格信息"):
            flavor_info_response = paas_client.mqs_client.get_prepare_flavor('elasticsearch', zone_info['id'])
            check_status_code(flavor_info_response)
            flavor_info = get_value_from_json(flavor_info_response, f"$..virtual[?(@.name=='{flavor}')]")
            assert flavor_info, f"未找到规格：{flavor_info}"
            flavor_info = {
                "id": flavor_info['id'],
                "name": flavor_info['name']
            }
        with allure.step("3.查询缺省镜像信息"):
            image_info_response = paas_client.mqs_client.get_default_image_info('elasticsearch')
            check_status_code(image_info_response)
            image_id = image_info_response.json()['data']['imageId']
        with allure.step("4.创建es虚拟机集群"):
            create_response = paas_client.es_client.create_es_cluster(cluster_name, zone_info, network_info,
                                                                      keypair_name, flavor_info, image_id, admin_pwd,
                                                                      es_nodes, es_version, **kwargs)
            check_status_code(create_response)
            check_response(EXP_RESPONSE, create_response.json())


def apply_for_create_es_vm_cluster(paas_client: PAASClient, cluster_name, label_name, net_name, kp_name, flavor,
                                   admin_pwd, es_nodes, es_version, **kwargs):

    """ 申请创建elasticsearch虚拟机集群 """
    with allure.step("apply_for_create_es_vm_cluster()"):
        # with allure.step("1.查询es版本信息"):
        #     version_response = paas_client.mqs_client.get_deploy_service()
        #     check_status_code(version_response)
        #     get_value_from_json(version_response, f"$...componentList[?(@.server_version=='{es_version}')]")
        with allure.step("1.查询网络信息"):
            prepare_info_response = paas_client.mqs_client.get_prepare_info('elasticsearch')
            check_status_code(prepare_info_response)
            zone_info = get_value_from_json(prepare_info_response, f"$..azones[?(@.labelName=='{label_name}')]")
            network_info = get_value_from_json(prepare_info_response, f"$..networkAndAzone[?(@.networkName=='{net_name}')]")
            keypair_name = get_value_from_json(prepare_info_response, f"$..keypairs[?(@.name=='{kp_name}')]")
            assert (zone_info and network_info and keypair_name), f"未找到 {label_name} 或 {net_name} 或 {kp_name}"
            zone_info = {
                "id": zone_info['id'],
                "label_name": zone_info['labelName'],
                "zone_name": zone_info['zone'],
                "virt_type": zone_info['virtType']
            }

            network_info = {
                "id": network_info['networkId'],
                "name": network_info['networkName']
            }

            keypair_name = keypair_name['name']
        with allure.step("2.查询规格信息"):
            flavor_info_response = paas_client.mqs_client.get_prepare_flavor('elasticsearch', zone_info['id'])
            check_status_code(flavor_info_response)
            flavor_info = get_value_from_json(flavor_info_response, f"$..virtual[?(@.name=='{flavor}')]")
            assert flavor_info, f"未找到规格：{flavor_info}"
            flavor_info = {
                "id": flavor_info['id'],
                "name": flavor_info['name']
            }
        with allure.step("3.查询缺省镜像信息"):
            image_info_response = paas_client.mqs_client.get_default_image_info('elasticsearch')
            check_status_code(image_info_response)
            image_id = image_info_response.json()['data']['imageId']
        with allure.step("4.创建es虚拟机集群"):
            apply_response = paas_client.es_client.apply_for_create_es_cluster(cluster_name, zone_info, network_info,
                                                                               keypair_name, flavor_info, image_id,
                                                                               admin_pwd, es_nodes, es_version, **kwargs)
            check_status_code(apply_response)
            check_response(EXP_RESPONSE, apply_response.json())


def scale_es_cluster(paas_client: PAASClient, service_name, cluster_name, node_count, **kwargs):
    """ es集群主机扩容 """
    with allure.step("scale_es_cluster()"):
        with allure.step("1. 选择集群"):
            cluster_info = get_cluster_by_name(paas_client, service_name, cluster_name)
            assert cluster_info, f"未找到 {cluster_name}"
            cluster_id = cluster_info['id']
            cluster_detail_response = paas_client.mqs_client.get_bigdata_cluster_detail(service_name, cluster_id)
            check_status_code(cluster_detail_response)
            cluster_detail = cluster_detail_response.json()['data']
            zone_info = {
                "id": cluster_detail['availabilityZone']['id'],
                "name": cluster_detail['availabilityZone']['zone'],
                "virt_type": cluster_detail['availabilityZone']['virtType']
            }
            network_info = {
                "id": cluster_detail['neutronManagementNetwork'],
                "name": cluster_detail['neutronManagementNetworkName']
            }
            flavor_info = {
                "id": cluster_detail['nodeGroups'][0]['flavorId'],
                "name": str(cluster_detail['nodeGroups'][0]['cpu']) + "*" + str(int(cluster_detail['nodeGroups'][0]['ram']/1024))
                        + "*" + str(cluster_detail['nodeGroups'][0]['disk'])
            }
        with allure.step("2.扩容"):
            scale_response = paas_client.es_client.scale_es_cluster(service_name, cluster_id, cluster_name, zone_info,
                                                                    network_info, flavor_info, node_count, **kwargs)
            check_status_code(scale_response)
            result = scale_response.json()
            assert result['code'] == "", f"扩容失败。{result['msg']}"


def create_es_index(paas_client: PAASClient, service_name, cluster_name, index_name, replicas=1, shards=1):
    """ 创建ES索引 """
    es_info = get_cluster_detail(paas_client, service_name, cluster_name)
    assert es_info, f"未找到{cluster_name}"
    es_vip = es_info['data']['realIp']
    created_response = paas_client.es_client.create_index(es_vip, index_name, replicas=replicas, shards=shards)
    check_status_code(created_response)
    exp_response = {
        "code": "",
        "message": ""
    }
    check_response(exp_response, created_response.json())


def get_es_index_by_name(paas_client: PAASClient, service_name, cluster_name, index_name=""):
    """ 搜索ES索引 """
    with allure.step("get_es_index_by_name()"):
        es_info = get_cluster_detail(paas_client, service_name, cluster_name)
        assert es_info, f"未找到{cluster_name}"
        es_vip = es_info['data']['realIp']
        index_response = paas_client.es_client.get_index_list(es_vip)
        check_status_code(index_response)
        if index_name == "":
            index_info = index_response.json()
        else:
            index_info = get_value_from_json(index_response, f"$.data[?(@.index=='{index_name}')]")
        return index_info


def delete_es_index(paas_client: PAASClient, service_name, cluster_name, index_names: list):
    """ 删除ES索引 """
    es_info = get_cluster_detail(paas_client, service_name, cluster_name)
    assert es_info, f"未找到{cluster_name}"
    es_vip = es_info['data']['realIp']
    deleted_response = paas_client.es_client.action_index(es_vip, index_names, "delete")
    check_status_code(deleted_response)
    exp_response = {
        "code": "",
        "message": ""
    }
    check_response(exp_response, deleted_response.json())
    for name in index_names:
        index_info = get_es_index_by_name(paas_client, service_name, cluster_name, name)
        assert not index_info, f"未删除INDEX：{name}"


def close_es_index(paas_client: PAASClient, service_name, cluster_name, index_names: list):
    """ 关闭ES索引 """
    es_info = get_cluster_detail(paas_client, service_name, cluster_name)
    assert es_info, f"未找到{cluster_name}"
    es_vip = es_info['data']['realIp']
    closed_response = paas_client.es_client.action_index(es_vip, index_names, "close")
    check_status_code(closed_response)
    for name in index_names:
        temp = 30
        cnt = 1
        while cnt <= temp:
            index_info = get_es_index_by_name(paas_client, service_name, cluster_name, name)
            assert index_info, f"未找到INDEX：{name}"
            if index_info['status'] == "close":
                break
            time.sleep(6)
            cnt += 1
        if cnt > temp:
            raise Exception(f"关闭INDEX：{name}超时")


def open_es_index(paas_client: PAASClient, service_name, cluster_name, index_names: list):
    """ 开启ES索引 """
    es_info = get_cluster_detail(paas_client, service_name, cluster_name)
    assert es_info, f"未找到{cluster_name}"
    es_vip = es_info['data']['realIp']
    opened_response = paas_client.es_client.action_index(es_vip, index_names, "open")
    check_status_code(opened_response)
    for name in index_names:
        temp = 30
        cnt = 1
        while cnt <= temp:
            index_info = get_es_index_by_name(paas_client, service_name, cluster_name, name)
            assert index_info, f"未找到INDEX：{name}"
            if index_info['status'] == "open":
                break
            time.sleep(6)
            cnt += 1
        if cnt > temp:
            raise Exception(f"开启INDEX：{name}超时")


def update_es_config(paas_client: PAASClient, service_name, es_name, **kwargs):
    """ 更改es配置 """
    with allure.step("update_es_config()"):
        with allure.step("1. 查询集群信息"):
            es_info = get_cluster_detail(paas_client, service_name, es_name)
            assert es_info, f"未找到{es_name}"
            cluster_id = es_info['data']['id']
        with allure.step("2.获取原有配置"):
            configs_response = paas_client.mqs_client.get_cluster_config(service_name, cluster_id, service_name)
            check_status_code(configs_response)
            es_node_names = get_value_from_json(configs_response, f"$...elasticsearch-config[?(@.name=='cluster.initial_master_nodes')]")['value']
        with allure.step("3.更新配置"):
            update_response = paas_client.es_client.update_es_config(service_name, es_name, es_node_names, **kwargs)
            check_status_code(update_response)


def restart_es_cluster(paas_client: PAASClient, service_name, es_name):
    """ 重启es集群 """
    with allure.step("restart_es_cluster()"):
        with allure.step("1. 查询es集群ID"):
            es_info = get_cluster_by_name(paas_client, service_name, es_name)
            assert es_info, f"未找到es集群：{es_name}"
            host_ip = es_info['realIp']
        with allure.step("2. 查询hosts"):
            hosts = ""
            config_top_response = paas_client.mqs_client.get_cluster_component_list(service_name, host_ip, es_name,
                                                                                    service_version="ELASTICSEARCH")
            check_status_code(config_top_response)
            config_top = config_top_response.json()
            for item in config_top['data']:
                hosts += item['hostName'] + ","
        with allure.step("3. 重启集群"):
            restart_response = paas_client.es_client.restart_es_cluster(service_name, es_name, hosts[:-1])
            check_status_code(restart_response)
            timeout = 300
            temp = timeout / 5
            cnt = 1
            while cnt < temp:
                config_top_response = paas_client.mqs_client.get_cluster_component_list(service_name, host_ip, es_name,
                                                                                        service_version="ELASTICSEARCH")
                check_status_code(config_top_response)
                status = config_top_response.json()['data'][0]['componentState']
                if status == "已启动":
                    break
                time.sleep(5)
            if cnt > temp:
                raise Exception(f"重启es集群：{es_name}超时")


def stop_es_components(paas_client: PAASClient, service_name, cluster_name):
    """ 停止ES组件 """
    with allure.step("stop_es_components()"):
        with allure.step("1.停止ES组件"):
            closed_response = paas_client.es_client.action_es_components(cluster_name, "stop")
            check_status_code(closed_response)
        with allure.step("2.确认组件状态"):
            es_info = get_cluster_detail(paas_client, service_name, cluster_name)
            assert es_info, f"未找到{cluster_name}"
            es_vip = es_info['data']['realIp']
            temp = 60   # 等待10min
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                es_status_resp = paas_client.mqs_client.get_omc_service_list(service_name, es_vip, cluster_name)
                check_status_code(es_status_resp)
                es_status = es_status_resp.json()
                if es_status['data'][0]['serviceState'] == "STOPPED":
                    break
                cnt += 1
            if cnt > temp:
                raise Exception(f"停止ES组件：{cluster_name}超时")


def start_es_components(paas_client: PAASClient, service_name, cluster_name):
    """ 开启ES组件 """
    with allure.step("start_es_components()"):
        with allure.step("1.开启ES组件"):
            closed_response = paas_client.es_client.action_es_components(cluster_name, "start")
            check_status_code(closed_response)
        with allure.step("2.确认组件状态"):
            es_info = get_cluster_detail(paas_client, service_name, cluster_name)
            assert es_info, f"未找到{cluster_name}"
            es_vip = es_info['data']['realIp']
            temp = 60   # 等待10min
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                es_status_resp = paas_client.mqs_client.get_omc_service_list(service_name, es_vip, cluster_name)
                check_status_code(es_status_resp)
                es_status = es_status_resp.json()
                if es_status['data'][0]['serviceState'] == "STARTED":
                    break
                cnt += 1
            if cnt > temp:
                raise Exception(f"开启ES组件：{cluster_name}超时")


def restart_es_components(paas_client: PAASClient, service_name, cluster_name):
    """ 重启ES组件 """
    with allure.step("start_es_components()"):
        with allure.step("1.开启ES组件"):
            closed_response = paas_client.es_client.action_es_components(cluster_name, "restart")
            check_status_code(closed_response)
        with allure.step("2.确认组件状态"):
            es_info = get_cluster_detail(paas_client, service_name, cluster_name)
            assert es_info, f"未找到{cluster_name}"
            es_vip = es_info['data']['realIp']
            temp = 60   # 等待10min
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                es_status_resp = paas_client.mqs_client.get_omc_service_list(service_name, es_vip, cluster_name)
                check_status_code(es_status_resp)
                es_status = es_status_resp.json()
                if es_status['data'][0]['serviceState'] == "STARTED":
                    break
                cnt += 1
            if cnt > temp:
                raise Exception(f"重启ES组件：{cluster_name}超时")