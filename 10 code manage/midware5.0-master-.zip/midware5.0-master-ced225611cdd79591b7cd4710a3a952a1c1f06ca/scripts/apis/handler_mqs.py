from config.config import settings
from resource.base.client import PAASClient
from resource.utils.common import *


def get_cluster_by_name(paas_client: PAASClient, service_name, cluster_name):
    """ 在集群列表根据集群名称搜索 """
    with allure.step("get_cluster_by_name()"):
        cluster_info_response = paas_client.mqs_client.get_bigdata_cluster(service_name)
        check_status_code(cluster_info_response)
        cluster_info = get_value_from_json(cluster_info_response, f"$.data[?(@.name=='{cluster_name}')]")
        return cluster_info


def get_cluster_detail(paas_client: PAASClient, service_name, cluster_name):
    """ 获取集群详情 """
    with allure.step("get_cluster_detail()"):
        with allure.step("1. 查询集群ID"):
            cluster_info = get_cluster_by_name(paas_client, service_name, cluster_name)
            assert cluster_info, f"未找到集群：{cluster_name}"
            cluster_id = cluster_info['id']
        with allure.step("2. 查询集群详情"):
            detail_response = paas_client.mqs_client.get_bigdata_cluster_detail(service_name, cluster_id)
            check_status_code(detail_response)
            return detail_response.json()


def delete_cluster(paas_client: PAASClient, service_name, cluster_name):
    """ 删除集群 """
    delete_response = paas_client.mqs_client.delete_bigdata_cluster(service_name, cluster_name)
    check_status_code(delete_response)
    temp = 60
    cnt = 1
    while cnt <= temp:
        cluster_info = get_cluster_by_name(paas_client, service_name, cluster_name)
        if cluster_info:
            time.sleep(5)
        else:
            break
    if cnt > temp:
        raise Exception("删除集群超时")


def get_specific_cluster_by_name(paas_client: PAASClient, service_name, cluster_name):
    """ 获取某些特定集群。例如，kafka中数据同步集群 """
    cluster_info_response = paas_client.mqs_client.get_mqs_cluster_list(service_name)
    check_status_code(cluster_info_response)
    cluster_info = get_value_from_json(cluster_info_response, f"$.data[?(@.name=='{cluster_name}')]")
    return cluster_info


def delete_specific_cluster(paas_client: PAASClient, service_name1, service_name2, cluster_name):
    """ 删除某些特定集群。例如，kafka中数据同步集群 """
    with allure.step("delete_specific_cluster()"):
        with allure.step("1.查询集群ID"):
            cluster_info = get_specific_cluster_by_name(paas_client, service_name1, cluster_name)
            assert cluster_info, f"未找到集群：{cluster_name}"
            cluster_id = cluster_info['id']
        with allure.step("2.删除集群"):
            delete_response = paas_client.mqs_client.delete_specific_cluster(service_name2, cluster_id)
            check_status_code(delete_response)
            temp = 60
            cnt = 1
            while cnt <= temp:
                cluster_info = get_cluster_by_name(paas_client, service_name1, cluster_name)
                if cluster_info:
                    time.sleep(5)
                else:
                    break
            if cnt > temp:
                raise Exception("删除集群超时")


def get_cluster_config_detail(paas_client: PAASClient, service_name, cluster_name, config_name="", service="ZOOKEEPER37"):
    with allure.step("get_cluster_config_detail()"):
        with allure.step("1. 查询集群ID"):
            cluster_info = get_cluster_by_name(paas_client, service_name, cluster_name)
            assert cluster_info, f"未找到集群：{cluster_name}"
            cluster_id = cluster_info['id']
        with allure.step("2. 查询配置详情"):
            config_response = paas_client.mqs_client.get_cluster_config(service_name, cluster_id, service)
            check_status_code(config_response)
            if config_name == "":
                return config_response.json()
            else:
                config_info = get_value_from_json(config_response, f"$..types[*][?(@.name=='{config_name}')]")
                assert config_info, f"未找到配置项：{config_info}"
                return config_info


def collect_server_log(paas_client: PAASClient, service_name, begin_data, end_data, ssh_port=settings['SSH_PORT'],
                       plat_pwd=settings['PASSWORD']):
    """ 运行日志收集 """
    with allure.step("collect_server_log()"):
        with allure.step("1. 测试连接服务器"):
            check_connected_response = paas_client.mqs_client.check_connected_server(service_name, ssh_port, plat_pwd)
            check_status_code(check_connected_response)
            result = check_connected_response.json()
            assert result['code'] == "", f"{result['msg']}"
        with allure.step("2. 确认要收集的运行日志"):
            check_downloaded_response = paas_client.mqs_client.check_downloaded_server_log(service_name, ssh_port,
                                                                                           plat_pwd, begin_data,
                                                                                           end_data)
            check_status_code(check_downloaded_response)
            result = check_downloaded_response.json()
            assert result['code'] == "", f"{result['msg']}"
            log_id = check_downloaded_response.json()['data']
        with allure.step("3. 下载进度确认"):
            temp = 60
            cnt = 1
            while cnt < 60:
                result = paas_client.mqs_client.check_download_log_progress(service_name, log_id).json()
                if result['data'] == "Completed":
                    break
                time.sleep(10)
            if cnt > temp:
                raise Exception("运行日志收集时长超过10min")
        with allure.step("4. 下载日志"):
            download_response = paas_client.mqs_client.download_server_log(service_name, log_id)
            check_status_code(download_response)


def collect_cluster_log(paas_client: PAASClient, service_name, cluster_name):
    """ 集群日志收集 """
    with allure.step("collect_cluster_log()"):
        with allure.step("1. 选择集群"):
            cluster_info_response = paas_client.mqs_client.get_mqs_cluster_list(service_name)
            check_status_code(cluster_info_response)
            result = cluster_info_response.json()
            assert result['code'] == "", f"{result['msg']}"
            cluster_info = get_value_from_json(cluster_info_response, f"$.data[?(@.name=='{cluster_name}')]")
            assert cluster_info, f"未找到 {cluster_name}"
            cluster_id = cluster_info['id']
            master_ip = cluster_info['realIp']
            if service_name == "kafka":
                log_path = cluster_info['serviceProperties']['logPath']
        with allure.step("2. 选择节点"):
            node_info_response = paas_client.mqs_client.get_omc_list(service_name, master_ip, cluster_name)
            check_status_code(node_info_response)
            num_nodes = len(node_info_response.json()['data'])
            node_index = random.randint(0, num_nodes - 1)  # 随机选择节点
            node_info = get_value_from_json(node_info_response, f"$.data[{node_index}]")
            assert node_info, f"未找到节点：{node_info}"
            node_ip = node_info['managerIp']    #  当前租管互通，不确定使用的是managerIp还是internalIp
        with allure.step("3. 确认要收集的运行日志"):
            if service_name == "kafka":
                check_downloaded_response = paas_client.mqs_client.check_downloaded_cluster_log(service_name, cluster_id,
                                                                                                cluster_name, node_ip,
                                                                                                log_path=log_path)
            else:
                check_downloaded_response = paas_client.mqs_client.check_downloaded_cluster_log(service_name,
                                                                                                cluster_id,
                                                                                                cluster_name, node_ip)
            check_status_code(check_downloaded_response)
            result = check_downloaded_response.json()
            assert result['code'] == "", f"{result['msg']}"
            log_id = check_downloaded_response.json()['data']
        with allure.step("3. 下载进度确认"):
            temp = 60
            cnt = 1
            while cnt < 60:
                result = paas_client.mqs_client.check_download_log_progress(service_name, log_id).json()
                if result['data'] == "Completed":
                    break
                time.sleep(10)
            if cnt > temp:
                raise Exception("运行日志收集时长超过10min")
        with allure.step("4. 下载日志"):
            download_response = paas_client.mqs_client.download_cluster_log(service_name, log_id, node_ip)
            check_status_code(download_response)



