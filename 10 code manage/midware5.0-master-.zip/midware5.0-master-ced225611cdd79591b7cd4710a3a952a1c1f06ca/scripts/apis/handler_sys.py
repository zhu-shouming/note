import allure

from resource.base.client import PAASClient
from resource.utils.common import *

EXP_RESPONSE = {
    "code": None,
    "msg": None
}


def get_user_by_name(paas_client: PAASClient, user):
    """
     查询用户

     :param paas_client: 登录信息
     :param user: 用户名
     :return:

     """
    with allure.step("get_user_by_name()"):
        project_id = paas_client.login_info.default_project_id
        processes_info_response = paas_client.sys_client.get_project_users(project_id=project_id, name=user)
        check_status_code(processes_info_response)
        return processes_info_response.json()


def get_processes_by_kwargs(paas_client: PAASClient, **kwargs):
    """
    搜索流程

    :param paas_client: 登录信息
    :param kwargs: 搜索条件。如，status=PROCESSING; nameLike=aaaa; createUserNameLike=proj_admin; nextCandidateUser=userName
    :return:

    """

    with allure.step("get_processes_by_kwargs()"):
        if 'nextCandidateUser' in kwargs.keys():
            user_info = get_user_by_name(paas_client, kwargs['nextCandidateUser'])
            kwargs['nextCandidateUser'] = user_info['data']['res'][0]['id']

        processes_info_response = paas_client.sys_client.get_processes(**kwargs)
        check_status_code(processes_info_response)
        return processes_info_response.json()


def approve_processes(paas_client: PAASClient, processes_ids, is_pass, message=""):
    """
    审批流程

    :param paas_client: 登录信息
    :param processes_ids: 流程ID列表
    :param is_pass: 同意（True）/驳回（False）
    :param message: 处理意见
    :return:

    """

    with allure.step("approve_processes()"):
        with allure.step("审批流程"):
            ids = ""
            for i in range(len(processes_ids)):
                ids += processes_ids[i] + ","
            approved_response = paas_client.sys_client.deal_with_process(ids[:-1], is_pass, message)
            check_status_code(approved_response)
            check_response(EXP_RESPONSE, approved_response.json())
