from resource.base.rest_api_base import RestAPIBase
from urllib.parse import urlencode


class MqsAPI(RestAPIBase):
    def get_bigdata_cluster(self, servicename):
        """
        获取大数据集群列表
        :param servicename: 服务名称 比如：zookeeper  rabbitmq
        :return:

        """
        uri = "/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster?withDetail=True"
        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_bigdata_cluster_count(self, servicename):
        """
        获取大数据集群统计
        servicename: 服务名称 比如：zookeeper  rabbitmq
        :return:

        """
        uri = "/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster/count"
        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_bigdata_cluster_detail(self, servicename, cluster_id):
        """
        获取大数据集群详情
        :param servicename: 服务名称 比如：zookeeper  rabbitmq
        :param cluster_id: 集群ID
        :return:

        """
        uri = f"/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster/{cluster_id}?withDetail=true"
        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_specific_bigdata_cluster_detail(self, servicename, cluster_id):
        """
        获取集群详情。例如，kafka中数据同步集群

        :param servicename: 服务名称 比如：kafkaconnector, kafka
        :param cluster_id: 集群ID
        :return:

        """
        uri = f"/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster/{cluster_id}"
        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def delete_bigdata_cluster(self, servicename, cluster_name):
        """删除集群"""
        uri = f'/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster/{cluster_name}'
        headers = self.ss.headers
        headers['servicename'] = servicename
        return self._delete(uri, headers=headers)

    def delete_specific_cluster(self, servicename, cluster_id):
        """"删除某些特定集群。例如，kafka中数据同步集群

        :param servicename: 服务名称 比如：kafkaconnector
        :param cluster_id: 集群ID
        :return:

        """
        uri = f'/api/mqs/app/v1.0/iaasCluster/v1/bigdata/deleteCluster/{cluster_id}'
        headers = self.ss.headers
        headers['servicename'] = servicename
        return self._delete(uri, headers=headers)

    def get_nodes_overview(self, servicename):
        """查询主机管理--主机统计信息"""
        uri = '/api/mqs/app/v1.0/omc/operationAndMaintenanceCenter/nodeManagement/overView'
        headers = self.ss.headers
        headers['servicename'] = servicename
        return self._get(uri, headers=headers)

    def get_deploy_service(self, servicename):
        """
        获取集群部署的服务

        :return:

        """
        uri = "/api/mqs/app/v1.0/cluster/deployment/v1/service"
        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_mid_service(self):
        """
        获取中间件的服务

        :return:

        """
        uri = "/api/mqs/app/v1.0/cmw/containerMiddleware/service"

        response = self._get(uri=uri)
        return response

    def check_cluster_name(self, cluster_name):
        """
        校验集群名称

        :param cluster_name: 集群名称
        :return:

        """
        uri = (
            f"/api/mqs/app/v1.0/iaasCluster/v1/bigdata/prepare/{cluster_name}/validate"
        )

        response = self._get(uri=uri)
        return response

    def check_image(self):
        """
        校验镜像

        :return:

        """
        uri = "/api/mqs/app/v1.0/iaasCluster/v1/bigdata/imageCheck"

        response = self._get(uri=uri)
        return response

    def check_connected_server(self, servicename, ssh_port, plat_pwd):
        """
        测试连接云平台

        :param servicename: 服务名称 比如：zookeeper  rabbitmq
        :param ssh_port: 云平台SSH端口
        :param plat_pwd: 云平台密码
        :return:

        """
        uri = "/api/mqs/app/v1.0/log/v1/mqs/syslog/connect/server"

        headers = self.ss.headers
        headers['servicename'] = servicename

        data = {
            "login_port": ssh_port,
            "login_password": plat_pwd
        }

        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def check_downloaded_server_log(self, servicename, ssh_port, plat_pwd, begin_date, end_date):
        """
        确认要收集的运行日志

        :param servicename: 服务名称 比如：zookeeper  rabbitmq
        :param ssh_port: 云平台SSH端口
        :param plat_pwd: 云平台密码
        :param begin_date: 开始日期。格式："2022-07-26"
        :param end_date: 结束日期。格式："2022-07-27"

        :return:

        """
        uri = "/api/mqs/app/v1.0/log/v1/mqs/syslog/collect/podLog"

        headers = self.ss.headers
        headers['servicename'] = servicename

        data = {
            "base_name": [
                "base",
                servicename
            ],
            "login_port": ssh_port,
            "login_password": plat_pwd,
            "begin_date": begin_date,
            "end_date": end_date
        }

        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def check_downloaded_cluster_log(self, servicename, cluster_id, cluster_name, node_ip, virt_type="CAS", **kwargs):
        """
        确认要收集的运行日志

        :param servicename: 服务名称 比如：zookeeper  rabbitmq
        :param cluster_id: 集群ID
        :param cluster_name: 集群名称
        :param node_ip: zk的节点IP
        :param virt_type: 虚拟化类型。缺省为"CAS"
        :param kwargs:
        :return:

        """
        uri = "/api/mqs/app/v1.0/log/v1/mqs/syslog/collect/clusterLog"

        headers = self.ss.headers
        headers['servicename'] = servicename

        data = {
            "cluster_id": cluster_id,
            "service_type": servicename,
            "virt_type": virt_type,
            "cluster_name": cluster_name,
            "node_ip": node_ip
        }

        if servicename == "kafka":
            data['log_path'] = kwargs['log_path']

        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def get_cluster_config(self, servicename, cluster_id, service):
        """
        查询集群配置

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param cluster_id: 集群 ID
        :param service: 集群版本
        :return:
        """

        uri = f"/api/mqs/app/v1.0/iaasCluster/v1/bigdata/config/{cluster_id}?service={service}"

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_mqs_cluster_list(self, servicename):
        """
        获取大数据集群列表
        :param servicename: 服务名称 比如：zookeeper  rabbitmq
        :return:

        """
        uri = "/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster"
        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_omc_list(self, servicename, master_ip, cluster_name, page=1, size=10, order_by_field="onLine",
                     order="descending"):
        """
        确认要收集的运行日志

        :param servicename: 服务名称 比如：zookeeper  rabbitmq
        :param master_ip: 集群ID
        :param cluster_name: 集群名称
        :param page: 页码
        :param size: 数据量
        :param order_by_field: 排序方式。如，状态在线
        :param order: 升序/降序

        :return:

        """
        uri = f"/api/mqs/app/v1.0/omc/operationAndMaintenanceCenter/nodeManagement/list?masterIp={master_ip}" \
              f"&clusterName={cluster_name}&page={page}&size={size}&orderByField={order_by_field}&order={order}"

        headers = self.ss.headers
        headers['servicename'] = servicename

        response = self._get(uri=uri, headers=headers)
        return response

    def check_download_log_progress(self, servicename, log_id):
        """
        检查日志下载进度

        :param log_id: 下载日志ID
        :return:

        """
        uri = f"/api/mqs/app/v1.0/log/v1/mqs/syslog/check/download/{log_id}"

        headers = self.ss.headers
        headers['servicename'] = servicename

        response = self._get(uri=uri, headers=headers)
        return response

    def download_server_log(self, servicename, log_id):
        """
        下载运行日志

        :param log_id: 日志ID
        :return:

        """
        uri = f"/api/mqs/app/v1.0/log/v1/mqs/syslog/download/podLog/{log_id}"

        headers = self.ss.headers
        headers['servicename'] = servicename

        response = self._get(uri=uri, headers=headers)
        return response

    def download_cluster_log(self, servicename, log_id, node_ip):
        """
        下载集群日志

        :param log_id: 日志ID
        :return:

        """
        uri = f"/api/mqs/app/v1.0/log/v1/mqs/syslog/download/clusterLog"

        data = {
            "task_id": log_id,
            "node_ip": node_ip,
            "service_type": servicename
        }

        headers = self.ss.headers
        headers['servicename'] = servicename

        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def get_prepare_info(self, servicename, prepare_type="virtual"):
        """
        获取前置信息

        :param servicename: 中间件类型。如，zookeeper
        :param prepare_type: 前置信息
        :return:

        """
        uri = (
            f"/api/mqs/app/v1.0/iaasCluster/v1/bigdata/prepare/info?type={prepare_type}"
        )

        headers = self.ss.headers
        headers['servicename'] = servicename

        response = self._get(uri=uri, headers=headers)
        return response

    def get_prepare_flavor(self, servicename, zone_id):
        """
        获取前置规格

        :param servicename: 中间件类型。如，zookeeper
        :param zone_id: 可用域ID
        :return:

        """
        uri = f"/api/mqs/app/v1.0/iaasCluster/v1/bigdata/prepare/flavor?azone={zone_id}"
        headers = self.ss.headers
        headers['servicename'] = servicename

        response = self._get(uri=uri, headers=headers)
        return response

    def get_default_image_info(self, servicename):
        """
        获取缺省镜像信息

        :param servicename: 中间件类型。如，zookeeper
        :return:

        """
        uri = (
            "/api/mqs/app/v1.0/iaasCluster/v1/bigdata/customImage/defaultImageInfo/CAS"
        )
        headers = self.ss.headers
        headers['servicename'] = servicename

        response = self._get(uri=uri)
        return response

    def get_custom_images_list(self, servicename, virt_type="CAS", name=None):
        """
        获取自定义镜像列表
        :servicename: 服务名称 例如：kafaka、rabbitmq等
        :param virt_type: 虚拟化类型
        :param name: 镜像名称
        :return:

        """
        uri = f"/api/mqs/app/v1.0/iaasCluster/v1/bigdata/customImage/list/service?virtType={virt_type}&name={name}"
        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_omc_service_list(self, servicename, host_ip, cluster_name):
        """
        获取集群的状态
        :param :servicename: 服务名称 例如：kafaka、rabbitmq等
        :param host_ip: 集群主机IP
        :param cluster_name: 集群名称
        :return:

        """
        uri = f"/api/mqs/app/v1.0/omc/operationAndMaintenanceCenter/clusterManagement/serviceList?hostIp={host_ip}&clusterName={cluster_name}"
        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_omc_service_components_list(self, servicename, host_ip, cluster_name):
        """
        获取集群重启后组件的状态
        :param :servicename: 服务名称 例如：kafaka、rabbitmq等
        :param host_ip: 集群主机IP
        :param cluster_name: 集群名称
        :return:

        """
        svc_name = str(servicename).upper()
        uri = f"/api/mqs/app/v1.0/omc/operationAndMaintenanceCenter/clusterManagement/getComponentList?hostIp={host_ip}&serviceName={svc_name}&clusterName={cluster_name}"
        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_cluster_component_list(self, servicename, host_ip, cluster_name, service_version="ZOOKEEPER37"):
        """
        获取集群配置拓扑

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param host_ip: 主机IP
        :param cluster_name: 集群名称
        :return:
        """
        uri = f"/api/mqs/app/v1.0/omc/operationAndMaintenanceCenter/clusterManagement/getComponentList?hostIp={host_ip}&serviceName={service_version}&clusterName={cluster_name}"
        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_alert_contact_group(self, page=1, pagesize=10):
        """获取告警联系组"""
        uri = f"/api/mqs/app/v1.0/alert/v1/alert/group?page={page}&pageSize={pagesize}"
        return self._get(uri)

    def get_alert_contact_person(self, page=1, pagesize=10):
        """获取告警联系人"""
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/person?page={page}&pageSize={pagesize}'
        return self._get(uri)

    def get_alerts_count(self, **kwargs):
        """查询告警数量， 包括：告警总数，致命数，严重数，一般数"""
        uri = '/api/mqs/app/v1.0/alert/v1/alert/info/count'
        if kwargs:
            uri = uri + "?" + urlencode(kwargs)
        return self._get(uri)
