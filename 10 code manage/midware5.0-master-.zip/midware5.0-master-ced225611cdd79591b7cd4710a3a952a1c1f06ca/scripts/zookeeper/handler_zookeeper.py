from kazoo.client import KazooClient
from kazoo.handlers.threading import KazooTimeoutError

from scripts.apis.handler_mqs import *


def create_zookeeper_vm_cluster(paas_client: PAASClient, cluster_name, label_name, net_name, kp_name, flavor, admin_pwd,
                                is_ha=False, **kwargs):
    """ 创建zk虚拟机集群 """
    with allure.step("create_zookeeper_vm_cluster()"):
        # 这里只有zk3.7版本，故api请求中已写死。实际可以从以下接口查询
        # with allure.step("1.查询zookeeper版本等信息"):
        #     response = paas_client.mqs_client.get_deploy_service()
        #     check_status_code(response)
        with allure.step("1.查询网络信息"):
            prepare_info_response = paas_client.mqs_client.get_prepare_info('zookeeper')
            check_status_code(prepare_info_response)
            zone_info = get_value_from_json(prepare_info_response, f"$..azones[?(@.labelName=='{label_name}')]")
            network_info = get_value_from_json(prepare_info_response, f"$..networkAndAzone[?(@.networkName=='{net_name}')]")
            keypair_name = get_value_from_json(prepare_info_response, f"$..keypairs[?(@.name=='{kp_name}')]")
            assert (zone_info and network_info and keypair_name), f"未找到 {label_name} 或 {net_name} 或 {kp_name}"
            zone_info = {
                "id": zone_info['id'],
                "label_name": zone_info['labelName'],
                "zone_name": zone_info['zone'],
                "virt_type": zone_info['virtType']
            }

            network_info = {
                "id": network_info['networkId'],
                "name": network_info['networkName']
            }

            keypair_name = keypair_name['name']
        with allure.step("2.查询规格信息"):
            flavor_info_response = paas_client.mqs_client.get_prepare_flavor('zookeeper', zone_info['id'])
            check_status_code(flavor_info_response)
            flavor_info = get_value_from_json(flavor_info_response, f"$..virtual[?(@.name=='{flavor}')]")
            assert flavor_info, f"未找到规格：{flavor_info}"
            flavor_info = {
                "id": flavor_info['id'],
                "name": flavor_info['name']
            }
        with allure.step("3.查询缺省镜像信息"):
            image_info_response = paas_client.mqs_client.get_default_image_info('zookeeper')
            check_status_code(image_info_response)
            image_id = image_info_response.json()['data']['imageId']
        with allure.step("4.创建zk虚拟机集群"):
            create_response = paas_client.zk_client.create_zk_cluster(cluster_name, zone_info, network_info,
                                                                      keypair_name, flavor_info, image_id, admin_pwd,
                                                                      is_ha=is_ha, **kwargs)
            check_status_code(create_response)


def apply_for_create_zookeeper_vm_cluster(paas_client: PAASClient, cluster_name, label_name, net_name, kp_name, flavor,
                                          admin_pwd, is_ha=False, **kwargs):
    """ 申请创建zk虚拟机集群 """
    with allure.step("apply_for_create_zookeeper_vm_cluster()"):
        # 这里只有zk3.7版本，故api请求中已写死。实际可以从以下接口查询
        # with allure.step("1.查询zookeeper版本等信息"):
        #     response = paas_client.mqs_client.get_deploy_service()
        #     check_status_code(response)
        with allure.step("1.查询网络信息"):
            prepare_info_response = paas_client.mqs_client.get_prepare_info('zookeeper')
            check_status_code(prepare_info_response)
            zone_info = get_value_from_json(prepare_info_response, f"$..azones[?(@.labelName=='{label_name}')]")
            network_info = get_value_from_json(prepare_info_response, f"$..networkAndAzone[?(@.networkName=='{net_name}')]")
            keypair_name = get_value_from_json(prepare_info_response, f"$..keypairs[?(@.name=='{kp_name}')]")
            assert (zone_info and network_info and keypair_name), f"未找到 {label_name} 或 {net_name} 或 {kp_name}"
            zone_info = {
                "id": zone_info['id'],
                "label_name": zone_info['labelName'],
                "zone_name": zone_info['zone'],
                "virt_type": zone_info['virtType']
            }

            network_info = {
                "id": network_info['networkId'],
                "name": network_info['networkName']
            }

            keypair_name = keypair_name['name']
        with allure.step("2.查询规格信息"):
            flavor_info_response = paas_client.mqs_client.get_prepare_flavor('zookeeper', zone_info['id'])
            check_status_code(flavor_info_response)
            flavor_info = get_value_from_json(flavor_info_response, f"$..virtual[?(@.name=='{flavor}')]")
            assert flavor_info, f"未找到规格：{flavor_info}"
            flavor_info = {
                "id": flavor_info['id'],
                "name": flavor_info['name']
            }
        with allure.step("3.查询缺省镜像信息"):
            image_info_response = paas_client.mqs_client.get_default_image_info('zookeeper')
            check_status_code(image_info_response)
            image_id = image_info_response.json()['data']['imageId']
        with allure.step("4.创建zk虚拟机集群"):
            create_response = paas_client.zk_client.apply_for_create_zk_cluster(cluster_name, zone_info, network_info,
                                                                                keypair_name, flavor_info, image_id,
                                                                                admin_pwd, is_ha=is_ha, **kwargs)
            check_status_code(create_response)


def scale_zk_cluster(paas_client: PAASClient, service_name, cluster_name, leader_count, observer_count, **kwargs):
    """ zk集群主机扩容 """
    with allure.step("scale_zk_cluster()"):
        with allure.step("1. 选择集群"):
            cluster_info = get_cluster_by_name(paas_client, service_name, cluster_name)
            assert cluster_info, f"未找到 {cluster_name}"
            cluster_id = cluster_info['id']
            cluster_detail_response = paas_client.mqs_client.get_bigdata_cluster_detail(service_name, cluster_id)
            check_status_code(cluster_detail_response)
            cluster_detail = cluster_detail_response.json()['data']
            zone_info = {
                "id": cluster_detail['availabilityZone']['id'],
                "name": cluster_detail['availabilityZone']['zone'],
                "virt_type": cluster_detail['availabilityZone']['virtType']
            }
            network_info = {
                "id": cluster_detail['neutronManagementNetwork'],
                "name": cluster_detail['neutronManagementNetworkName']
            }
            flavor_info = {
                "id": cluster_detail['nodeGroups'][0]['flavorId'],
                "name": str(cluster_detail['nodeGroups'][0]['cpu']) + "*" + str(int(cluster_detail['nodeGroups'][0]['ram']/1024))
                        + "*" + str(cluster_detail['nodeGroups'][0]['disk'])
            }
        with allure.step("2.扩容"):
            scale_response = paas_client.zk_client.scale_zk_cluster(service_name, cluster_id, cluster_name,
                                                                    zone_info, network_info, flavor_info,
                                                                    leader_count, observer_count, **kwargs)
            check_status_code(scale_response)
            result = scale_response.json()
            assert result['code'] == "", f"扩容失败。{result['msg']}"


def create_znode(paas_client: PAASClient, service_name, zk_name, znode_path, znode_name, world=None, digest=None,
                 ip=None, **kwargs):
    """ 创建znode """
    with allure.step("create_znode()"):
        with allure.step("1. 查询zk集群ID"):
            zk_info = get_cluster_by_name(paas_client, service_name, zk_name)
            assert zk_info, f"未找到zk集群：{zk_name}"
            zk_id = zk_info['id']
        with allure.step("2. 创建znode"):
            world_acl = []
            digest_acl = []
            ip_acl = []

            if world is not None:
                for item in world:
                    each_world = {
                        "scheme": "world",
                        "userName": "anyone",
                        "permissions": item['permissions']
                    }
                    world_acl.append(each_world)

            if digest is not None:
                for item in digest:
                    each_digest = {
                        "scheme": "digest",
                        "userName": item['user_name'],
                        "password": item['password'],
                        "modifyPasswd": True,
                        "permissions": item['permissions']
                    }
                    digest_acl.append(each_digest)

            if ip is not None:
                for item in ip:
                    each_ip = {
                        "scheme": "ip",
                        "iPAddr": item['ip_addr'],
                        "permissions": item['permissions']
                    }
                    ip_acl.append(each_ip)

            create_response = paas_client.zk_client.create_znode(service_name, zk_id, znode_path, znode_name, world_acl,
                                                                 digest_acl, ip_acl)
            check_status_code(create_response)


def get_znode_by_name(paas_client: PAASClient, service_name, zk_name, znode_path, **kwargs):
    """ 根据名称查询znode """
    with allure.step("get_znode_by_name()"):
        with allure.step("1. 查询zk集群ID"):
            zk_info = get_cluster_by_name(paas_client, service_name, zk_name)
            assert zk_info, f"未找到zk集群：{zk_name}"
            zk_id = zk_info['id']
        with allure.step("2. 查询znode"):
            if 'znode_name' in kwargs.keys():
                get_response = paas_client.zk_client.get_zk_znode_list(service_name, zk_id, page=1, size=100,
                                                                       znode_path=znode_path,
                                                                       znodeName=kwargs['znode_name'])
            else:
                get_response = paas_client.zk_client.get_zk_znode_list(service_name, zk_id, page=1, size=100,
                                                                       znode_path=znode_path)
            check_status_code(get_response)
            return get_response.json()


def check_znode_on_backend(zk_addr, znode_path):
    """ 后台校验znode """
    try:
        zk = KazooClient(hosts=zk_addr)
        zk.start()
        result = zk.get_children(znode_path)
        zk.stop()
        return result
    except KazooTimeoutError as e:
        assert e.args[0] != 'Connection time-out', f"zk连接超时，请确认zk主机地址和端口是否正确。实际：{zk_addr}"


def delete_znode(paas_client: PAASClient, service_name, zk_name, znode_path, znode_name):
    """ 删除znode """
    with allure.step("delete_znode()"):
        with allure.step("1. 查询zk集群ID"):
            zk_info = get_cluster_by_name(paas_client, service_name, zk_name)
            assert zk_info, f"未找到zk集群：{zk_name}"
            zk_id = zk_info['id']
        with allure.step("2. 删除znode"):
            delete_response = paas_client.zk_client.delete_znode(service_name, zk_id, znode_path, znode_name)
            check_status_code(delete_response)
        with allure.step("3. 确认znode已删除"):
            znode_info = get_znode_by_name(paas_client, service_name, zk_name, znode_path, znode_name=znode_name)
            assert len(znode_info['data']) == 0, f"未删除 {znode_path}/{znode_name}"


def update_znode(paas_client: PAASClient, service_name, zk_name, znode_path, znode_name, **kwargs):
    """ 修改znode """
    with allure.step("update_znode()"):
        with allure.step("1. 查询zk集群ID"):
            zk_info = get_cluster_by_name(paas_client, service_name, zk_name)
            assert zk_info, f"未找到zk集群：{zk_name}"
            zk_id = zk_info['id']
        with allure.step("2. 修改znode"):
            update_response = paas_client.zk_client.update_znode(service_name, zk_id, znode_path, znode_name, **kwargs)
            check_status_code(update_response)
        with allure.step("3. 前端确认znode已更新"):
            znode_path = "/" + znode_path
            detail_info_response = paas_client.zk_client.get_znode_detail(service_name, zk_id, znode_path, znode_name)
            check_status_code(detail_info_response)
            act_acl = detail_info_response.json()['data']['acl']
            if 'world' in kwargs.keys():
                assert (act_acl['world'][0]['scheme'] == kwargs['world'][0]['scheme']) and \
                       (act_acl['world'][0]['scheme'] == 'world'), \
                    f"ACL['world']['scheme']。实际：{act_acl['world'][0]}, 期望：{kwargs['world'][0]}"
                assert (act_acl['world'][0]['userName'] == kwargs['world'][0]['userName']) and \
                       (act_acl['world'][0]['userName'] == 'anyone'), \
                    f"ACL['world']['userName']。实际：{act_acl['world'][0]}, 期望：{kwargs['world'][0]}"
                for each_perm in kwargs['world'][0]['permissions']:
                    assert each_perm in act_acl['world'][0]['permissions'], \
                        f"ACL['world']['permissions']。实际：{act_acl['world'][0]}, 期望：{kwargs['world'][0]}"

            if 'digest' in kwargs.keys():
                for each_kw in kwargs['digest']:
                    for each_act in act_acl['digest']:
                        assert (each_act['scheme'] == each_kw['scheme']) and (each_act['scheme'] == 'digest'), \
                            f"ACL['digest']['scheme']。实际：{each_act}, 期望：{each_kw}"
                        assert (each_act['userName'] == each_kw['userName']), \
                            f"ACL['digest']['userName']。实际：{each_act}, 期望：{each_kw}"
                        for each_perm in each_kw['permissions']:
                            assert each_perm in each_act['permissions'], \
                                f"ACL['digest']['permissions']。实际：{each_act}, 期望：{each_kw}"

            if 'ip' in kwargs.keys():
                for each_kw in kwargs['ip']:
                    for each_act in act_acl['ip']:
                        assert (each_act['scheme'] == each_kw['scheme']) and (each_act['scheme'] == 'ip'), \
                            f"ACL['ip']['scheme']。实际：{each_act}, 期望：{each_kw}"
                        assert (each_act['iPAddr'] == each_kw['iPAddr']), \
                            f"ACL['ip']['iPAddr']。实际：{each_act}, 期望：{each_kw}"
                        for each_perm in each_kw['permissions']:
                            assert each_perm in each_act['permissions'], \
                                f"ACL['ip']['permissions']。实际：{each_act}, 期望：{each_kw}"

            # 这种方式能判断，但循环太多，且因为列表中元素位置不同会判断为不一致
            # for kk in kwargs.keys():         # 遍历请求中传入的key
            #     for each_kwargs in kwargs[kk]:  # 每个key的值为一个列表元素
            #         for each_act_acl in act_acl[kk]:     # 响应中这些key的对象，为一个列表
            #             for each_key in each_act_acl.keys():    # 遍历列表每个元素（obj）中每一个key
            #                 if (each_key in each_kwargs.keys()) and (each_key != 'password'):
            #                     assert each_act_acl[each_key] == each_kwargs[each_key], \
            #                         f"ACL未修改成功。实际：{each_act_acl}, 期望：{each_kwargs}"

        # 后台验证check_znode_acl_on_backend()中，能够查询ACL信息，但由于数据结构特殊，不易验证，暂未写


def check_znode_acl_on_backend(zk_addr, znode_path):
    """ 后台校验znode权限 """
    zk = KazooClient(hosts=zk_addr)
    zk.start()
    result = zk.get_acls("/" + znode_path)
    zk.stop()


def update_zk_config(paas_client: PAASClient, service_name, zk_name, **kwargs):
    """ 更新zk配置 """
    with allure.step("update_zk_config()"):
        update_response = paas_client.zk_client.update_zk_config(service_name, zk_name, **kwargs)
        check_status_code(update_response)


def restart_zk_cluster(paas_client: PAASClient, service_name, zk_name):
    """ 重启zk集群 """
    with allure.step("restart_zk_cluster()"):
        with allure.step("1. 查询zk集群ID"):
            zk_info = get_cluster_by_name(paas_client, service_name, zk_name)
            assert zk_info, f"未找到zk集群：{zk_name}"
            host_ip = zk_info['realIp']
        with allure.step("2. 查询hosts"):
            config_top_response = paas_client.mqs_client.get_cluster_component_list(service_name, host_ip, zk_name)
            check_status_code(config_top_response)
            config_top = config_top_response.json()
            hosts = config_top['data'][0]['hostName']
        with allure.step("3. 重启集群"):
            restart_response = paas_client.zk_client.restart_zookeeper_cluster(service_name, zk_name, hosts)
            check_status_code(restart_response)
            timeout = 300
            temp = timeout / 5
            cnt = 1
            while cnt < temp:
                config_top_response = paas_client.mqs_client.get_cluster_component_list(service_name, host_ip, zk_name)
                check_status_code(config_top_response)
                status = config_top_response.json()['data'][0]['componentState']
                if status == "已启动":
                    break
                time.sleep(5)
            if cnt > temp:
                raise Exception(f"重启zk集群：{zk_name}超时")