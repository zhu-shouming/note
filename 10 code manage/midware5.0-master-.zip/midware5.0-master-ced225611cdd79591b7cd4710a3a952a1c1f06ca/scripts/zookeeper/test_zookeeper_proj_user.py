import pytest
import os
import yaml

from resource.utils.user import PAASLogin
from scripts.apis.handler_sys import *
from scripts.zookeeper.handler_zookeeper import *

cur_path = os.path.dirname(os.path.realpath(__file__))
datafile = os.path.join(cur_path, 'data_proj_user.yaml')

with open(datafile, encoding='utf-8') as f:
    data_file = yaml.safe_load(f)

SERVICE_NAME = "zookeeper"


@pytest.mark.zk
@allure.feature("zookeeper")
class TestZookeeper:

    """ 初始化：创建ZOOKEEPER集群 """
    def setup_class(self):
        paas_proj_user_login = PAASClient(
            PAASLogin(settings.PROJ_USER, settings.PASSWORD, settings.HOST, settings.PORT))
        paas_proj_admin_login = PAASClient(
            PAASLogin(settings.PROJ_ADMIN, settings.PASSWORD, settings.HOST, settings.PORT))
        cluster_name = "auto" + get_random_string(5, char_type=0).lower()
        label_name = settings['LABEL_NAME']
        net_name = settings['NET_NAME']
        kp_name = settings['KP_PROJ_USER_NAME']
        flavor = settings['ZK_FLAVOR']
        admin_pwd = settings['PASSWORD']
        leader_follower_nodes = settings['ZK_LEADER_FOLLOWER_NODES']
        assert leader_follower_nodes >= 3, f"leader_follower_nodes至少为3节点。实际：{leader_follower_nodes}"
        observer_count = settings['ZK_OBSERVER_COUNT']
        apply_for_create_zookeeper_vm_cluster(paas_proj_user_login, cluster_name, label_name, net_name, kp_name, flavor,
                                              admin_pwd, is_ha=True, leader_follower_nodes=leader_follower_nodes,
                                              observer_count=observer_count)
        processes_info = get_processes_by_kwargs(paas_proj_admin_login, status="PROCESSING", namelike=cluster_name,
                                                 createUserNameLike=settings['PROJ_USER'],
                                                 nextCandidateUser=settings['PROJ_ADMIN'])
        assert len(processes_info['data']) > 0, "无指定审批流程"
        processes_ids = jsonpath.jsonpath(processes_info, "$.data[*].id")
        approve_processes(paas_proj_admin_login, processes_ids, True, "OK")
        temp = 60
        cnt = 1
        while cnt <= temp:
            time.sleep(10)
            cluster_info = get_cluster_by_name(paas_proj_user_login, SERVICE_NAME, cluster_name)
            if not cluster_info:
                continue
            if cluster_info['status'] == "ACTIVE":
                break
        if cnt > temp:
            raise Exception("创建ZOOKEEPER集群超时")
        self.zk_name = cluster_name

    """ 清理：ZOOKEEPER集群 """
    def teardown_class(self):
        paas_proj_user_login = PAASClient(
            PAASLogin(settings.PROJ_USER, settings.PASSWORD, settings.HOST, settings.PORT))
        delete_cluster(paas_proj_user_login, SERVICE_NAME, self.zk_name)

    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_create_single_zookeeper'])
    @allure.description("创建zk单机")
    def test_create_single_zookeeper(self, paas_proj_user_login: PAASClient, paas_proj_admin_login, args):
        show_testcase_title(args['title'])
        with allure.step("1.申请创建ZOOKEEPER单机"):
            cluster_name = "auto" + get_random_string(5, char_type=0).lower()
            label_name = settings['LABEL_NAME']
            net_name = settings['NET_NAME']
            kp_name = settings['KP_PROJ_USER_NAME']
            flavor = settings['ZK_FLAVOR']
            admin_pwd = args['admin_pwd']
            apply_for_create_zookeeper_vm_cluster(paas_proj_user_login, cluster_name, label_name, net_name, kp_name,
                                                  flavor, admin_pwd)
        with allure.step("2.当前默认流程是一级审批。即，项目管理员审批"):
            processes_info = get_processes_by_kwargs(paas_proj_admin_login, status="PROCESSING", namelike=cluster_name,
                                                     createUserNameLike=settings['PROJ_USER'],
                                                     nextCandidateUser=settings['PROJ_ADMIN'])
            assert len(processes_info['data']) > 0, "无指定审批流程"
            processes_ids = jsonpath.jsonpath(processes_info, "$.data[*].id")
            approve_processes(paas_proj_admin_login, processes_ids, True, "OK")
        with allure.step("3.检查集群状态"):       # 等待10min
            temp = 60
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                cluster_info = get_cluster_by_name(paas_proj_user_login, SERVICE_NAME, cluster_name)
                if not cluster_info:
                    continue
                if cluster_info['status'] == "ACTIVE":
                    break
            if cnt > temp:
                raise Exception("创建ZOOKEEPER单机超时")
        with allure.step("TEARDOWN: 删除ZOOKEEPER单机"):
            delete_cluster(paas_proj_user_login, SERVICE_NAME, cluster_name)

    @pytest.mark.skip(reason="初始化中已有创建ZK集群")
    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_create_multiple_zookeeper_cluster'])
    @allure.description("创建zk集群")
    def test_create_multiple_zookeeper_cluster(self, paas_proj_user_login: PAASClient, paas_proj_admin_login, args):
        show_testcase_title(args['title'])
        with allure.step("1.申请创建ZOOKEEPER集群"):
            cluster_name = "auto" + get_random_string(5, char_type=0).lower()
            label_name = settings['LABEL_NAME']
            net_name = settings['NET_NAME']
            kp_name = settings['KP_PROJ_USER_NAME']
            flavor = settings['ZK_FLAVOR']
            admin_pwd = args['admin_pwd']
            leader_follower_nodes = args['leader_follower_nodes']
            assert leader_follower_nodes >= 3, f"leader_follower_nodes至少为3节点。实际：{leader_follower_nodes}"
            observer_count = args['observer_count']
            apply_for_create_zookeeper_vm_cluster(paas_proj_user_login, cluster_name, label_name, net_name, kp_name,
                                                  flavor, admin_pwd, is_ha=True,
                                                  leader_follower_nodes=leader_follower_nodes,
                                                  observer_count=observer_count)
        with allure.step("2.当前默认流程是一级审批。即，项目管理员审批"):
            processes_info = get_processes_by_kwargs(paas_proj_admin_login, status="PROCESSING", namelike=cluster_name,
                                                     createUserNameLike=settings['PROJ_USER'],
                                                     nextCandidateUser=settings['PROJ_ADMIN'])
            assert len(processes_info['data']) > 0, "无指定审批流程"
            processes_ids = jsonpath.jsonpath(processes_info, "$.data[*].id")
            approve_processes(paas_proj_admin_login, processes_ids, True, "OK")
        with allure.step("2.检查集群状态"):  # 等待10min
            temp = 60
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                cluster_info = get_cluster_by_name(paas_proj_user_login, SERVICE_NAME, cluster_name)
                if not cluster_info:
                    continue
                if cluster_info['status'] == "ACTIVE":
                    break
            if cnt > temp:
                raise Exception("创建ZOOKEEPER集群超时")
        with allure.step("TEARDOWN: 删除ZOOKEEPER集群"):
            delete_cluster(paas_proj_user_login, SERVICE_NAME, cluster_name)

    @pytest.mark.L5
    @allure.description("创建znode")
    def test_create_znode(self, paas_proj_user_login: PAASClient):
        show_testcase_title("普通用户 -- 创建Znode")
        with allure.step("1.创建znode"):
            # zk_name = "testaaa"  ### 修改zk_name
            postfix = get_random_string(5, char_type=0).lower()
            znode_path = "auto" + postfix
            znode_name = "autosub" + postfix
            world = [{
                "permissions": ["Read", "Delete", "Admin", "Create", "Write"]
            }]
            create_znode(paas_proj_user_login, SERVICE_NAME, self.zk_name, znode_path, znode_name, world)
        with allure.step("2. 页面校验父znode是否创建成功"):
            znode_info = get_znode_by_name(paas_proj_user_login, SERVICE_NAME, self.zk_name, "", znode_name=znode_path)
            assert len(znode_info['data']) > 0, f"{znode_path} 未创建成功"
        with allure.step("3. 页面校验子znode是否创建成功"):
            znode_info = get_znode_by_name(paas_proj_user_login, SERVICE_NAME, self.zk_name, znode_path)
            assert len(znode_info['data']) > 0, f"{znode_path} 下无子node"
            znode_names = []
            for sub_znode in znode_info['data']:
                znode_names.append(sub_znode['znodeName'])
            assert znode_name in znode_names, f"{znode_path} 下的 {znode_name} 未创建成功"
        with allure.step("4. 后台是否创建成功"):
            zk_info = get_cluster_detail(paas_proj_user_login, SERVICE_NAME, self.zk_name)
            assert zk_info, f"未找到{self.zk_name}"
            zk_addr = zk_info['data']['serviceProperties']['url']
            result = check_znode_on_backend(zk_addr, znode_path)
            assert znode_name in result, f"未找到{znode_path}/{znode_name}"
        with allure.step("TEARDOWN: 删除znode"):
            delete_znode(paas_proj_user_login, SERVICE_NAME, self.zk_name, "", znode_path)
            result = check_znode_on_backend(zk_addr, "")
            assert znode_path not in result, f"未删除{znode_path}/{znode_name}"

    @pytest.mark.L5
    @allure.description("修改znode")
    def test_update_znode(self, paas_proj_user_login: PAASClient):
        show_testcase_title("普通用户 -- 修改Znode")
        with allure.step("SETUP: 创建znode"):
            # zk_name = "testaaa"  ### 修改zk_name
            postfix = get_random_string(5, char_type=0).lower()
            znode_path = "auto" + postfix
            znode_name = "autosub" + postfix
            world = [{
                "permissions": ["Read", "Delete", "Admin", "Create", "Write"]
            }]
            create_znode(paas_proj_user_login, SERVICE_NAME, self.zk_name, znode_path, znode_name, world)
            # 页面校验父znode是否创建成功
            znode_info = get_znode_by_name(paas_proj_user_login, SERVICE_NAME, self.zk_name, "", znode_name=znode_path)
            assert len(znode_info['data']) > 0, f"{znode_path} 未创建成功"
            # 页面校验子znode是否创建成功
            znode_info = get_znode_by_name(paas_proj_user_login, SERVICE_NAME, self.zk_name, znode_path)
            assert len(znode_info['data']) > 0, f"{znode_path} 下无子node"
            znode_names = []
            for sub_znode in znode_info['data']:
                znode_names.append(sub_znode['znodeName'])
            assert znode_name in znode_names, f"{znode_path} 下的 {znode_name} 未创建成功"
        with allure.step("2. 修改znode"):
            digest = [
                {
                    "scheme": "digest",
                    "userName": "auto" + get_random_string(5, char_type=0).lower(),
                    "password": "admin@123",
                    "modifyPasswd": True,
                    "permissions": [
                        "Read",
                        "Create",
                        "Delete",
                        "Admin"
                    ]
                }
            ]
            # 对父节点进行权限设置
            update_znode(paas_proj_user_login, SERVICE_NAME, self.zk_name, "", znode_path, digest=digest)
        with allure.step("TEARDOWN: 删除znode"):
            delete_znode(paas_proj_user_login, SERVICE_NAME, self.zk_name, "", znode_path)
            zk_info = get_cluster_detail(paas_proj_user_login, SERVICE_NAME, self.zk_name)
            assert zk_info, f"未找到{self.zk_name}"
            zk_addr = zk_info['data']['serviceProperties']['url']
            result = check_znode_on_backend(zk_addr, "")
            assert znode_path not in result, f"未删除{znode_path}/{znode_name}"

    @pytest.mark.L5
    @allure.description("更改zk配置")
    def test_update_config(self, paas_proj_user_login: PAASClient):
        show_testcase_title("普通用户 -- 修改配置文件中ZK端口号")
        with allure.step("1. 查询默认端口"):
            # zk_name = "testaaa"  ### 修改zk_name
            config_info = get_cluster_config_detail(paas_proj_user_login, SERVICE_NAME, self.zk_name,
                                                    config_name="clientPort")
            origin_zk_port = config_info['value']
        with allure.step("2. 修改端口"):
            for i in range(3):
                new_zk_port = str(random.randint(2100, 2200))
                if new_zk_port != origin_zk_port:
                    break

            zoo_cfg = {
                "clientPort": new_zk_port
            }
            update_zk_config(paas_proj_user_login, SERVICE_NAME, self.zk_name, zoo_cfg=zoo_cfg)
        with allure.step("3. 重启集群"):
            restart_zk_cluster(paas_proj_user_login, SERVICE_NAME, self.zk_name)
        with allure.step("4. 确认端口已修改"):
            config_info = get_cluster_config_detail(paas_proj_user_login, SERVICE_NAME, self.zk_name,
                                                    config_name="clientPort")
            current_zk_port = config_info['value']
            assert current_zk_port == new_zk_port, f"端口修改失败。实际：{current_zk_port}，期望：{new_zk_port}"
        with allure.step("5. 后台连接测试"):
            zk_info = get_cluster_detail(paas_proj_user_login, SERVICE_NAME, self.zk_name)
            zk_addr = zk_info['data']['serviceProperties']['url']
            zk = KazooClient(hosts=zk_addr)
            try:
                zk.start()
                zk.stop()
            except KazooTimeoutError as e:
                assert e.args[0] != 'Connection time-out', f"zk连接超时，请确认zk主机地址和端口是否正确。实际：{zk_addr}"
        with allure.step("TEARDOWN:"):
            with allure.step("1. 恢复端口"):
                zoo_cfg = {
                    "clientPort": origin_zk_port
                }
                update_zk_config(paas_proj_user_login, SERVICE_NAME, self.zk_name, zoo_cfg=zoo_cfg)
            with allure.step("2. 重启集群"):
                restart_zk_cluster(paas_proj_user_login, SERVICE_NAME, self.zk_name)
            with allure.step("3. 确认端口已修改"):
                config_info = get_cluster_config_detail(paas_proj_user_login, SERVICE_NAME, self.zk_name,
                                                        config_name="clientPort")
                current_zk_port = config_info['value']
                assert current_zk_port == origin_zk_port, f"端口修改失败。实际：{current_zk_port}，期望：{origin_zk_port}"
            with allure.step("4. 后台连接测试"):
                zk_info = get_cluster_detail(paas_proj_user_login, SERVICE_NAME, self.zk_name)
                zk_addr = zk_info['data']['serviceProperties']['url']
                zk = KazooClient(hosts=zk_addr)
                try:
                    zk.start()
                    zk.stop()
                except KazooTimeoutError as e:
                    assert e.args[0] != 'Connection time-out', f"zk连接超时，请确认zk主机地址和端口是否正确。实际：{zk_addr}"

    @pytest.mark.L5
    @allure.description("主机扩容")
    def test_scale_zk(self, paas_proj_user_login: PAASClient):
        show_testcase_title("普通用户 -- ZK主机扩容")
        with allure.step("1. 原有节点数量"):
            cluster_detail = get_cluster_detail(paas_proj_user_login, SERVICE_NAME, self.zk_name)
            assert cluster_detail, f"未找到：{self.zk_name}"
            origin_node_count = cluster_detail['data']['nodeCount']
            origin_leader_count = cluster_detail['data']['serviceProperties']['leaderAndFollowerCount']
            origin_observer_count = cluster_detail['data']['serviceProperties']['observerCount']
        with allure.step("2.主机扩容"):
            step_leader_count = 2
            step_observer_count = 2
            scale_zk_cluster(paas_proj_user_login, SERVICE_NAME, self.zk_name, step_leader_count, step_observer_count)
            temp = 120
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                cluster_info = get_cluster_by_name(paas_proj_user_login, SERVICE_NAME, self.zk_name)
                if cluster_info['status'] == "ACTIVE":
                    break
                cnt += 1
            if cnt > temp:
                raise Exception("主机扩容超时")
        with allure.step("3.校验扩容结果"):
            cluster_detail = get_cluster_detail(paas_proj_user_login, SERVICE_NAME, self.zk_name)
            new_node_count = cluster_detail['data']['nodeCount']
            new_leader_count = cluster_detail['data']['serviceProperties']['leaderAndFollowerCount']
            new_observer_count = cluster_detail['data']['serviceProperties']['observerCount']
            assert (origin_node_count + step_leader_count + step_observer_count) == new_node_count, \
                f"扩容失败。实际节点数量：{new_node_count}, 期望：{origin_node_count + step_leader_count + step_observer_count}"
            assert (origin_leader_count + step_leader_count) == new_leader_count, \
                f"扩容失败。实际节点数量：{new_node_count}, 期望：{origin_leader_count + step_leader_count}"
            assert (origin_observer_count + step_observer_count) == new_observer_count, \
                f"扩容失败。实际节点数量：{new_node_count}, 期望：{origin_observer_count + step_observer_count}"
