from resource.base.rest_api_base import RestAPIBase
from urllib.parse import urlencode


class ZooKeeperAPI(RestAPIBase):

    def get_zk_znode_list(self, servicename, zk_id, znode_path, page=1, size=10, **kwargs):
        """
        获取zookeeper中znode列表

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param zk_id: zookeeper ID
        :param page: 页码
        :param size: 数据条数
        :param znode_path: 路径
        :return:

        """
        uri = f"/api/mqs/app/v1.0/zookeeper/manage/v1/zookeeper/znode/{zk_id}/list?page={page}&size={size}&path=/{znode_path}&orderByField=znodeName&order=ascending"

        if kwargs:
            uri = uri + '&' + urlencode(kwargs)

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def create_zk_cluster(self, cluster_name, zone_info, network_info, keypair_name, flavor_info, image_id, admin_pwd,
                          monitor_on=1, monitor_interval="15s", is_ha=False, **kwargs):
        """
        创建zookeeper虚拟机集群

        :param cluster_name: 集群名称
        :param zone_info: 可用域信息
        :param network_info: 网络信息
        :param keypair_name: 密钥对名称
        :param flavor_info: 规格信息
        :param image_id: 镜像ID
        :param admin_pwd: 管理员密码
        :param monitor_on: 是否开启监控。1（是）/0（否）
        :param monitor_interval: 监控间隔
        :param is_ha: 单机（False）/集群（True）
        :param kwargs:
        :return:

        """

        uri = "/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster"

        data = {
            "type": "zookeeper",
            "name": cluster_name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": admin_pwd,
            "observer_count": kwargs['observer_count'] if 'observer_count' in kwargs.keys() else 0,
            "description": kwargs['description'] if 'description' in kwargs.keys() else "",
            "whether_ha": is_ha,
            "availability_zone": {
                "id": zone_info['id'],
                "name": zone_info['zone_name'],
                "virtType": zone_info['virt_type'],
            },
            "neutron_management_network_id": network_info['id'],
            "keypair_name": keypair_name,
            "anti_affinity": kwargs['anti_affinity'] if 'anti_affinity' in kwargs.keys() else False,
            "service": [
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"],
                }
            ],
            "monitor_interval": monitor_interval,
            "monitor_on": monitor_on,
            "node_flavor_list": [],
            "master": {"size": 2 if is_ha else 1, "flavor_id": ""},
            "core": {
                "size": (kwargs['leader_follower_nodes'] - 2) if is_ha else 0,
                "flavor_id": "",
            },
            "task": {"size": "0", "flavor_id": ""},
            "instanceInfo": [
                {
                    "roleNameList": ["master-1"],
                    "title": "Zookeeper实例",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "serverRole": "Leader/Follower" if is_ha else "Standalone",
                }
            ],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "manager_virtual_ip": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "neutron_management_network_name": network_info['name'],
            "imageId": image_id,
            "version": {"ZOOKEEPER": "3.7.0"},
        }

        service_sub1 = {
            "display": True,
            "component": "ZOOKEEPER37_SERVER",
            "relation": "",
            "host_roles_default": ["master"],
            "optional_host_roles": [],
            "hosts": ["master-1"],
            "service": "ZOOKEEPER",
        }

        service_sub2 = {
            "component": "AMBARI_SLAVE",
            "display": False,
            "service": "AMBARI",
            "relation": "",
            "host_roles_default": ["master"],
            "hosts": ["master-2"],
        }

        instance_sub1 = {
            "roleNameList": ["master-2"],
            "title": "Zookeeper实例",
            "azoneId": zone_info['id'],
            "labelName": zone_info['label_name'],
            "azoneName": zone_info['zone_name'],
            "virtType": zone_info['virt_type'],
            "flavorId": flavor_info['id'],
            "name": flavor_info['name'],
            "storageTypeId": None,
            "fixIp": "",
            "serverRole": "Leader/Follower" if is_ha else "Standalone",
        }

        instance_sub2 = {
            "roleNameList": [],
            "title": "Zookeeper实例",
            "azoneId": zone_info['id'],
            "labelName": zone_info['label_name'],
            "azoneName": zone_info['zone_name'],
            "virtType": zone_info['virt_type'],
            "flavorId": flavor_info['id'],
            "name": flavor_info['name'],
            "storageTypeId": None,
            "fixIp": "",
            "serverRole": "Leader/Follower" if is_ha else "Standalone",
        }

        if is_ha:
            service_sub1['host_roles_default'].append("core")
            service_sub1['hosts'].append("master-2")
            data['instanceInfo'].append(instance_sub1)
            for i in range(1, kwargs['leader_follower_nodes'] - 1):
                service_sub1['hosts'].append("core-" + str(i))
                instance_sub2['roleNameList'].append("core-" + str(i))
                data['instanceInfo'].append(instance_sub2)

            data['service'].append(service_sub1)
            data['service'].append(service_sub2)

        else:
            data['service'].append(service_sub1)

        headers = self.ss.headers
        headers['servicename'] = 'zookeeper'
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def create_znode(self, servicename, zk_id, znode_path, znode_name, world=None, digest=None, ip=None, **kwargs):
        """
        创建znode

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param zk_id: zookeeper ID
        :param znode_path: path
        :param znode_name: znode名称
        :param world: world acl
        :param digest: digest acl
        :param ip: ip acl
        :param kwargs:
        :return:
        """

        uri = f"/api/mqs/app/v1.0/zookeeper/manage/v1/zookeeper/znode/{zk_id}/create"

        data = {
            "path": "/" + znode_path,
            "znodeName": znode_name,
            "value": kwargs['value'] if 'value' in kwargs.keys() else "",
            "persistentSequential": kwargs[
                'persistent_sequential'] if 'persistent_sequential' in kwargs.keys() else "false",
            "acl": {
                "world": [] if world is None else world,
                "digest": [] if digest is None else digest,
                "ip": [] if ip is None else ip
            }
        }

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def delete_znode(self, servicename, zk_id, znode_path, znode_name):
        """
        删除znode

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param zk_id: zookeeper ID
        :param znode_name: znode名称
        :param znode_path: path

        :return:
        """

        uri = f"/api/mqs/app/v1.0/zookeeper/manage/v1/zookeeper/znode/{zk_id}/delete?path=/{znode_path}&znodeName={znode_name}"

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._delete(uri=uri, headers=headers)
        return response

    def update_znode(self, servicename, zk_id, znode_path, znode_name, **kwargs):
        """
        修改znode

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param zk_id: zookeeper ID
        :param znode_path: path
        :param znode_name: znode名称
        :param kwargs:
        :return:
        """

        uri = f"/api/mqs/app/v1.0/zookeeper/manage/v1/zookeeper/znode/{zk_id}/update"

        acl = {}

        if 'world' in kwargs.keys():
            acl["world"] = kwargs['world']
        if 'digest' in kwargs.keys():
            acl["digest"] = kwargs['digest']
        if 'ip' in kwargs.keys():
            acl["ip"] = kwargs['ip']

        data = {
            "path": "/" + znode_path,
            "znodeName": znode_name,
            "value": kwargs['value'] if 'value' in kwargs.keys() else None,
            "persistentSequential": kwargs[
                'persistent_sequential'] if 'persistent_sequential' in kwargs.keys() else "false",
            "acl": acl
        }

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._put(uri=uri, data=data, headers=headers)
        return response

    def get_znode_detail(self, servicename, zk_id, znode_path, znode_name):
        """
        查询znode详情

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param zk_id: zookeeper ID
        :param znode_path: 父目录
        :param znode_name: znode名称
        :param kwargs:
        :return:
        """

        uri = f"/api/mqs/app/v1.0/zookeeper/manage/v1/zookeeper/znode/{zk_id}/detail?path={znode_path}&znodeName={znode_name}"

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def update_zk_config(self, servicename, zk_name, **kwargs):
        """
        修改zk配置

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param zk_name: zookeeper名称
        :param kwargs:
        :return:
        """

        uri = f"/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{zk_name}/update/configs"

        data = {
            "Clusters": {
                "desired_config": [
                    {
                        "type": "zoo.cfg",
                        "properties": {
                            "autopurge.purgeInterval": kwargs['zoo_cfg'][
                                'autopurge.purgeInterval'] if 'autopurge.purgeInterval' in kwargs[
                                'zoo_cfg'].keys() else "0",
                            "autopurge.snapRetainCount": kwargs['zoo_cfg'][
                                'autopurge.snapRetainCount'] if 'autopurge.snapRetainCount' in kwargs[
                                'zoo_cfg'].keys() else "3",
                            "clientPort": kwargs['zoo_cfg']['clientPort'] if 'clientPort' in kwargs[
                                'zoo_cfg'].keys() else "2181",
                            "dataDir": kwargs['zoo_cfg']['dataDir'] if 'dataDir' in kwargs[
                                'zoo_cfg'].keys() else "/zookeeper",
                            "globalOutstandingLimit": kwargs['zoo_cfg'][
                                'globalOutstandingLimit'] if 'globalOutstandingLimit' in kwargs[
                                'zoo_cfg'].keys() else "1000",
                            "initLimit": kwargs['zoo_cfg']['initLimit'] if 'initLimit' in kwargs[
                                'zoo_cfg'].keys() else "5",
                            "jute.maxbuffer": kwargs['zoo_cfg']['ute.maxbuffer'] if 'ute.maxbuffer' in kwargs[
                                'zoo_cfg'].keys() else "1048575",
                            "maxClientCnxns": kwargs['zoo_cfg']['maxClientCnxns'] if 'maxClientCnxns' in kwargs[
                                'zoo_cfg'].keys() else "60",
                            "preAllocSize": kwargs['zoo_cfg']['preAllocSize'] if 'preAllocSize' in kwargs[
                                'zoo_cfg'].keys() else "64M",
                            "quorumListenOnAllIPs": kwargs['zoo_cfg'][
                                'quorumListenOnAllIPs'] if 'quorumListenOnAllIPs' in kwargs[
                                'zoo_cfg'].keys() else "false",
                            "snapCount": kwargs['zoo_cfg']['snapCount'] if 'snapCount' in kwargs[
                                'zoo_cfg'].keys() else "100000",
                            "syncLimit": kwargs['zoo_cfg']['syncLimit'] if 'syncLimit' in kwargs[
                                'zoo_cfg'].keys() else "2",
                            "tickTime": kwargs['zoo_cfg']['tickTime'] if 'tickTime' in kwargs[
                                'zoo_cfg'].keys() else "2000"
                        },
                        "service_config_version_note": ""
                    },
                    {
                        "type": "zookeeper-env",
                        "properties": {
                            "Observer.hosts": kwargs['zookeeper_env']['Observer.hosts']
                            if ('zookeeper_env' in kwargs.keys()) and ('Observer.hosts' in kwargs['zookeeper_env'].keys())
                            else "",
                            "extend.observer.count": kwargs['zookeeper_env'][
                                'extend.observer.count'] if ('zookeeper_env' in kwargs.keys()) and (
                                        'extend.observer.count' in kwargs[
                                    'zookeeper_env'].keys()) else "0",
                            "extend.observer.ip": kwargs['zookeeper_env'][
                                'extend.observer.ip'] if ('zookeeper_env' in kwargs.keys()) and (
                                        'extend.observer.ip' in kwargs['zookeeper_env'].keys()) else "",
                            "super.user.password": kwargs['zookeeper_env'][
                                'super.user.password'] if ('zookeeper_env' in kwargs.keys()) and (
                                        'super.user.password' in kwargs[
                                    'zookeeper_env'].keys()) else "Passw0rd@_",
                            "zk_server_heapsize": kwargs['zookeeper_env'][
                                'zk_server_heapsize'] if ('zookeeper_env' in kwargs.keys()) and (
                                        'zk_server_heapsize' in kwargs[
                                    'zookeeper_env'].keys()) else "1024m",
                            "zookeeper.user.nofile.limit": kwargs['zookeeper_env'][
                                'zookeeper.user.nofile.limit'] if ('zookeeper_env' in kwargs.keys()) and (
                                        'zookeeper.user.nofile.limit' in kwargs[
                                    'zookeeper_env'].keys()) else "128000",
                            "zookeeper.user.nproc.limit": kwargs['zookeeper_env'][
                                'zookeeper.user.nproc.limit'] if ('zookeeper_env' in kwargs.keys()) and (
                                        'zookeeper.user.nproc.limit' in kwargs[
                                    'zookeeper_env'].keys()) else "65536"
                        },
                        "service_config_version_note": ""
                    }
                ]
            }
        }

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._put(uri=uri, data=data, headers=headers)
        return response

    def restart_zookeeper_cluster(self, servicename, cluster_name, hosts, service_version="ZOOKEEPER37"):
        """
        重启zk集群

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param cluster_name: 集群名称
        :param hosts: 主机IP
        :param service_version: 集群名称和版本
        :return:
        """
        uri = f"/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/restart/all/effected/components"

        data = {
            "RequestInfo": {
                "command": "RESTART",
                "context": "Restart all components with Stale Configs for " + service_version,
                "operation_level": {
                    "level": "SERVICE",
                    "cluster_name": cluster_name,
                    "service_name": service_version
                }
            },
            "Requests/resource_filters": [
                {
                    "service_name": service_version,
                    "component_name": service_version + "_SERVER",
                    "hosts": hosts
                }
            ]
        }

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def apply_for_create_zk_cluster(self, cluster_name, zone_info, network_info, keypair_name, flavor_info, image_id,
                                    admin_pwd, monitor_on=1, monitor_interval="15s", is_ha=False, **kwargs):

        """
        普通用户申请创建zookeeper虚拟机集群

        :param cluster_name: 集群名称
        :param zone_info: 可用域信息
        :param network_info: 网络信息
        :param keypair_name: 密钥对名称
        :param flavor_info: 规格信息
        :param image_id: 镜像ID
        :param admin_pwd: 管理员密码
        :param monitor_on: 是否开启监控。1（是）/0（否）
        :param monitor_interval: 监控间隔
        :param is_ha: 单机（False）/集群（True）
        :param kwargs:
        :return:

        """

        uri = "/api/mqs/app/v1.0/cluster/deployment/v1/deployment/cluster/iaas/process"

        data = {
            "type": "zookeeper",
            "name": cluster_name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": admin_pwd,
            "observer_count": kwargs['observer_count'] if 'observer_count' in kwargs.keys() else 0,
            "description": kwargs['description'] if 'description' in kwargs.keys() else "",
            "whether_ha": is_ha,
            "availability_zone": {
                "id": zone_info['id'],
                "name": zone_info['zone_name'],
                "virtType": zone_info['virt_type'],
            },
            "neutron_management_network_id": network_info['id'],
            "keypair_name": keypair_name,
            "anti_affinity": kwargs['anti_affinity'] if 'anti_affinity' in kwargs.keys() else False,
            "service": [
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"],
                }
            ],
            "monitor_interval": monitor_interval,
            "monitor_on": monitor_on,
            "node_flavor_list": [],
            "master": {"size": 2 if is_ha else 1, "flavor_id": ""},
            "core": {
                "size": (kwargs['leader_follower_nodes'] - 2) if is_ha else 0,
                "flavor_id": "",
            },
            "task": {"size": "0", "flavor_id": ""},
            "instanceInfo": [
                {
                    "roleNameList": ["master-1"],
                    "title": "Zookeeper实例",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "serverRole": "Leader/Follower" if is_ha else "Standalone",
                }
            ],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "manager_virtual_ip": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "neutron_management_network_name": network_info['name'],
            "imageId": image_id,
            "version": {"ZOOKEEPER": "3.7.0"},
        }

        service_sub1 = {
            "display": True,
            "component": "ZOOKEEPER37_SERVER",
            "relation": "",
            "host_roles_default": ["master"],
            "optional_host_roles": [],
            "hosts": ["master-1"],
            "service": "ZOOKEEPER",
        }

        service_sub2 = {
            "component": "AMBARI_SLAVE",
            "display": False,
            "service": "AMBARI",
            "relation": "",
            "host_roles_default": ["master"],
            "hosts": ["master-2"],
        }

        instance_sub1 = {
            "roleNameList": ["master-2"],
            "title": "Zookeeper实例",
            "azoneId": zone_info['id'],
            "labelName": zone_info['label_name'],
            "azoneName": zone_info['zone_name'],
            "virtType": zone_info['virt_type'],
            "flavorId": flavor_info['id'],
            "name": flavor_info['name'],
            "storageTypeId": None,
            "fixIp": "",
            "serverRole": "Leader/Follower" if is_ha else "Standalone",
        }

        instance_sub2 = {
            "roleNameList": [],
            "title": "Zookeeper实例",
            "azoneId": zone_info['id'],
            "labelName": zone_info['label_name'],
            "azoneName": zone_info['zone_name'],
            "virtType": zone_info['virt_type'],
            "flavorId": flavor_info['id'],
            "name": flavor_info['name'],
            "storageTypeId": None,
            "fixIp": "",
            "serverRole": "Leader/Follower" if is_ha else "Standalone",
        }

        if is_ha:
            service_sub1['host_roles_default'].append("core")
            service_sub1['hosts'].append("master-2")
            data['instanceInfo'].append(instance_sub1)
            for i in range(1, kwargs['leader_follower_nodes'] - 1):
                service_sub1['hosts'].append("core-" + str(i))
                instance_sub2['roleNameList'].append("core-" + str(i))
                data['instanceInfo'].append(instance_sub2)

            data['service'].append(service_sub1)
            data['service'].append(service_sub2)

        else:
            data['service'].append(service_sub1)

        headers = self.ss.headers
        headers['servicename'] = 'zookeeper'
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def scale_zk_cluster(self, servicename, cluster_id, cluster_name, zone_info, network_info, flavor_info,
                         leader_count, observer_count, **kwargs):
        """
        zk主机扩容

        :param servicename: 服务名称 比如：zookeeper  rabbitmq
        :param cluster_id: 集群ID
        :param cluster_name: 集群名称
        :param zone_info: 可用域信息
        :param network_info: 网络信息
        :param flavor_info: 规格信息
        :param leader_count: leader个数
        :param observer_count: observer个数
        :param kwargs
        :return:

        """

        uri = f"/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster/{cluster_id}"

        data = {
            "expand": True,
            "node_count": leader_count + observer_count,
            "cluster_name": cluster_name,
            "flavor_id": flavor_info['id'],
            "storageTypeId": None,
            "node_processes": ["ZOOKEEPER37_SERVER"],
            "instanceInfo": [],
            "clusterData": [],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "neutron_management_network_id": network_info['id'],
            "neutron_management_network_name": network_info['name'],
            "managerNetwork": network_info['id'],
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "quota": 100,
            "quotaText": "可用1000000000G / 全部1000000000G",
            "replicates": 1,
            "leader_count": leader_count,
            "extend_observer_count": observer_count
        }

        for i in range(leader_count):
            sub_data = {
                "roleNameList": [],
                "title": "Zookeeper实例",
                "azoneId": zone_info['id'],
                "azoneName": zone_info['name'],
                "virtType": zone_info['virt_type'],
                "flavorId": flavor_info['id'],
                "storageTypeId": None,
                "onlyId": flavor_info['id'] + "_",
                "name": flavor_info['name'],
                "fixIp": "",
                "fixManagementIp": ""
            }
            sub_data['roleNameList'].append("extend-" + str(i + 1))
            sub_data['serverRole'] = "Leader/Follower"
            data['instanceInfo'].append(sub_data)
            data['clusterData'].append(sub_data)

        for i in range(observer_count):
            sub_data = {
                "roleNameList": [],
                "title": "Zookeeper实例",
                "azoneId": zone_info['id'],
                "azoneName": zone_info['name'],
                "virtType": zone_info['virt_type'],
                "flavorId": flavor_info['id'],
                "storageTypeId": None,
                "onlyId": flavor_info['id'] + "_",
                "name": flavor_info['name'],
                "fixIp": "",
                "fixManagementIp": ""
            }
            sub_data['roleNameList'].append("extend-" + str(i + 1))
            sub_data['serverRole'] = "Observer"
            data['instanceInfo'].append(sub_data)
            data['clusterData'].append(sub_data)

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._post(uri=uri, json=data, headers=headers)
        return response

