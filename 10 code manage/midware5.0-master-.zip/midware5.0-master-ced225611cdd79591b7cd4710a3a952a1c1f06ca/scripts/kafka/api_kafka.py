from resource.base.rest_api_base import RestAPIBase
from urllib.parse import urlencode


class KafkaAPI(RestAPIBase):

    def create_kafka_cluster(self, cluster_name, zone_info, network_info, keypair_name, flavor_info, image_id, kafka_pwd,
                             monitor_on=1, monitor_interval="15s", kafka_nodes=3, safety_mgt=False, anti_affinity=False,
                             **kwargs):

        """
        创建kafka虚拟机集群

        :param cluster_name: 集群名称
        :param zone_info: 可用域信息
        :param network_info: 网络信息
        :param keypair_name: 密钥对名称
        :param flavor_info: 规格信息
        :param image_id: 镜像ID
        :param kafka_pwd: kafka密码
        :param monitor_on: 是否开启监控。1（是）/0（否）
        :param monitor_interval: 监控间隔
        :param kafka_nodes: kafka节点数
        :param safety_mgt: 安全管理打开（True）/关闭（False）
        :param anti_affinity: 节点反亲和
        :param kwargs:
        :return:

        """

        uri = "/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster"

        data = {
            "type": "kafka",
            "name": cluster_name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": "admin@123",
            "kafka_password": kafka_pwd,
            "description": kwargs['description'] if 'description' in kwargs.keys() else "",
            "whether_kerberos": safety_mgt,
            "whether_ranger": safety_mgt,
            "whether_audit": False,
            "whether_kms": safety_mgt,
            "whether_log": False,
            "whether_ha": True,
            "availability_zone": {
                "id": zone_info['id'],
                "name": zone_info['zone_name'],
                "virtType": zone_info['virt_type'],
            },
            "neutron_management_network_id": network_info['id'],
            "neutron_management_network_name": network_info['name'],
            "keypair_name": keypair_name,
            "anti_affinity": anti_affinity,
            "manager_virtual_ip": "",
            "service": [
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"],
                },
                {
                    "display": True,
                    "component": "KAFKA_EAGLE",
                    "relation": "",
                    "host_roles_default": [
                        "master"
                    ],
                    "optional_host_roles": [],
                    "hosts": [
                        "master-1",
                        "master-2"
                    ],
                    "service": "KAFKA"
                },
                {
                    "component": "AMBARI_SLAVE",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": [
                        "master"
                    ],
                    "hosts": [
                        "master-2"
                    ]
                }
            ],
            "monitor_interval": monitor_interval,
            "monitor_on": monitor_on,
            "node_flavor_list": [],
            "master": {
                "size": kafka_nodes - 1,
                "flavor_id": ""
            },
            "core": {
                "size": kafka_nodes - 2,
                "flavor_id": "",
            },
            "task": {
                "size": "0",
                "flavor_id": ""
            },
            "zookeeper": {
                "size": 0,
                "flavor_id": ""
            },
            "instanceInfo": [
                {
                    "roleNameList": ["master-1"],
                    "title": "Kafka实例",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                },
                {
                    "roleNameList": ["master-2"],
                    "title": "Kafka实例",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                },
                {
                    "roleNameList": ["core-1"],
                    "title": "Kafka实例",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                }
            ],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "imageId": image_id,
            "data_path": kwargs['/kafka-logs'] if 'data_path' in kwargs.keys() else "/kafka-logs",
            "log_path": kwargs['/var/log/kafka'] if 'log_path' in kwargs.keys() else "/var/log/kafka",
            "version": {
                "ZOOKEEPER": kwargs['versions']['zookeeper'],
                "KAFKA": kwargs['versions']['kafka']
            }
        }

        service_sub1 = {
            "display": True,
            "component": "KAFKA_BROKER",
            "relation": "",
            "host_roles_default": [
                "master",
                "core"
            ],
            "optional_host_roles": [],
            "hosts": [
                "master-1",
                "master-2",
                "core-1"
            ],
            "service": "KAFKA"
        }

        service_sub2 = {
            "display": True,
            "component": "ZOOKEEPER_SERVER",
            "relation": "",
            "host_roles_default": [
                "core",
                "master"
            ],
            "optional_host_roles": [],
            "hosts": [
                "core-1",
                "master-1",
                "master-2"
            ],
            "service": "ZOOKEEPER"
        }

        instance_subs = {
            "roleNameList": [],
            "title": "Kafka实例",
            "azoneId": zone_info['id'],
            "labelName": zone_info['label_name'],
            "azoneName": zone_info['zone_name'],
            "virtType": zone_info['virt_type'],
            "flavorId": flavor_info['id'],
            "name": flavor_info['name'],
            "storageTypeId": None,
            "fixIp": "",
            "fixManagementIp": "",
        }

        if kafka_nodes > 3:
            service_sub2['host_roles_default'].remove("master")
            service_sub2['hosts'].remove("master-1")
            service_sub2['hosts'].remove("master-2")

            for i in range(2, kafka_nodes - 1):
                service_sub1['hosts'].append("core-" + str(i))
                data['service'].append(service_sub1)
                service_sub2['hosts'].append("core-" + str(i))
                instance_subs['roleNameList'].append("core-" + str(i))
                data['instanceInfo'].append(instance_subs)

        data['service'].append(service_sub1)
        data['service'].append(service_sub2)

        if safety_mgt:
            for component in ("RANGER_ADMIN", "RANGER_USERSYNC"):
                ranger_sub = {
                    "display": True,
                    "component": component,
                    "relation": "",
                    "host_roles_default": [
                        "master"
                    ],
                    "optional_host_roles": [],
                    "hosts": [
                        "master-1",
                        "master-2"
                    ],
                    "service": "RANGER"
                }
                data['service'].append(ranger_sub)

        headers = self.ss.headers
        headers['servicename'] = 'kafka'
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def create_kafka_topic(self, cluster_name, cluster_id, virtual_ip, topic_name, partitions=1, replications=1):
        """
        创建topic

        :param cluster_name: 集群名称
        :param cluster_id: 集群ID
        :param virtual_ip: KAFKA vip
        :param topic_name: TOPIC
        :param partitions: 分区
        :param replications: 副本数
        :return:

        """

        uri = "/api/mqs/app/v1.0/kafka/manage/v1/kafka/topic/create"

        data = {
            "virtualIp": virtual_ip,
            "topicName": topic_name,
            "partitions": partitions,
            "replications": replications
        }

        headers = self.ss.headers
        headers['servicename'] = 'kafka'
        headers['clusterId'] = cluster_id
        headers['clusterName'] = cluster_name
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def get_kafka_topics_list(self, cluster_name, cluster_id, virtual_ip, page=1, size=10, **kwargs):
        """
        获取topic列表

        :param cluster_name: 集群名称
        :param cluster_id: 集群ID
        :param virtual_ip: KAFKA vip
        :param page: 页数
        :param size: 数据量
        :param kwargs:
        :return:

        """

        uri = f"/api/mqs/app/v1.0/kafka/manage/v1/kafka/topic/list?virtualIp={virtual_ip}&page={page}&size={size}"

        if kwargs:
            uri = uri + "&" + urlencode(kwargs)

        headers = self.ss.headers
        headers['servicename'] = 'kafka'
        headers['clusterId'] = cluster_id
        headers['clusterName'] = cluster_name
        response = self._get(uri=uri, headers=headers)
        return response

    def delete_kafka_topic(self, cluster_name, cluster_id, virtual_ip, topic_names: list):
        """
        删除topic

        :param cluster_name: 集群名称
        :param cluster_id: 集群ID
        :param virtual_ip: KAFKA vip
        :param topic_names: TOPIC 列表
        :return:

        """

        uri = "/api/mqs/app/v1.0/kafka/manage/v1/kafka/topic/delete"

        data = {
            "virtualIp": virtual_ip,
            "topicList": topic_names
        }

        headers = self.ss.headers
        headers['servicename'] = 'kafka'
        headers['clusterId'] = cluster_id
        headers['clusterName'] = cluster_name
        response = self._delete(uri=uri, data=data, headers=headers)
        return response

    def scale_kafka_cluster(self, servicename, cluster_id, cluster_name, zone_info, network_info, flavor_info,
                            node_count, **kwargs):
        """
        kafka主机扩容

        :param servicename: 服务名称 比如：zookeeper  rabbitmq
        :param cluster_id: 集群ID
        :param cluster_name: 集群名称
        :param zone_info: 可用域信息
        :param network_info: 网络信息
        :param flavor_info: 规格信息
        :param node_count: kafka扩容节点个数
        :param kwargs
        :return:

        """

        uri = f"/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster/{cluster_id}"

        data = {
            "expand": True,
            "node_count": str(node_count),
            "cluster_name": cluster_name,
            "flavor_id": flavor_info['id'],
            "storageTypeId": None,
            "node_processes": ["KAFKA_BROKER"],
            "instanceInfo": [],
            "clusterData": [],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "neutron_management_network_id": network_info['id'],
            "neutron_management_network_name": network_info['name'],
            "managerNetwork": network_info['id'],
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "quota": 100,
            "quotaText": "可用1000000000G / 全部1000000000G",
            "replicates": 1,
            "leader_count": 0,
            "extend_observer_count": 0
        }

        for i in range(node_count):
            sub_data = {
                "roleNameList": [],
                "title": "Kafka实例",
                "azoneId": zone_info['id'],
                "azoneName": zone_info['name'],
                "virtType": zone_info['virt_type'],
                "flavorId": flavor_info['id'],
                "storageTypeId": None,
                "onlyId": flavor_info['id'] + "_",
                "name": flavor_info['name'],
                "fixIp": "",
                "fixManagementIp": ""
            }
            sub_data['roleNameList'].append("extend-" + str(i + 1))
            data['instanceInfo'].append(sub_data)
            data['clusterData'].append(sub_data)

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def get_kafka_partitions_status(self, cluster_name, cluster_id, virtual_ip, topic_name, page=1, size=10):
        """
        获取kafka分区状态列表

        :param cluster_name: 集群名称
        :param cluster_id: 集群ID
        :param virtual_ip: KAFKA vip
        :param topic_name: topic名称
        :param page: 页数
        :param size: 数据量

        :return:

        """

        uri = f"/api/mqs/app/v1.0/kafka/manage/v1/kafka/topic/partition/info?virtualIp={virtual_ip}&topicName={topic_name}&page={page}&size={size}"

        headers = self.ss.headers
        headers['servicename'] = 'kafka'
        headers['clusterId'] = cluster_id
        headers['clusterName'] = cluster_name
        response = self._get(uri=uri, headers=headers)
        return response

    def alter_kafka_topic_partitions(self, cluster_name, cluster_id, virtual_ip, topic_name, steps):
        """
        修改kafka topic分区数

        :param cluster_name: 集群名称
        :param cluster_id: 集群ID
        :param virtual_ip: KAFKA vip
        :param topic_name: topic名称
        :param steps: 新增的分区数

        :return:

        """
        uri = "/api/mqs/app/v1.0/kafka/manage/v1/kafka/topic/partition/alter"

        data = {
            "virtualIp": virtual_ip,
            "topicName": topic_name,
            "partitions": steps
        }

        headers = self.ss.headers
        headers['servicename'] = 'kafka'
        headers['clusterId'] = cluster_id
        headers['clusterName'] = cluster_name
        response = self._put(uri=uri, data=data, headers=headers)
        return response

    def query_message(self, cluster_name, cluster_id, topic_name, offset_param, virtual_ip, partition_id=-1, topic_type="offset"):
        """
        获取kafka分区状态列表

        :param cluster_name: 集群名称
        :param cluster_id: 集群ID
        :param topic_name: topic名称
        :param offset_param: 起始偏移量
        :param virtual_ip: KAFKA vip
        :param partition_id: 分区ID
        :param topic_type: 类型：偏移量

        :return:

        """

        uri = f"/api/mqs/app/v1.0/kafka/manage/v1/kafka/topic/message?topicName={topic_name}&partitionId={partition_id}&type={topic_type}&param={offset_param}&virtualIp={virtual_ip}"

        headers = self.ss.headers
        headers['servicename'] = 'kafka'
        headers['clusterId'] = cluster_id
        headers['clusterName'] = cluster_name
        response = self._get(uri=uri, headers=headers)
        return response

    def get_consumer_group(self, cluster_name, cluster_id, virtual_ip, page=1, size=10, order="lagCount",
                           ascending_order="DESC", **kwargs):
        """
        获取kafka分区状态列表

        :param cluster_name: 集群名称
        :param cluster_id: 集群ID
        :param virtual_ip: KAFKA vip
        :param page: 页码
        :param size: 数据量
        :param order: 排序列。例如：lagCount（堆积量）
        :param ascending_order: 升序/降序
        :param kwargs: 例如，filterKey=topic_name
        :return:

        """

        uri = f"/api/mqs/app/v1.0/kafka/manage/v1/kafka/consumer/group/list?page={page}&size={size}&virtualIp={virtual_ip}&order={order}&ascendingOrder={ascending_order}"

        if kwargs:
            uri = uri + "&" + urlencode(kwargs)

        headers = self.ss.headers
        headers['servicename'] = 'kafka'
        headers['clusterId'] = cluster_id
        headers['clusterName'] = cluster_name
        response = self._get(uri=uri, headers=headers)
        return response

    def reset_offset(self, cluster_name, cluster_id, virtual_ip, group_id, topic_names, reset_type="latest", **kwargs):
        """
        重置偏移量

        :param cluster_name: 集群名称
        :param cluster_id: 集群ID
        :param virtual_ip: KAFKA vip
        :param group_id: GroupID
        :param topic_names: TOPIC列表
        :param reset_type: 重置类型。例如：从最新偏移量开始消费(latest)/从指定时间点的位移量开始消费(time)
        :param kwargs
        :return:

        """

        uri = "/api/mqs/app/v1.0/kafka/manage/v1/kafka/consumer/reset"

        data = {
            "virtualIp": virtual_ip,
            "groupId": group_id,
            "resetType": reset_type,
            "topics": topic_names
        }

        if reset_type == "time":
            data['param'] = kwargs['param']

        headers = self.ss.headers
        headers['servicename'] = 'kafka'
        headers['clusterId'] = cluster_id
        headers['clusterName'] = cluster_name
        response = self._put(uri=uri, data=data, headers=headers)
        return response

    def get_subscribe_list(self, cluster_name, cluster_id, virtual_ip, topic_name, page=1, size=10):
        """
        获取kafka分区状态列表

        :param cluster_name: 集群名称
        :param cluster_id: 集群ID
        :param virtual_ip: KAFKA vip
        :param topic_name: topic名称
        :param page: 分区ID
        :param size: 类型：偏移量
        :return:

        """

        uri = f"/api/mqs/app/v1.0/kafka/manage/v1/kafka/topic/subscribe?virtualIp={virtual_ip}&topicName={topic_name}&page={page}&size={size}"

        headers = self.ss.headers
        headers['servicename'] = 'kafka'
        headers['clusterId'] = cluster_id
        headers['clusterName'] = cluster_name
        response = self._get(uri=uri, headers=headers)
        return response

    def update_kafka_config(self, servicename, kafka_name, zookeeper_connect, kafka_eagle_db_url, **kwargs):
        """
        修改kafka配置

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param kafka_name: kafka名称
        :param zookeeper_connect: zookeeper_connect
        :param kafka_eagle_db_url: kafka_eagle_db_url
        :param kwargs:
        :return:
        """

        uri = f"/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{kafka_name}/update/configs"

        data = {
            "Clusters": {
                "desired_config": [{
                    "type": "kafka-broker",
                    "properties": {
                        "auto.create.topics.enable": "false",
                        "auto.leader.rebalance.enable": "true",
                        "compression.type": "producer",
                        "controlled.shutdown.enable": "true",
                        "controlled.shutdown.max.retries": "3",
                        "controlled.shutdown.retry.backoff.ms": "5000",
                        "controller.message.queue.size": "10",
                        "controller.socket.timeout.ms": "30000",
                        "default.replication.factor": "1",
                        "delete.topic.enable": "true",
                        "external.kafka.metrics.exclude.prefix": "kafka.network.RequestMetrics,kafka.server.DelayedOperationPurgatory,kafka.server.BrokerTopicMetrics.BytesRejectedPerSec",
                        "external.kafka.metrics.include.prefix": "\n            kafka.network.RequestMetrics.ResponseQueueTimeMs.request.OffsetCommit.98percentile,kafka.network.RequestMetrics.ResponseQueueTimeMs.request.Offsets.95percentile,kafka.network.RequestMetrics.ResponseSendTimeMs.request.Fetch.95percentile,kafka.network.RequestMetrics.RequestsPerSec.request",
                        "fetch.purgatory.purge.interval.requests": "10000",
                        "kafka.ganglia.metrics.group": "kafka",
                        "kafka.ganglia.metrics.host": "localhost",
                        "kafka.ganglia.metrics.port": "8671",
                        "kafka.ganglia.metrics.reporter.enabled": "true",
                        "kafka.metrics.reporters": "",
                        "kafka.timeline.metrics.host_in_memory_aggregation": "{{host_in_memory_aggregation}}",
                        "kafka.timeline.metrics.host_in_memory_aggregation_port": "{{host_in_memory_aggregation_port}}",
                        "kafka.timeline.metrics.host_in_memory_aggregation_protocol": "{{host_in_memory_aggregation_protocol}}",
                        "kafka.timeline.metrics.hosts": "{{ams_collector_hosts}}",
                        "kafka.timeline.metrics.maxRowCacheSize": "10000",
                        "kafka.timeline.metrics.port": "{{metric_collector_port}}",
                        "kafka.timeline.metrics.protocol": "{{metric_collector_protocol}}",
                        "kafka.timeline.metrics.reporter.enabled": "true",
                        "kafka.timeline.metrics.reporter.sendInterval": "5900",
                        "kafka.timeline.metrics.truststore.password": "{{metric_truststore_password}}",
                        "kafka.timeline.metrics.truststore.path": "{{metric_truststore_path}}",
                        "kafka.timeline.metrics.truststore.type": "{{metric_truststore_type}}",
                        "leader.imbalance.check.interval.seconds": "300",
                        "leader.imbalance.per.broker.percentage": "10",
                        "listeners": "PLAINTEXT://localhost:6667",
                        "log.cleanup.interval.mins": "10",
                        "log.dirs": "/kafka-logs",
                        "log.index.interval.bytes": "4096",
                        "log.index.size.max.bytes": "10485760",
                        "log.retention.bytes": "-1",
                        "log.retention.check.interval.ms": "600000",
                        "log.retention.hours": "168",
                        "log.roll.hours": "168",
                        "log.segment.bytes": "1073741824",
                        "message.max.bytes": "1000000",
                        "min.insync.replicas": "1",
                        "num.io.threads": "8",
                        "num.network.threads": "3",
                        "num.partitions": kwargs['num_partitions'] if 'num_partitions' in kwargs.keys() else "1",
                        "num.recovery.threads.per.data.dir": "1",
                        "num.replica.fetchers": "1",
                        "offset.metadata.max.bytes": "4096",
                        "offsets.commit.required.acks": "-1",
                        "offsets.commit.timeout.ms": "5000",
                        "offsets.load.buffer.size": "5242880",
                        "offsets.retention.check.interval.ms": "600000",
                        "offsets.retention.minutes": "86400000",
                        "offsets.topic.compression.codec": "0",
                        "offsets.topic.num.partitions": "50",
                        "offsets.topic.replication.factor": "3",
                        "offsets.topic.segment.bytes": "104857600",
                        "port": "6667",
                        "producer.metrics.enable": "false",
                        "producer.purgatory.purge.interval.requests": "10000",
                        "queued.max.requests": "500",
                        "replica.fetch.max.bytes": "1048576",
                        "replica.fetch.min.bytes": "1",
                        "replica.fetch.wait.max.ms": "500",
                        "replica.high.watermark.checkpoint.interval.ms": "5000",
                        "replica.lag.max.messages": "4000",
                        "replica.lag.time.max.ms": "10000",
                        "replica.socket.receive.buffer.bytes": "65536",
                        "replica.socket.timeout.ms": "30000",
                        "sasl.enabled.mechanisms": "GSSAPI",
                        "sasl.mechanism.inter.broker.protocol": "GSSAPI",
                        "security.inter.broker.protocol": "PLAINTEXT",
                        "socket.receive.buffer.bytes": "102400",
                        "socket.request.max.bytes": "104857600",
                        "socket.send.buffer.bytes": "102400",
                        "ssl.client.auth": "none",
                        "ssl.key.password": "",
                        "ssl.keystore.location": "",
                        "ssl.keystore.password": "",
                        "ssl.truststore.location": "",
                        "ssl.truststore.password": "",
                        "unclean.leader.election.enable": "false",
                        "zookeeper.connect": zookeeper_connect,
                        "zookeeper.connection.timeout.ms": "25000",
                        "zookeeper.session.timeout.ms": "30000",
                        "zookeeper.sync.time.ms": "2000"
                    },
                    "service_config_version_note": ""
                }, {
                    "type": "kafka-log4j",
                    "properties": {
                        "content": "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n      <!-- Licensed to the Apache Software Foundation (ASF) under one or more contributor license agreements.  See the NOTICE file distributed with this work for additional information regarding copyright ownership.  The ASF licenses this file to You under the Apache License, Version 2.0 (the \"License\"); you may not use this file except in compliance with the License.  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the License for the specific language governing permissions and limitations under the License.  -->\n\t  <Configuration>\n        <Appenders>\n\n          <Console name=\"Console\" target=\"SYSTEM_ERR\">\n            <PatternLayout>\n              <Pattern>\n                %d{yyyy-MM-dd HH:mm:ss.SSS} %-5p (%t) [%X{collection} %X{shard} %X{replica} %X{core}] %c{1.} %m%n\n              </Pattern>\n            </PatternLayout>\n          </Console>\n\n          <RollingFile\n              name=\"RollingFile\"\n              fileName=\"{{kafka_log_dir}}/user_${sys:user.name}/kafka.log\"\n              filePattern=\"{{kafka_log_bak_dir}}/user_${sys:user.name}/kafka-%d{yyyy-MM-dd}-%i.gz\">\n            <PatternLayout>\n              <Pattern>\n                %d{yyyy-MM-dd HH:mm:ss.SSS} %-5p (%t) [%X{collection} %X{shard} %X{replica} %X{core}] %c{1.} %m%n\n              </Pattern>\n            </PatternLayout>\n            <Policies>\n              <TimeBasedTriggeringPolicy interval=\"1\" modulate=\"true\"/>\n              <SizeBasedTriggeringPolicy size=\"{{kafka_log_maxfilesize}} MB\"/>\n            </Policies>\n            <DefaultRolloverStrategy max=\"{{kafka_log_maxbackup_oneday}}\">\n              <Delete basePath=\"{{kafka_log_bak_dir}}/user_${sys:user.name}\" maxDepth=\"3\">\n                <IfFileName glob=\"*.gz\" />\n                <IfLastModified age=\"{{kafka_log_maxbackup_days}}d\" />\n              </Delete>\n            </DefaultRolloverStrategy>\n          </RollingFile>\n\n        </Appenders>\n        <Loggers>\n          <Root level=\"{{kafka_log_level}}\">\n            <AppenderRef ref=\"RollingFile\"/>\n            <AppenderRef ref=\"Console\"/>\n          </Root>\n        </Loggers>\n      </Configuration>",
                        "kafka_log_level": "info",
                        "kafka_log_maxbackup_days": "10",
                        "kafka_log_maxbackup_oneday": "5",
                        "kafka_log_maxfilesize": "256"
                    },
                    "service_config_version_note": ""
                }, {
                    "type": "kafka-env",
                    "properties": {
                        "content": "\n            #!/bin/bash\n\n            # Set KAFKA specific environment variables here.\n\n            # The java implementation to use.\n            export JAVA_HOME={{java64_home}}\n            export PATH=$PATH:$JAVA_HOME/bin\n            export PID_DIR={{kafka_pid_dir}}\n            export LOG_DIR={{kafka_log_dir}}\n            export KE_HOME={{ke_home}}\n            export JMX_PORT=9998\n            {% if kerberos_security_enabled or kafka_other_sasl_enabled %}\n            export KAFKA_KERBEROS_PARAMS=\"-Djavax.security.auth.useSubjectCredsOnly=false {{kafka_kerberos_params}}\"\n            {% else %}\n            export KAFKA_KERBEROS_PARAMS={{kafka_kerberos_params}}\n            {% endif %}\n            # Add kafka sink to classpath and related depenencies\n            if [ -e \"/usr/lib/ambari-metrics-kafka-sink/ambari-metrics-kafka-sink.jar\" ]; then\n            export CLASSPATH=$CLASSPATH:/usr/lib/ambari-metrics-kafka-sink/ambari-metrics-kafka-sink.jar\n            export CLASSPATH=$CLASSPATH:/usr/lib/ambari-metrics-kafka-sink/lib/*\n            fi\n            if [ -f /etc/kafka/conf/kafka-ranger-env.sh ]; then\n            . /etc/kafka/conf/kafka-ranger-env.sh\n            fi",
                        "is_supported_kafka_ranger": "true",
                        "kafka_eagle_db_driver": "com.mysql.jdbc.Driver",
                        "kafka_eagle_db_pass": "SECRET:kafka-env:" + kwargs['num_partitions'] if 'num_partitions' in kwargs.keys() else "1" + ":kafka_eagle_db_pass",
                        "kafka_eagle_db_url": kafka_eagle_db_url,
                        "kafka_eagle_db_user": "mqs_iaas_cluster_user",
                        "kafka_log_bak_dir": "/var/log/kafka",
                        "kafka_log_dir": "/var/log/kafka",
                        "kafka_pid_dir": "/var/run/kafka",
                        "kafka_user": "kafka",
                        "kafka_user_nofile_limit": "128000",
                        "kafka_user_nproc_limit": "65536"
                    },
                    "service_config_version_note": ""
                }]
            }
        }

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._put(uri=uri, data=data, headers=headers)
        return response

    def restart_kafka_components(self, servicename, cluster_name, hosts, master_hosts, service_version="KAFKA"):
        """
        重启kafka组件

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param cluster_name: 集群名称
        :param hosts: 主机名
        :param master_hosts: master主机名
        :param service_version: 集群版本
        :return:
        """
        uri = f"/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/restart/all/effected/components"

        data = {
            "RequestInfo": {
                "command": "RESTART",
                "context": "Restart all components with Stale Configs for KAFKA",
                "operation_level": {
                    "level": "SERVICE",
                    "cluster_name": cluster_name,
                    "service_name": service_version
                }
            },
            "Requests/resource_filters": [
                {
                    "service_name": service_version,
                    "component_name": "KAFKA_BROKER",
                    "hosts": hosts
                },
                {
                    "service_name": service_version,
                    "component_name": "KAFKA_EAGLE",
                    "hosts": master_hosts
                }
            ]
        }

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def restart_kafka_cluster(self, servicename, cluster_name):
        """
        重启kafka集群

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param cluster_name: 集群名称
        :return:
        """
        uri = f"/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/service/KAFKA/start"

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._put(uri=uri, headers=headers)
        return response

    def get_restarted_kafka_cluster(self, servicename, cluster_name):
        """
        获取重启后kafka集群状态

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param cluster_name: 集群名称
        :return:
        """
        uri = f"/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/effected/components"

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def create_kafka_connector_cluster(self, cluster_name, zone_info, network_info, keypair_name, flavor_info, image_id,
                                       kafka_nodes=1, anti_affinity=False, **kwargs):

        """
        创建kafka数据同步集群

        :param cluster_name: 集群名称
        :param zone_info: 可用域信息
        :param network_info: 网络信息
        :param keypair_name: 密钥对名称
        :param flavor_info: 规格信息
        :param image_id: 镜像ID
        :param kafka_nodes: kafka节点数
        :param anti_affinity: 节点反亲和
        :param kwargs:
        :return:

        """

        uri = "/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster"

        data = {
            "type": "kafkaconnector",
            "name": cluster_name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": "admin@123",
            "administrator_confirm_password": "admin@123",
            "description": kwargs['description'] if 'description' in kwargs.keys() else "",
            "whether_ha": True if kafka_nodes > 2 else False,
            "availability_zone": {
                "id": zone_info['id'],
                "name": zone_info['zone_name'],
                "virtType": zone_info['virt_type'],
            },
            "neutron_management_network_id": network_info['id'],
            "neutron_management_network_name": network_info['name'],
            "keypair_name": keypair_name,
            "anti_affinity": anti_affinity,
            "manager_virtual_ip": "",
            "service": [{
                "component": "AMBARI",
                "display": False,
                "service": "AMBARI",
                "relation": "",
                "host_roles_default": ["master"],
                "hosts": ["master-1"]
            }],
            "monitor_interval": "",
            "monitor_on": 1,
            "node_flavor_list": [],
            "master": {
                "size": 2,
                "flavor_id": ""
            },
            "core": {
                "size": (kafka_nodes - 2) if kafka_nodes >= 3 else 0,
                "flavor_id": ""
            },
            "task": {
                "size": "0",
                "flavor_id": ""
            },
            "zookeeper": {
                "size": 0,
                "flavor_id": ""
            },
            "instanceInfo": [{
                "roleNameList": ["master-1"],
                "title": "数据同步实例",
                "azoneId": zone_info['id'],
                "labelName": zone_info['label_name'],
                "azoneName": zone_info['zone_name'],
                "virtType": zone_info['virt_type'],
                "flavorId": flavor_info['id'],
                "name": flavor_info['name'],
                "storageTypeId": None,
                "fixIp": "",
                "fixManagementIp": ""
            }],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "imageId": image_id,
            "version": {
                "KAFKA-CONNECTOR": kwargs['versions']['kafka']
            },
            "datasync_config": {}
        }

        service_sub1 = {
            "display": True,
            "component": "CONNECTOR",
            "relation": "",
            "host_roles_default": ["master"],
            "optional_host_roles": [],
            "hosts": ["master-1"],
            "service": "KAFKACONNECTOR"
        }

        service_sub2 = {
            "component": "AMBARI_SLAVE",
            "display": False,
            "service": "AMBARI",
            "relation": "",
            "host_roles_default": ["master"],
            "hosts": ["master-2"]
        }

        instance_sub1 = {
            "roleNameList": ["master-2"],
            "title": "数据同步实例",
            "azoneId": zone_info['id'],
            "labelName": zone_info['label_name'],
            "azoneName": zone_info['zone_name'],
            "virtType": zone_info['virt_type'],
            "flavorId": flavor_info['id'],
            "name": flavor_info['name'],
            "storageTypeId": None,
            "fixIp": "",
            "fixManagementIp": "",
        }

        if kafka_nodes >= 2:
            service_sub1['hosts'].append("master-2")
            data['service'].append(service_sub2)
            data['instanceInfo'].append(instance_sub1)

            if kafka_nodes > 2:
                service_sub1['host_roles_default'].append("core")

            for i in range(3, kafka_nodes + 1):
                service_sub1['hosts'].append("core-" + str(i - 2))

                instance_sub2 = {
                    "roleNameList": [],
                    "title": "数据同步实例",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                }

                instance_sub2['roleNameList'].append("core-" + str(i - 2))
                data['instanceInfo'].append(instance_sub2)

        data['service'].append(service_sub1)

        headers = self.ss.headers
        headers['servicename'] = 'kafkaconnector'
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def get_kafka_connector_cluster_detail(self, servicename, cluster_id, cluster_name, cluster_ip, src_cluster_url,
                                           source_kerberos=False):
        """
        获取数据同步集群详情

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param cluster_id: 集群ID
        :param cluster_name: 集群名称
        :param cluster_ip: 集群IP
        :param src_cluster_url: 源集群url
        :param source_kerberos:
        :return:
        """
        uri = f"/api/mqs/app/v1.0/kafka/datasync/v1/datasync/kafka/task/list/{cluster_id}?clusterName={cluster_name}" \
            f"&clusterIp={cluster_ip}&sourceClusterId=&sourceDriverUrl={src_cluster_url}&sourceKerberos={source_kerberos}"

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_kafka_data_sync_status(self, servicename, kafka_url, cluster_ip):
        """
        数据同步集群连接测试

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param kafka_url: 集群连接url
        :param cluster_ip: 集群IP
        :return:
        """
        uri = f"/api/mqs/app/v1.0/kafka/datasync/v1/datasync/kafka/link/network/state?kafkaUrl={kafka_url}&clusterIp={cluster_ip}"

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def residue_kafka(self, servicename, kafka_url, cluster_ip):
        """
        数据同步时清理kafka集群的残留数据

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param kafka_url: 集群连接url
        :param cluster_ip: 集群IP
        :return:
        """
        uri = f"/api/mqs/app/v1.0/kafka/datasync/v1/datasync/kafka/link/clean/residue?kafkaUrl={kafka_url}&clusterIp={cluster_ip}&type=source&cleanTrust=true"

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._post(uri=uri, headers=headers)
        return response

    def synchronize_kafka_config(self, cluster_info, src_cluster_info, des_cluster_info, local_cluster,
                                 kafka_sync_all=True, sync_task=True, **kwargs):

        """
        kafka数据同步配置

        :param cluster_info: 集群信息
        :param src_cluster_info: 源kafka信息。包括id, url
        :param des_cluster_info: 目的kafka信息。包括id, url
        :param local_cluster: 是否本平台集群。源&目的端都是本平台集群（0）/源本平台&目的端非本平台（1）/源非本平台&目的端本平台（2）
        :param kafka_sync_all: 同步topics
        :param sync_task: 是否同步对象。是（True）/ 否（False）
        :param kwargs
        :return:

        """

        uri = "/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster/connector/config"

        data = {
            "clusterIp": cluster_info['ip'],
            "kafkaConnectorName": cluster_info['name'],
            "clusterId": cluster_info['id'],
            "kafkaSourceClusterId": "",
            "kafkaSourceClusterName": "",
            "kafkaSourceClusterAlias": src_cluster_info['alias'],
            "kafkaSourceClusterAddress": src_cluster_info['url'],
            "kafkaSourceKerberos": False,
            "kafkaTargetClusterId": "",
            "kafkaTargetClusterName": "",
            "kafkaTargetClusterAlias": des_cluster_info['alias'],
            "kafkaTargetClusterAddress": des_cluster_info['url'],
            "kafkaTargetKerberos": False,
            "syncTaskEnable": sync_task,
            "kafkaSyncAll": kafka_sync_all,
            "kafkaTopics": kwargs['topics'] if 'topics' in kwargs.keys() else "",
            "taskName": cluster_info['name']
        }

        if local_cluster == 0:
            data['kafkaSourceClusterId'] = src_cluster_info['id']
            data['kafkaSourceClusterName'] = src_cluster_info['name']
            data['kafkaTargetClusterId'] = des_cluster_info['id']
            data['kafkaTargetClusterName'] = des_cluster_info['name']
        if local_cluster == 1:
            data['kafkaSourceClusterId'] = src_cluster_info['id']
            data['kafkaSourceClusterName'] = src_cluster_info['name']
        if local_cluster == 2:
            data['kafkaTargetClusterId'] = des_cluster_info['id']
            data['kafkaTargetClusterName'] = des_cluster_info['name']

        headers = self.ss.headers
        headers['servicename'] = 'kafkaconnector'
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def check_kafka_data_sync_task(self, servicename, cluster_id, kafka_url):
        """
        检查同步任务是否存在

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param cluster_id: 集群ID
        :param kafka_url: 集群连接url

        :return:
        """
        uri = f"/api/mqs/app/v1.0/kafka/datasync/v1/datasync/kafka/task/check/exist/task?clusterId={cluster_id}&sourceDriverUrl={kafka_url}"

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def get_kafka_data_sync_topics(self, servicename, cluster_id, kafka_url, cluster_ip, source_kerberos=False,
                                   mqs_version="E5135-V500R001B01D007_RC719"):
        """
        检查同步任务是否存在

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param cluster_id: 集群ID
        :param kafka_url: 集群连接url
        :param cluster_ip: 集群IP
        :param source_kerberos: 是否同步全部topic
        :param mqs_version:  中间件版本

        :return:
        """
        uri = f"/api/mqs/app/v1.0/kafka/datasync/v1/datasync/kafka/task/source/notsync/topics?clusterId={cluster_id}" \
            f"&sourceDriverUrl={kafka_url}&clusterIp={cluster_ip}&sourceKerberos={source_kerberos}&mqsVersion={mqs_version}"

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = self._get(uri=uri, headers=headers)
        return response

    def create_synchronize_kafka_task(self, task_name, cluster_info, src_cluster_info, des_cluster_info, sync_all=True,
                                      **kwargs):

        """
        创建数据同步任务

        :param task_name: 任务名称
        :param cluster_info: 集群信息
        :param src_cluster_info: 源kafka信息。包括id, url
        :param des_cluster_info: 目的kafka信息。包括id, url
        :param sync_all: 是否同步全部topics
        :param kwargs
        :return:

        """

        uri = "/api/mqs/app/v1.0/kafka/datasync/v1/datasync/kafka/task"

        data = {
            "clusterId": cluster_info['id'],
            "taskName": task_name,
            "syncAll": sync_all,
            "clusterIp": cluster_info['ip'],
            "sourceClusterId": src_cluster_info['id'],
            "targetBootstrapServers": des_cluster_info['url'],
            "sourceClusterAlias": src_cluster_info['alias'],
            "targetClusterAlias": des_cluster_info['alias'],
            "sourceTopic": kwargs['topics'] if 'topics' in kwargs.keys() else "",
            "sourceKerberos": False,
            "targeteKerberos": False,
            "sourceBootstrapServers": src_cluster_info['url']
        }

        headers = self.ss.headers
        headers['servicename'] = 'kafkaconnector'
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def delete_synchronize_kafka_task(self, task_name, cluster_ip, cluster_id):

        """
        删除数据同步任务

        :param task_name: 任务名称
        :param cluster_ip: 集群IP
        :param cluster_id: 集群ID
        :return:

        """

        uri = f"/api/mqs/app/v1.0/kafka/datasync/v1/datasync/kafka/task/delete/{task_name}?clusterIp={cluster_ip}&clusterId={cluster_id}"

        headers = self.ss.headers
        headers['servicename'] = 'kafkaconnector'
        response = self._delete(uri=uri, headers=headers)
        return response

    def restart_synchronize_kafka_task(self, task_name, cluster_ip):

        """
        重启数据同步任务

        :param task_name: 任务名称
        :param cluster_ip: 集群IP
        :return:

        """

        uri = f"/api/mqs/app/v1.0/kafka/datasync/v1/datasync/kafka/task/restart/{task_name}?clusterIp={cluster_ip}"

        data = {}

        headers = self.ss.headers
        headers['servicename'] = 'kafkaconnector'
        response = self._put(uri=uri, data=data, headers=headers)
        return response

    def action_synchronize_kafka_connector(self, servicename, cluster_name, action):

        """
        停止/ 开启/ 重启数据同步组件

        :param servicename: 服务名称 例如：kafaka、rabbitmq等
        :param cluster_name: 数据同步集群名称
        :param action: 操作。例如，停止(stop)/ 开启(start)/ 重启(restart)
        :return:

        """

        uri = f"/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/service/CONNECTOR/{action}"

        headers = self.ss.headers
        headers['servicename'] = servicename
        response = None
        if action in ["start", "stop"]:
            response = self._put(uri=uri, headers=headers)
        if action in ["restart"]:
            response = self._post(uri=uri, headers=headers)

        return response

    def apply_for_create_kafka_cluster(self, cluster_name, zone_info, network_info, keypair_name, flavor_info, image_id,
                                       kafka_pwd, monitor_on=1, monitor_interval="15s", kafka_nodes=3, safety_mgt=False,
                                       anti_affinity=False, **kwargs):

        """
        普通用户申请创建kafka虚拟机集群

        :param cluster_name: 集群名称
        :param zone_info: 可用域信息
        :param network_info: 网络信息
        :param keypair_name: 密钥对名称
        :param flavor_info: 规格信息
        :param image_id: 镜像ID
        :param kafka_pwd: kafka密码
        :param monitor_on: 是否开启监控。1（是）/0（否）
        :param monitor_interval: 监控间隔
        :param kafka_nodes: kafka节点数
        :param safety_mgt: 安全管理打开（True）/关闭（False）
        :param anti_affinity: 节点反亲和
        :param kwargs:
        :return:

        """

        uri = "/api/mqs/app/v1.0/cluster/deployment/v1/deployment/cluster/iaas/process"

        data = {
            "type": "kafka",
            "name": cluster_name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": "admin@123",
            "kafka_password": kafka_pwd,
            "description": kwargs['description'] if 'description' in kwargs.keys() else "",
            "whether_kerberos": safety_mgt,
            "whether_ranger": safety_mgt,
            "whether_audit": False,
            "whether_kms": safety_mgt,
            "whether_log": False,
            "whether_ha": True,
            "availability_zone": {
                "id": zone_info['id'],
                "name": zone_info['zone_name'],
                "virtType": zone_info['virt_type'],
            },
            "neutron_management_network_id": network_info['id'],
            "neutron_management_network_name": network_info['name'],
            "keypair_name": keypair_name,
            "anti_affinity": anti_affinity,
            "manager_virtual_ip": "",
            "service": [
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"],
                },
                {
                    "display": True,
                    "component": "KAFKA_EAGLE",
                    "relation": "",
                    "host_roles_default": [
                        "master"
                    ],
                    "optional_host_roles": [],
                    "hosts": [
                        "master-1",
                        "master-2"
                    ],
                    "service": "KAFKA"
                },
                {
                    "component": "AMBARI_SLAVE",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": [
                        "master"
                    ],
                    "hosts": [
                        "master-2"
                    ]
                }
            ],
            "monitor_interval": monitor_interval,
            "monitor_on": monitor_on,
            "node_flavor_list": [],
            "master": {
                "size": kafka_nodes - 1,
                "flavor_id": ""
            },
            "core": {
                "size": kafka_nodes - 2,
                "flavor_id": "",
            },
            "task": {
                "size": "0",
                "flavor_id": ""
            },
            "zookeeper": {
                "size": 0,
                "flavor_id": ""
            },
            "instanceInfo": [
                {
                    "roleNameList": ["master-1"],
                    "title": "Kafka实例",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                },
                {
                    "roleNameList": ["master-2"],
                    "title": "Kafka实例",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                },
                {
                    "roleNameList": ["core-1"],
                    "title": "Kafka实例",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                }
            ],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "imageId": image_id,
            "data_path": kwargs['/kafka-logs'] if 'data_path' in kwargs.keys() else "/kafka-logs",
            "log_path": kwargs['/var/log/kafka'] if 'log_path' in kwargs.keys() else "/var/log/kafka",
            "version": {
                "ZOOKEEPER": kwargs['versions']['zookeeper'],
                "KAFKA": kwargs['versions']['kafka']
            }
        }

        service_sub1 = {
            "display": True,
            "component": "KAFKA_BROKER",
            "relation": "",
            "host_roles_default": [
                "master",
                "core"
            ],
            "optional_host_roles": [],
            "hosts": [
                "master-1",
                "master-2",
                "core-1"
            ],
            "service": "KAFKA"
        }

        service_sub2 = {
            "display": True,
            "component": "ZOOKEEPER_SERVER",
            "relation": "",
            "host_roles_default": [
                "core",
                "master"
            ],
            "optional_host_roles": [],
            "hosts": [
                "core-1",
                "master-1",
                "master-2"
            ],
            "service": "ZOOKEEPER"
        }

        instance_subs = {
            "roleNameList": [],
            "title": "Kafka实例",
            "azoneId": zone_info['id'],
            "labelName": zone_info['label_name'],
            "azoneName": zone_info['zone_name'],
            "virtType": zone_info['virt_type'],
            "flavorId": flavor_info['id'],
            "name": flavor_info['name'],
            "storageTypeId": None,
            "fixIp": "",
            "fixManagementIp": "",
        }

        if kafka_nodes > 3:
            service_sub2['host_roles_default'].remove("master")
            service_sub2['hosts'].remove("master-1")
            service_sub2['hosts'].remove("master-2")

            for i in range(2, kafka_nodes - 1):
                service_sub1['hosts'].append("core-" + str(i))
                data['service'].append(service_sub1)
                service_sub2['hosts'].append("core-" + str(i))
                instance_subs['roleNameList'].append("core-" + str(i))
                data['instanceInfo'].append(instance_subs)

        data['service'].append(service_sub1)
        data['service'].append(service_sub2)

        if safety_mgt:
            for component in ("RANGER_ADMIN", "RANGER_USERSYNC"):
                ranger_sub = {
                    "display": True,
                    "component": component,
                    "relation": "",
                    "host_roles_default": [
                        "master"
                    ],
                    "optional_host_roles": [],
                    "hosts": [
                        "master-1",
                        "master-2"
                    ],
                    "service": "RANGER"
                }
                data['service'].append(ranger_sub)

        headers = self.ss.headers
        headers['servicename'] = 'kafka'
        response = self._post(uri=uri, json=data, headers=headers)
        return response

    def apply_for_create_kafka_connector_cluster(self, cluster_name, zone_info, network_info, keypair_name, flavor_info,
                                                 image_id, kafka_nodes=1, anti_affinity=False, **kwargs):

        """
        申请创建kafka数据同步集群

        :param cluster_name: 集群名称
        :param zone_info: 可用域信息
        :param network_info: 网络信息
        :param keypair_name: 密钥对名称
        :param flavor_info: 规格信息
        :param image_id: 镜像ID
        :param kafka_nodes: kafka节点数
        :param anti_affinity: 节点反亲和
        :param kwargs:
        :return:

        """

        uri = "/api/mqs/app/v1.0/cluster/deployment/v1/deployment/cluster/iaas/process"

        data = {
            "type": "kafkaconnector",
            "name": cluster_name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": "admin@123",
            "administrator_confirm_password": "admin@123",
            "description": kwargs['description'] if 'description' in kwargs.keys() else "",
            "whether_ha": True if kafka_nodes > 2 else False,
            "availability_zone": {
                "id": zone_info['id'],
                "name": zone_info['zone_name'],
                "virtType": zone_info['virt_type'],
            },
            "neutron_management_network_id": network_info['id'],
            "neutron_management_network_name": network_info['name'],
            "keypair_name": keypair_name,
            "anti_affinity": anti_affinity,
            "manager_virtual_ip": "",
            "service": [{
                "component": "AMBARI",
                "display": False,
                "service": "AMBARI",
                "relation": "",
                "host_roles_default": ["master"],
                "hosts": ["master-1"]
            }],
            "monitor_interval": "",
            "monitor_on": 1,
            "node_flavor_list": [],
            "master": {
                "size": 2,
                "flavor_id": ""
            },
            "core": {
                "size": (kafka_nodes - 2) if kafka_nodes >= 3 else 0,
                "flavor_id": ""
            },
            "task": {
                "size": "0",
                "flavor_id": ""
            },
            "zookeeper": {
                "size": 0,
                "flavor_id": ""
            },
            "instanceInfo": [{
                "roleNameList": ["master-1"],
                "title": "数据同步实例",
                "azoneId": zone_info['id'],
                "labelName": zone_info['label_name'],
                "azoneName": zone_info['zone_name'],
                "virtType": zone_info['virt_type'],
                "flavorId": flavor_info['id'],
                "name": flavor_info['name'],
                "storageTypeId": None,
                "fixIp": "",
                "fixManagementIp": ""
            }],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "imageId": image_id,
            "version": {
                "KAFKA-CONNECTOR": kwargs['versions']['kafka']
            },
            "datasync_config": {}
        }

        service_sub1 = {
            "display": True,
            "component": "CONNECTOR",
            "relation": "",
            "host_roles_default": ["master"],
            "optional_host_roles": [],
            "hosts": ["master-1"],
            "service": "KAFKACONNECTOR"
        }

        service_sub2 = {
            "component": "AMBARI_SLAVE",
            "display": False,
            "service": "AMBARI",
            "relation": "",
            "host_roles_default": ["master"],
            "hosts": ["master-2"]
        }

        instance_sub1 = {
            "roleNameList": ["master-2"],
            "title": "数据同步实例",
            "azoneId": zone_info['id'],
            "labelName": zone_info['label_name'],
            "azoneName": zone_info['zone_name'],
            "virtType": zone_info['virt_type'],
            "flavorId": flavor_info['id'],
            "name": flavor_info['name'],
            "storageTypeId": None,
            "fixIp": "",
            "fixManagementIp": "",
        }

        if kafka_nodes >= 2:
            service_sub1['hosts'].append("master-2")
            data['service'].append(service_sub2)
            data['instanceInfo'].append(instance_sub1)

            if kafka_nodes > 2:
                service_sub1['host_roles_default'].append("core")

            for i in range(3, kafka_nodes + 1):
                service_sub1['hosts'].append("core-" + str(i - 2))

                instance_sub2 = {
                    "roleNameList": [],
                    "title": "数据同步实例",
                    "azoneId": zone_info['id'],
                    "labelName": zone_info['label_name'],
                    "azoneName": zone_info['zone_name'],
                    "virtType": zone_info['virt_type'],
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                }

                instance_sub2['roleNameList'].append("core-" + str(i - 2))
                data['instanceInfo'].append(instance_sub2)

        data['service'].append(service_sub1)

        headers = self.ss.headers
        headers['servicename'] = 'kafkaconnector'
        response = self._post(uri=uri, json=data, headers=headers)
        return response