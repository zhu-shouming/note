from scripts.apis.handler_mqs import *


def create_kafka_vm_cluster(paas_client: PAASClient, cluster_name, label_name, net_name, kp_name, flavor, kafka_pwd,
                            kafka_nodes=3, safety_mgt=False, anti_affinity=False, **kwargs):
    """ 创建kafka虚拟机集群 """
    with allure.step("create_kafka_vm_cluster()"):
        with allure.step("1.查询kafka&zookeeper版本信息"):
            service_response = paas_client.mqs_client.get_deploy_service("kafka")
            check_status_code(service_response)
            zk_info = get_value_from_json(service_response, f"$...componentList[?(@.server_display_name=='ZooKeeper')]")
            kafka_info = get_value_from_json(service_response,
                                             f"$...componentList[?(@.server_display_name=='Kafka')]")
            assert (zk_info and kafka_info), "未找到zk或者kafka的版本信息"
            versions = {
                'zookeeper': zk_info['server_version'],
                'kafka': kafka_info['server_version']
            }
        with allure.step("1.查询网络信息"):
            prepare_info_response = paas_client.mqs_client.get_prepare_info('kafka')
            check_status_code(prepare_info_response)
            zone_info = get_value_from_json(prepare_info_response, f"$..azones[?(@.labelName=='{label_name}')]")
            network_info = get_value_from_json(prepare_info_response, f"$..networkAndAzone[?(@.networkName=='{net_name}')]")
            keypair_name = get_value_from_json(prepare_info_response, f"$..keypairs[?(@.name=='{kp_name}')]")
            assert (zone_info and network_info and keypair_name), f"未找到 {label_name} 或 {net_name} 或 {kp_name}"
            zone_info = {
                "id": zone_info['id'],
                "label_name": zone_info['labelName'],
                "zone_name": zone_info['zone'],
                "virt_type": zone_info['virtType']
            }

            network_info = {
                "id": network_info['networkId'],
                "name": network_info['networkName']
            }

            keypair_name = keypair_name['name']
        with allure.step("2.查询规格信息"):
            flavor_info_response = paas_client.mqs_client.get_prepare_flavor('zookeeper', zone_info['id'])
            check_status_code(flavor_info_response)
            flavor_info = get_value_from_json(flavor_info_response, f"$..virtual[?(@.name=='{flavor}')]")
            assert flavor_info, f"未找到规格：{flavor_info}"
            flavor_info = {
                "id": flavor_info['id'],
                "name": flavor_info['name']
            }
        with allure.step("3.查询缺省镜像信息"):
            image_info_response = paas_client.mqs_client.get_default_image_info('zookeeper')
            check_status_code(image_info_response)
            image_id = image_info_response.json()['data']['imageId']
        with allure.step("4.创建kafka虚拟机集群"):
            create_response = paas_client.kafka_client.create_kafka_cluster(cluster_name, zone_info, network_info,
                                                                            keypair_name, flavor_info, image_id,
                                                                            kafka_pwd, versions=versions)
            check_status_code(create_response)


def apply_for_create_kafka_vm_cluster(paas_client: PAASClient, cluster_name, label_name, net_name, kp_name, flavor,
                                      kafka_pwd, kafka_nodes=3, safety_mgt=False, anti_affinity=False, **kwargs):
    """ 申请创建kafka虚拟机集群 """
    with allure.step("apply_for_create_kafka_vm_cluster()"):
        with allure.step("1.查询kafka&zookeeper版本信息"):
            service_response = paas_client.mqs_client.get_deploy_service("kafka")
            check_status_code(service_response)
            zk_info = get_value_from_json(service_response, f"$...componentList[?(@.server_display_name=='ZooKeeper')]")
            kafka_info = get_value_from_json(service_response,
                                             f"$...componentList[?(@.server_display_name=='Kafka')]")
            assert (zk_info and kafka_info), "未找到zk或者kafka的版本信息"
            versions = {
                'zookeeper': zk_info['server_version'],
                'kafka': kafka_info['server_version']
            }
        with allure.step("1.查询网络信息"):
            prepare_info_response = paas_client.mqs_client.get_prepare_info('kafka')
            check_status_code(prepare_info_response)
            zone_info = get_value_from_json(prepare_info_response, f"$..azones[?(@.labelName=='{label_name}')]")
            network_info = get_value_from_json(prepare_info_response, f"$..networkAndAzone[?(@.networkName=='{net_name}')]")
            keypair_name = get_value_from_json(prepare_info_response, f"$..keypairs[?(@.name=='{kp_name}')]")
            assert (zone_info and network_info and keypair_name), f"未找到 {label_name} 或 {net_name} 或 {kp_name}"
            zone_info = {
                "id": zone_info['id'],
                "label_name": zone_info['labelName'],
                "zone_name": zone_info['zone'],
                "virt_type": zone_info['virtType']
            }

            network_info = {
                "id": network_info['networkId'],
                "name": network_info['networkName']
            }

            keypair_name = keypair_name['name']
        with allure.step("2.查询规格信息"):
            flavor_info_response = paas_client.mqs_client.get_prepare_flavor('zookeeper', zone_info['id'])
            check_status_code(flavor_info_response)
            flavor_info = get_value_from_json(flavor_info_response, f"$..virtual[?(@.name=='{flavor}')]")
            assert flavor_info, f"未找到规格：{flavor_info}"
            flavor_info = {
                "id": flavor_info['id'],
                "name": flavor_info['name']
            }
        with allure.step("3.查询缺省镜像信息"):
            image_info_response = paas_client.mqs_client.get_default_image_info('zookeeper')
            check_status_code(image_info_response)
            image_id = image_info_response.json()['data']['imageId']
        with allure.step("4.申请创建kafka虚拟机集群"):
            apply_response = paas_client.kafka_client.apply_for_create_kafka_cluster(cluster_name, zone_info,
                                                                                     network_info, keypair_name,
                                                                                     flavor_info, image_id, kafka_pwd,
                                                                                     versions=versions)
            check_status_code(apply_response)


def create_kafka_topic(paas_client: PAASClient, service_name, cluster_name, topic_name, partitions=1, replications=1):
    """ 创建kafka topic """
    kafka_info = get_cluster_detail(paas_client, service_name, cluster_name)
    assert kafka_info, f"未找到{cluster_name}"
    cluster_id = kafka_info['data']['id']
    kafka_vip = kafka_info['data']['realIp']
    created_response = paas_client.kafka_client.create_kafka_topic(cluster_name, cluster_id, kafka_vip, topic_name,
                                                                   partitions=1, replications=1)
    check_status_code(created_response)


def get_kafka_topic_by_name(paas_client: PAASClient, service_name, cluster_name, topic_name=""):
    """ 搜索kafka topic """
    kafka_info = get_cluster_detail(paas_client, service_name, cluster_name)
    assert kafka_info, f"未找到{cluster_name}"
    cluster_id = kafka_info['data']['id']
    kafka_vip = kafka_info['data']['realIp']
    topic_response = paas_client.kafka_client.get_kafka_topics_list(cluster_name, cluster_id, kafka_vip, page=1,
                                                                    size=100, topicName=topic_name)

    check_status_code(topic_response)
    if topic_name == "":
        topic_info = topic_response.json()
    else:
        topic_info = get_value_from_json(topic_response, f"$.data[?(@.topicName=='{topic_name}')]")
    return topic_info


def delete_kafka_topic(paas_client: PAASClient, service_name, cluster_name, topic_names):
    """ 删除kafka topic """
    kafka_info = get_cluster_detail(paas_client, service_name, cluster_name)
    assert kafka_info, f"未找到{cluster_name}"
    cluster_id = kafka_info['data']['id']
    kafka_vip = kafka_info['data']['realIp']
    deleted_response = paas_client.kafka_client.delete_kafka_topic(cluster_name, cluster_id, kafka_vip, topic_names)
    check_status_code(deleted_response)
    for name in topic_names:
        topic_info = get_kafka_topic_by_name(paas_client, service_name, cluster_name, name)
        assert not topic_info, f"未删除topic：{name}"


def scale_kafka_cluster(paas_client: PAASClient, service_name, cluster_name, node_count, **kwargs):
    """ kafka集群主机扩容 """
    with allure.step("scale_kafka_cluster()"):
        with allure.step("1. 选择集群"):
            cluster_info = get_cluster_by_name(paas_client, service_name, cluster_name)
            assert cluster_info, f"未找到 {cluster_name}"
            cluster_id = cluster_info['id']
            cluster_detail_response = paas_client.mqs_client.get_bigdata_cluster_detail(service_name, cluster_id)
            check_status_code(cluster_detail_response)
            cluster_detail = cluster_detail_response.json()['data']
            zone_info = {
                "id": cluster_detail['availabilityZone']['id'],
                "name": cluster_detail['availabilityZone']['zone'],
                "virt_type": cluster_detail['availabilityZone']['virtType']
            }
            network_info = {
                "id": cluster_detail['neutronManagementNetwork'],
                "name": cluster_detail['neutronManagementNetworkName']
            }
            flavor_info = {
                "id": cluster_detail['nodeGroups'][0]['flavorId'],
                "name": str(cluster_detail['nodeGroups'][0]['cpu']) + "*" + str(int(cluster_detail['nodeGroups'][0]['ram']/1024))
                        + "*" + str(cluster_detail['nodeGroups'][0]['disk'])
            }
        with allure.step("2.扩容"):
            scale_response = paas_client.kafka_client.scale_kafka_cluster(service_name, cluster_id, cluster_name,
                                                                          zone_info, network_info, flavor_info,
                                                                          node_count, **kwargs)
            check_status_code(scale_response)
            result = scale_response.json()
            assert result['code'] == "", f"扩容失败。{result['msg']}"


def get_kafka_partitions_status(paas_client: PAASClient, cluster_name, topic_name):
    """ 获取kafka集群topic分区状态 """
    with allure.step("get_kafka_partitions_status()"):
        with allure.step("1. 查询集群信息"):
            kafka_info = get_cluster_detail(paas_client, "kafka", cluster_name)
            assert kafka_info, f"未找到{cluster_name}"
            cluster_id = kafka_info['data']['id']
            kafka_vip = kafka_info['data']['realIp']
        with allure.step("2. 获取指定topic分区状态"):
            partitions_status_response = paas_client.kafka_client.get_kafka_partitions_status(cluster_name, cluster_id,
                                                                                              kafka_vip, topic_name)
            check_status_code(partitions_status_response)
            return partitions_status_response.json()


def alter_kafka_topic_partitions(paas_client: PAASClient, cluster_name, topic_name, steps):
    """ 修改kafka topic分区数 """
    with allure.step("alter_kafka_topic_partitions()"):
        with allure.step("1. 查询集群信息"):
            kafka_info = get_cluster_detail(paas_client, "kafka", cluster_name)
            assert kafka_info, f"未找到{cluster_name}"
            cluster_id = kafka_info['data']['id']
            kafka_vip = kafka_info['data']['realIp']
        with allure.step("2. 修改kafka topic分区数"):
            partitions_status_response = paas_client.kafka_client.alter_kafka_topic_partitions(cluster_name, cluster_id,
                                                                                               kafka_vip, topic_name,
                                                                                               steps)
            check_status_code(partitions_status_response)


def get_kafka_consumer_group(paas_client: PAASClient, cluster_name, **kwargs):
    """ 获取kafka消费者组 """
    with allure.step("get_kafka_consumer_group()"):
        with allure.step("1. 查询集群信息"):
            kafka_info = get_cluster_detail(paas_client, "kafka", cluster_name)
            assert kafka_info, f"未找到{cluster_name}"
            cluster_id = kafka_info['data']['id']
            kafka_vip = kafka_info['data']['realIp']
        with allure.step("2. 获取kafka消费者组"):
            cg_info_response = paas_client.kafka_client.get_consumer_group(cluster_name, cluster_id, kafka_vip, **kwargs)
            check_status_code(cg_info_response)
            return cg_info_response.json()


def reset_message_offset(paas_client: PAASClient, cluster_name, topic_names, reset_type, **kwargs):
    """ 重置消息偏移量 """
    with allure.step("reset_message_offset()"):
        with allure.step("1.查询集群信息"):
            kafka_info = get_cluster_detail(paas_client, "kafka", cluster_name)
            assert kafka_info, f"未找到{cluster_name}"
            cluster_id = kafka_info['data']['id']
            kafka_vip = kafka_info['data']['realIp']
        with allure.step("2.获取kafka消费者组"):
            cg_info_response = paas_client.kafka_client.get_consumer_group(cluster_name, cluster_id, kafka_vip, **kwargs)
            check_status_code(cg_info_response)
            cg_info = cg_info_response.json()
            assert len(cg_info['data']) > 0, f"未找到GroupID：{kwargs['filterKey']}"
            group_id = cg_info['data'][0]['consumerGroupId']
        with allure.step("3.重置消息"):
            reset_response = paas_client.kafka_client.reset_offset(cluster_name, cluster_id, kafka_vip, group_id,
                                                                   topic_names, reset_type, **kwargs)
            check_status_code(reset_response)


def query_kafka_message(paas_client: PAASClient, cluster_name, topic_name, offset_param):
    """ kafka消息查询 """
    with allure.step("query_kafka_message()"):
        with allure.step("1. 查询集群信息"):
            kafka_info = get_cluster_detail(paas_client, "kafka", cluster_name)
            assert kafka_info, f"未找到{cluster_name}"
            cluster_id = kafka_info['data']['id']
            kafka_vip = kafka_info['data']['realIp']
        with allure.step("2. 消息查询"):
            query_response = paas_client.kafka_client.query_message(cluster_name, cluster_id, topic_name, offset_param,
                                                                    kafka_vip)
            check_status_code(query_response)
            return query_response.json()


def get_subscribe_by_name(paas_client: PAASClient, cluster_name, topic_name, group_id):
    """ 查询订阅关系 """
    with allure.step("get_subscribe_by_name()"):
        with allure.step("1. 查询集群信息"):
            kafka_info = get_cluster_detail(paas_client, "kafka", cluster_name)
            assert kafka_info, f"未找到{cluster_name}"
            cluster_id = kafka_info['data']['id']
            kafka_vip = kafka_info['data']['realIp']
        with allure.step("2. 获取订阅关系"):
            subscribe_response = paas_client.kafka_client.get_subscribe_list(cluster_name, cluster_id, kafka_vip, topic_name)
            check_status_code(subscribe_response)
            return subscribe_response.json()


def update_kafka_config(paas_client: PAASClient, service_name, kafka_name, **kwargs):
    with allure.step("update_kafka_config()"):
        with allure.step("1. 查询集群信息"):
            kafka_info = get_cluster_detail(paas_client, "kafka", kafka_name)
            assert kafka_info, f"未找到{kafka_name}"
            cluster_id = kafka_info['data']['id']
        with allure.step("2.获取原有配置"):
            configs_response = paas_client.mqs_client.get_cluster_config(service_name, cluster_id, "KAFKA")
            check_status_code(configs_response)
            zookeeper_connect = get_value_from_json(configs_response, f"$...kafka-broker[?(@.name=='zookeeper.connect')]")['value']
            kafka_eagle_db_url = get_value_from_json(configs_response, f"$...kafka-env[?(@.name=='kafka_eagle_db_url')]")['value']
        with allure.step("3.更新配置"):
            update_response = paas_client.kafka_client.update_kafka_config(service_name, kafka_name, zookeeper_connect,
                                                                           kafka_eagle_db_url, **kwargs)
            check_status_code(update_response)


def restart_kafka_cluster(paas_client: PAASClient, service_name, kafka_name):
    with allure.step("restart_kafka_components()"):
        with allure.step("1.查询kafka集群IP"):
            kafka_info = get_cluster_by_name(paas_client, service_name, kafka_name)
            assert kafka_info, f"未找到zk集群：{kafka_name}"
            host_ip = kafka_info['realIp']
        with allure.step("2.查询hosts"):
            hosts_list_response = paas_client.mqs_client.get_omc_list(service_name, host_ip, kafka_name)
            check_status_code(hosts_list_response)
            hosts_list = hosts_list_response.json()
            assert len(hosts_list['data']) > 0, f"未找到主机名"
            hosts = ""
            master_hosts = ""
            for host in hosts_list['data']:
                hosts += host['nodeName'] + ","
                if 'master' in host['nodeName']:
                    master_hosts += host['nodeName'] + ","
            hosts = hosts[:-1]
            master_hosts = master_hosts[:-1]
        with allure.step("3.重启kafka组件"):
            restart_response = paas_client.kafka_client.restart_kafka_components(service_name, kafka_name, hosts,
                                                                                 master_hosts)
            check_status_code(restart_response)
        with allure.step("4.查看kafka组件重启状态"):
            timeout = 300
            temp = timeout / 5
            cnt = 1
            while cnt < temp:
                status_response = paas_client.kafka_client.get_restarted_kafka_cluster(service_name, kafka_name)
                check_status_code(status_response)
                status = status_response.json()['data']['components']
                if status == {}:
                    break
                time.sleep(5)
                cnt += 1
            if cnt > temp:
                raise Exception(f"重启kafka组件：{kafka_name}超时")


def create_kafka_connector_cluster(paas_client: PAASClient, cluster_name, label_name, net_name, kp_name, flavor,
                                   kafka_nodes=1, anti_affinity=False, **kwargs):
    """ 创建kafka数据同步集群 """
    with allure.step("create_kafka_connector_cluster()"):
        with allure.step("1.查询kafka-connector版本信息"):
            service_response = paas_client.mqs_client.get_deploy_service("kafkaconnector")
            check_status_code(service_response)
            kafka_info = get_value_from_json(service_response,
                                             f"$...componentList[?(@.server_display_name=='Kafka-Connector')]")
            assert kafka_info, "未找到Kafka-Connector的版本信息"
            versions = {
                'kafka': kafka_info['server_version']
            }
        with allure.step("2.查询网络信息"):
            prepare_info_response = paas_client.mqs_client.get_prepare_info('kafka')
            check_status_code(prepare_info_response)
            zone_info = get_value_from_json(prepare_info_response, f"$..azones[?(@.labelName=='{label_name}')]")
            network_info = get_value_from_json(prepare_info_response, f"$..networkAndAzone[?(@.networkName=='{net_name}')]")
            keypair_name = get_value_from_json(prepare_info_response, f"$..keypairs[?(@.name=='{kp_name}')]")
            assert (zone_info and network_info and keypair_name), f"未找到 {label_name} 或 {net_name} 或 {kp_name}"
            zone_info = {
                "id": zone_info['id'],
                "label_name": zone_info['labelName'],
                "zone_name": zone_info['zone'],
                "virt_type": zone_info['virtType']
            }
            network_info = {
                "id": network_info['networkId'],
                "name": network_info['networkName']
            }

            keypair_name = keypair_name['name']
        with allure.step("3.查询规格信息"):
            flavor_info_response = paas_client.mqs_client.get_prepare_flavor('kafkaconnector', zone_info['id'])
            check_status_code(flavor_info_response)
            flavor_info = get_value_from_json(flavor_info_response, f"$..virtual[?(@.name=='{flavor}')]")
            assert flavor_info, f"未找到规格：{flavor_info}"
            flavor_info = {
                "id": flavor_info['id'],
                "name": flavor_info['name']
            }
        with allure.step("4.查询缺省镜像信息"):
            image_info_response = paas_client.mqs_client.get_default_image_info('kafkaconnector')
            check_status_code(image_info_response)
            image_id = image_info_response.json()['data']['imageId']
        with allure.step("5.创建kafka数据同步集群"):
            create_response = paas_client.kafka_client.create_kafka_connector_cluster(cluster_name, zone_info,
                                                                                      network_info, keypair_name,
                                                                                      flavor_info, image_id, kafka_nodes,
                                                                                      versions=versions)
            check_status_code(create_response)


def apply_for_create_kafka_connector_cluster(paas_client: PAASClient, cluster_name, label_name, net_name, kp_name,
                                             flavor, kafka_nodes=1, anti_affinity=False, **kwargs):

    """ 申请创建kafka数据同步集群 """
    with allure.step("apply_for_create_kafka_connector_cluster()"):
        with allure.step("1.查询kafka-connector版本信息"):
            service_response = paas_client.mqs_client.get_deploy_service("kafkaconnector")
            check_status_code(service_response)
            kafka_info = get_value_from_json(service_response,
                                             f"$...componentList[?(@.server_display_name=='Kafka-Connector')]")
            assert kafka_info, "未找到Kafka-Connector的版本信息"
            versions = {
                'kafka': kafka_info['server_version']
            }
        with allure.step("2.查询网络信息"):
            prepare_info_response = paas_client.mqs_client.get_prepare_info('kafka')
            check_status_code(prepare_info_response)
            zone_info = get_value_from_json(prepare_info_response, f"$..azones[?(@.labelName=='{label_name}')]")
            network_info = get_value_from_json(prepare_info_response, f"$..networkAndAzone[?(@.networkName=='{net_name}')]")
            keypair_name = get_value_from_json(prepare_info_response, f"$..keypairs[?(@.name=='{kp_name}')]")
            assert (zone_info and network_info and keypair_name), f"未找到 {label_name} 或 {net_name} 或 {kp_name}"
            zone_info = {
                "id": zone_info['id'],
                "label_name": zone_info['labelName'],
                "zone_name": zone_info['zone'],
                "virt_type": zone_info['virtType']
            }
            network_info = {
                "id": network_info['networkId'],
                "name": network_info['networkName']
            }

            keypair_name = keypair_name['name']
        with allure.step("3.查询规格信息"):
            flavor_info_response = paas_client.mqs_client.get_prepare_flavor('kafkaconnector', zone_info['id'])
            check_status_code(flavor_info_response)
            flavor_info = get_value_from_json(flavor_info_response, f"$..virtual[?(@.name=='{flavor}')]")
            assert flavor_info, f"未找到规格：{flavor_info}"
            flavor_info = {
                "id": flavor_info['id'],
                "name": flavor_info['name']
            }
        with allure.step("4.查询缺省镜像信息"):
            image_info_response = paas_client.mqs_client.get_default_image_info('kafkaconnector')
            check_status_code(image_info_response)
            image_id = image_info_response.json()['data']['imageId']
        with allure.step("5.申请创建kafka数据同步集群"):
            apply_response = paas_client.kafka_client.apply_for_create_kafka_connector_cluster(cluster_name, zone_info,
                                                                                               network_info,
                                                                                               keypair_name,
                                                                                               flavor_info, image_id,
                                                                                               kafka_nodes,
                                                                                               versions=versions)
            check_status_code(apply_response)


def synchronize_kafka(paas_client: PAASClient, service_name1, service_name2, cluster_name, src_cluster_name,
                      des_cluster_name, local_cluster, kafka_sync_all=True, sync_task=True, **kwargs):
    """ kafka集群数据同步配置 """
    with allure.step("synchronize_kafka()"):
        with allure.step("1.数据同步集群信息"):
            cluster_info = get_specific_cluster_by_name(paas_client, service_name2, cluster_name)
            assert cluster_info, f"未找到集群：{cluster_name}"
            cluster_id = cluster_info['id']
            # 获取集群详情中的 url/ cluster_ip
            cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name2,
                                                                                                 cluster_id)
            check_status_code(cluster_detail_response)
            cluster_ip = cluster_detail_response.json()['data']['realIp']
            cluster_info = {
                "name": cluster_name,
                "id": cluster_id,
                "ip": cluster_ip
            }
        with allure.step("2.源集群连接测试"):
            # 获取集群ID
            src_cluster_info = get_specific_cluster_by_name(paas_client, service_name1, src_cluster_name)
            assert src_cluster_info, f"未找到集群：{src_cluster_name}"
            src_cluster_id = src_cluster_info['id']
            # 获取集群详情中的 url
            cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name1,
                                                                                                 src_cluster_id)
            check_status_code(cluster_detail_response)
            src_cluster_detail = cluster_detail_response.json()
            src_cluster_url = src_cluster_detail['data']['serviceProperties']['url']
            # 连接前先清理残留数据
            residue_kafka_cluster(paas_client, service_name2, src_cluster_url, cluster_ip)
            # 连接测试
            connect_kafka_cluster(paas_client, service_name2, src_cluster_url, cluster_ip)
            src_cluster_info = {
                "name": src_cluster_name,
                "alias": "src" + src_cluster_name,
                "id": src_cluster_id,
                "url": src_cluster_url
            }
        with allure.step("3.目的集群连接测试"):
            # 获取集群ID
            des_cluster_info = get_specific_cluster_by_name(paas_client, service_name1, des_cluster_name)
            assert des_cluster_info, f"未找到集群：{des_cluster_name}"
            des_cluster_id = des_cluster_info['id']
            # 获取集群详情中的 url
            cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name1,
                                                                                                 des_cluster_id)
            check_status_code(cluster_detail_response)
            des_cluster_detail = cluster_detail_response.json()
            des_cluster_url = des_cluster_detail['data']['serviceProperties']['url']
            # 连接前先清理残留数据
            residue_kafka_cluster(paas_client, service_name2, src_cluster_url, cluster_ip)
            # 连接测试
            connect_kafka_cluster(paas_client, service_name2, des_cluster_url, cluster_ip)
            des_cluster_info = {
                "name": des_cluster_name,
                "alias": "des" + des_cluster_name,
                "id": des_cluster_id,
                "url": des_cluster_url
            }
        with allure.step("4.同步集群"):
            synch_response = paas_client.kafka_client.synchronize_kafka_config(cluster_info, src_cluster_info,
                                                                               des_cluster_info, local_cluster,
                                                                               kafka_sync_all, sync_task, **kwargs)
            check_status_code(synch_response)
            temp = 60
            cnt = 1
            while cnt <= temp:
                cluster_info = get_specific_cluster_by_name(paas_client, service_name2, cluster_name)
                if cluster_info['status'] == "ACTIVE":
                    break
                time.sleep(10)
                cnt += 1
            if cnt > temp:
                raise Exception("数据同步配置超时")


def create_kafka_sync_task(paas_client: PAASClient, service_name1, service_name2, task_name, cluster_name,
                           src_cluster_name, des_cluster_name, kafka_sync_all=True, **kwargs):
    """ 新建同步任务 """
    with allure.step("create_kafka_sync_task()"):
        with allure.step("1.获取数据同步集群信息"):
            cluster_info = get_specific_cluster_by_name(paas_client, service_name2, cluster_name)
            assert cluster_info, f"未找到集群：{cluster_name}"
            cluster_id = cluster_info['id']
            # 获取集群详情中的 url/ cluster_ip
            cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name2,
                                                                                                 cluster_id)
            check_status_code(cluster_detail_response)
            cluster_ip = cluster_detail_response.json()['data']['realIp']
            cluster_info = {
                "name": cluster_name,
                "id": cluster_id,
                "ip": cluster_ip
            }
        with allure.step("2.获取源集群信息"):
            # 获取集群ID
            src_cluster_info = get_specific_cluster_by_name(paas_client, service_name1, src_cluster_name)
            assert src_cluster_info, f"未找到集群：{src_cluster_name}"
            src_cluster_id = src_cluster_info['id']
            # 获取集群详情中的 url
            cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name1,
                                                                                                 src_cluster_id)
            check_status_code(cluster_detail_response)
            src_cluster_detail = cluster_detail_response.json()
            src_cluster_url = src_cluster_detail['data']['serviceProperties']['url']
            src_cluster_info = {
                "name": src_cluster_name,
                "alias": "src" + src_cluster_name,
                "id": src_cluster_id,
                "url": src_cluster_url
            }
        with allure.step("3.获取目的集群连接测试"):
            # 获取集群ID
            des_cluster_info = get_specific_cluster_by_name(paas_client, service_name1, des_cluster_name)
            assert des_cluster_info, f"未找到集群：{des_cluster_name}"
            des_cluster_id = des_cluster_info['id']
            # 获取集群详情中的 url
            cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name1,
                                                                                                 des_cluster_id)
            check_status_code(cluster_detail_response)
            des_cluster_detail = cluster_detail_response.json()
            des_cluster_url = des_cluster_detail['data']['serviceProperties']['url']
            des_cluster_info = {
                "name": des_cluster_name,
                "alias": "des" + des_cluster_name,
                "id": des_cluster_id,
                "url": des_cluster_url
            }
        with allure.step("4.校验同步任务是否存在"):
            result_response = paas_client.kafka_client.check_kafka_data_sync_task("kafkaconnector", cluster_id,
                                                                                  src_cluster_url)
            check_status_code(result_response)
            result = result_response.json()
            assert not result['data'], f"同步任务已存在：{task_name}"
        with allure.step("5.创建任务"):
            synch_response = paas_client.kafka_client.create_synchronize_kafka_task(task_name, cluster_info,
                                                                                    src_cluster_info, des_cluster_info,
                                                                                    kafka_sync_all, **kwargs)
            check_status_code(synch_response)
        with allure.step("6.校验任务创建完成"):
            cluster_detail_resp = paas_client.kafka_client.get_kafka_connector_cluster_detail(service_name2, cluster_id,
                                                                                              cluster_name, cluster_ip,
                                                                                              src_cluster_url)
            check_status_code(cluster_detail_resp)
            task_info = get_value_from_json(cluster_detail_resp, f"$.data[?(@.taskName=='{task_name}')]")
            assert task_info, f"同步任务未创建成功：{task_name}"
            # assert task_info['status'] == "RUNNING", f"同步任务未正常运行：{task_name}" # 新建任务无消费行为，任务不会在运行中


def delete_kafka_sync_task(paas_client: PAASClient, service_name, task_name, cluster_name):
    """ 删除同步任务 """
    with allure.step("delete_kafka_sync_task()"):
        with allure.step("1.获取数据同步集群信息"):
            cluster_info = get_specific_cluster_by_name(paas_client, service_name, cluster_name)
            assert cluster_info, f"未找到集群：{cluster_name}"
            cluster_id = cluster_info['id']
            # 获取集群详情中的 url/ cluster_ip
            cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name,
                                                                                                 cluster_id)
            check_status_code(cluster_detail_response)
            cluster_ip = cluster_detail_response.json()['data']['realIp']
        with allure.step("2.删除同步任务"):
            result_response = paas_client.kafka_client.delete_synchronize_kafka_task(task_name, cluster_ip, cluster_id)
            check_status_code(result_response)
            result = result_response.json()
            assert result['data'], f"同步任务未成功删除：{task_name}"


def restart_kafka_sync_task(paas_client: PAASClient, service_name1, service_name2, task_name, cluster_name,
                            src_cluster_name):
    """ 重启同步任务 """
    with allure.step("restart_kafka_sync_task()"):
        with allure.step("1.获取数据同步集群信息"):
            cluster_info = get_specific_cluster_by_name(paas_client, service_name2, cluster_name)
            assert cluster_info, f"未找到集群：{cluster_name}"
            cluster_id = cluster_info['id']
            # 获取集群详情中的 url/ cluster_ip
            cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name2,
                                                                                                 cluster_id)
            check_status_code(cluster_detail_response)
            cluster_ip = cluster_detail_response.json()['data']['realIp']
        with allure.step("2.重启同步任务"):
            result_response = paas_client.kafka_client.restart_synchronize_kafka_task(task_name, cluster_ip)
            check_status_code(result_response)
            result = result_response.json()
            assert result['data'], f"同步任务未成功重启：{task_name}"
        with allure.step("2.校验同步任务状态"):
            src_cluster_info = get_specific_cluster_by_name(paas_client, service_name1, src_cluster_name)
            assert src_cluster_info, f"未找到源集群：{src_cluster_name}"
            src_cluster_id = src_cluster_info['id']
            cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name1,
                                                                                                 src_cluster_id)
            check_status_code(cluster_detail_response)
            src_cluster_detail = cluster_detail_response.json()
            src_cluster_url = src_cluster_detail['data']['serviceProperties']['url']

            temp = 10
            cnt = 1
            while cnt <= temp:
                cluster_detail_resp = paas_client.kafka_client.get_kafka_connector_cluster_detail(service_name2,
                                                                                                  cluster_id,
                                                                                                  cluster_name,
                                                                                                  cluster_ip,
                                                                                                  src_cluster_url)
                check_status_code(cluster_detail_resp)
                task_info = get_value_from_json(cluster_detail_resp, f"$.data[?(@.taskName=='{task_name}')]")
                assert task_info, f"未找到同步任务：{task_name}"
                if task_info['status'] == "RUNNING":
                    break
                time.sleep(2)
                cnt += 1
            if cnt > temp:
                raise Exception("同步任务未正常运行：{task_name}")


def stop_kafka_sync_connector(paas_client: PAASClient, service_name, service_name1, cluster_name):
    """ 停止同步组件 """
    with allure.step("stop_kafka_sync_connector()"):
        with allure.step("1.获取数据同步集群信息"):
            cluster_info = get_specific_cluster_by_name(paas_client, service_name1, cluster_name)
            assert cluster_info, f"未找到集群：{cluster_name}"
            cluster_id = cluster_info['id']
            # 获取集群详情中的 url/ cluster_ip
            cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name1,
                                                                                                 cluster_id)
            check_status_code(cluster_detail_response)
            cluster_ip = cluster_detail_response.json()['data']['realIp']
        with allure.step("2.停止同步组件"):
            result_response = paas_client.kafka_client.action_synchronize_kafka_connector(service_name, cluster_name,
                                                                                          "stop")
            check_status_code(result_response)
        with allure.step("3.校验同步组件状态"):
            temp = 10
            cnt = 1
            while cnt <= temp:
                resp = paas_client.mqs_client.get_omc_service_list(service_name1, cluster_ip, cluster_name)
                check_status_code(resp)
                if resp.json()['data'][0]['serviceState'] == "STOPPED":
                    break
                time.sleep(2)
                cnt += 1
            if cnt > temp:
                raise Exception("同步组件停止超时")


def start_kafka_sync_connector(paas_client: PAASClient, service_name, service_name1, cluster_name):
    """ 开启同步组件 """
    with allure.step("start_kafka_sync_connector()"):
        with allure.step("1.获取数据同步集群信息"):
            cluster_info = get_specific_cluster_by_name(paas_client, service_name1, cluster_name)
            assert cluster_info, f"未找到集群：{cluster_name}"
            cluster_id = cluster_info['id']
            # 获取集群详情中的 url/ cluster_ip
            cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name1,
                                                                                                 cluster_id)
            check_status_code(cluster_detail_response)
            cluster_ip = cluster_detail_response.json()['data']['realIp']
        with allure.step("2.开启同步组件"):
            result_response = paas_client.kafka_client.action_synchronize_kafka_connector(service_name, cluster_name,
                                                                                          "start")
            check_status_code(result_response)
        with allure.step("3.校验同步组件状态"):
            temp = 10
            cnt = 1
            while cnt <= temp:
                resp = paas_client.mqs_client.get_omc_service_list(service_name1, cluster_ip, cluster_name)
                check_status_code(resp)
                if resp.json()['data'][0]['serviceState'] == "STARTED":
                    break
                time.sleep(2)
                cnt += 1
            if cnt > temp:
                raise Exception("同步组件开启超时")


def restart_kafka_sync_connector(paas_client: PAASClient, service_name, service_name1, cluster_name):
    """ 重启同步组件 """
    with allure.step("restart_kafka_sync_connector()"):
        # with allure.step("1.获取数据同步集群信息"):
        #     cluster_info = get_specific_cluster_by_name(paas_client, service_name1, cluster_name)
        #     assert cluster_info, f"未找到集群：{cluster_name}"
        #     cluster_id = cluster_info['id']
        #     # 获取集群详情中的 url/ cluster_ip
        #     cluster_detail_response = paas_client.mqs_client.get_specific_bigdata_cluster_detail(service_name1,
        #                                                                                          cluster_id)
        #     check_status_code(cluster_detail_response)
        #     cluster_ip = cluster_detail_response.json()['data']['realIp']
        with allure.step("2.重启同步组件"):
            result_response = paas_client.kafka_client.action_synchronize_kafka_connector(service_name, cluster_name,
                                                                                          "restart")
            check_status_code(result_response)
        # with allure.step("3.校验同步组件状态"):
        #     temp = 10
        #     cnt = 1
        #     while cnt <= temp:
        #         resp = paas_client.mqs_client.get_omc_service_list(service_name1, cluster_ip, cluster_name)
        #         check_status_code(resp)
        #         if resp.json()['data'][0]['serviceState'] == "STARTED":
        #             break
        #         time.sleep(2)
        #         cnt += 1
        #     if cnt > temp:
        #         raise Exception("同步组件重启超时")


def connect_kafka_cluster(paas_client: PAASClient, service_name, cluster_url, cluster_ip):
    """ 测试kafka集群连接 """
    with allure.step("connect_kafka_cluster()"):
        result_response = paas_client.kafka_client.get_kafka_data_sync_status(service_name, cluster_url, cluster_ip)
        check_status_code(result_response)
        result = result_response.json()
        assert result['code'] == "", f"{result['msg']}"


def residue_kafka_cluster(paas_client: PAASClient, service_name, cluster_url, cluster_ip):
    """ 清理kafka残留数据 """
    with allure.step("residue_kafka_cluster()"):
        result_response = paas_client.kafka_client.residue_kafka(service_name, cluster_url, cluster_ip)
        check_status_code(result_response)
        result = result_response.json()
        assert result['code'] == "", f"{result['msg']}"

