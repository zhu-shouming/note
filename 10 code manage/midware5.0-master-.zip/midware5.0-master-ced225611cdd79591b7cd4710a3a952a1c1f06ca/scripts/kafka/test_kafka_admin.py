import datetime
import pytest
import os
import yaml

from resource.utils.user import PAASLogin
from scripts.kafka.handler_kafka import *
from kafka import KafkaProducer, KafkaConsumer, KafkaAdminClient, TopicPartition

cur_path = os.path.dirname(os.path.realpath(__file__))
datafile = os.path.join(cur_path, 'data_admin.yaml')

with open(datafile, encoding='utf-8') as f:
    data_file = yaml.safe_load(f)


SERVICE_NAME = "kafka"
SERVICE_NAME1 = "kafkaconnector"


@pytest.mark.kafka
@allure.feature("kafka")
@allure.story("kafka")
class TestKafka:

    """ 初始化：创建KAFKA集群 """
    def setup_class(self):
        paas_admin_login = PAASClient(PAASLogin(settings.USERNAME, settings.PASSWORD, settings.HOST, settings.PORT))
        label_name = settings['LABEL_NAME']
        net_name = settings['NET_NAME']
        kp_name = settings['KP_ADMIN_NAME']
        flavor = settings['KAFKA_FLAVOR']
        admin_pwd = settings['PASSWORD']
        cluster_name = "auto" + get_random_string(5, char_type=0).lower()
        create_kafka_vm_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor, admin_pwd)
        des_cluster_name = "auto" + get_random_string(5, char_type=0).lower()
        create_kafka_vm_cluster(paas_admin_login, des_cluster_name, label_name, net_name, kp_name, flavor, admin_pwd)
        temp = 180
        cnt = 1
        while cnt <= temp:
            cluster_info = get_cluster_by_name(paas_admin_login, "kafka", cluster_name)
            des_cluster_info = get_cluster_by_name(paas_admin_login, "kafka", des_cluster_name)
            if (cluster_info['status'] == "ACTIVE") and (des_cluster_info['status'] == "ACTIVE"):
                break
            time.sleep(10)
            cnt = cnt + 1
        if cnt > temp:
            raise Exception("创建KAFKA集群超时")
        self.kafka_name = cluster_name
        self.des_cluster_name = des_cluster_name    # 目的kafka

    """ 清理：KAFKA集群 """
    def teardown_class(self):
        paas_admin_login = PAASClient(PAASLogin(settings.USERNAME, settings.PASSWORD, settings.HOST, settings.PORT))
        delete_cluster(paas_admin_login, SERVICE_NAME, self.kafka_name)
        delete_cluster(paas_admin_login, SERVICE_NAME, self.des_cluster_name)

    @pytest.mark.skip(reason="初始化中已有创建集群")
    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_create_kafka_cluster'])
    def test_create_kafka_cluster(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("1.创建KAFKA集群"):
            label_name = settings['LABEL_NAME']
            net_name = settings['NET_NAME']
            kp_name = settings['KP_ADMIN_NAME']
            flavor = settings['KAFKA_FLAVOR']
            kafka_pwd = args['kafka_pwd']
            cluster_name = "auto" + get_random_string(5, char_type=0).lower()
            create_kafka_vm_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor, kafka_pwd)
        with allure.step("2.检查集群状态"):       # 等待10min
            temp = 180
            cnt = 1
            while cnt <= temp:
                cluster_info = get_cluster_by_name(paas_admin_login, "kafka", cluster_name)
                if cluster_info['status'] == "ACTIVE":
                    break
                time.sleep(10)
                cnt = cnt + 1
            if cnt > temp:
                raise Exception("创建KAFKA集群超时")
        with allure.step("TEARDOWN: 删除KAFKA集群"):
            delete_cluster(paas_admin_login, SERVICE_NAME, cluster_name)

    @pytest.mark.L5
    @allure.description("创建TOPIC")
    def test_create_topic(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 创建TOPIC")
        with allure.step("1. 创建TOPIC"):
            topic_name = "auto" + get_random_string(5, char_type=0)
            partitions = 1
            replications = 1
            create_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name, partitions, replications)
        with allure.step("2. 页面确认TOPIC创建成功"):
            topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name)
            assert topic_info, f"未找到TOPIC：{topic_name}"
            act_partitions = topic_info['partitions']
            act_replications = topic_info['replications']
            assert act_partitions == partitions, f"分区数不匹配。实际：{act_partitions}，期望：{partitions}"
            assert act_replications == replications, f"副本数不匹配。实际：{act_replications}，期望：{replications}"
        with allure.step("3. 分区状态页面确认TOPIC创建成功，分区数正确"):
            partitions_status_info = get_kafka_partitions_status(paas_admin_login, self.kafka_name, topic_name)
            act_partitions = partitions_status_info['total']
            assert act_partitions == partitions, f"分区数不匹配。实际：{act_partitions}，期望：{partitions}"
        with allure.step("4. 后台确认TOPIC创建成功，分区数正确"):
            kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.kafka_name)
            kafka_url = kafka_info['data']['serviceProperties']['url']
            admin_client = KafkaAdminClient(bootstrap_servers=kafka_url)
            topics = admin_client.list_topics()
            assert topic_name in topics, f"未找到TOPIC：{topic_name}"
            for item in admin_client.describe_topics():
                if item['topic'] == topic_name:
                    assert len(item['partitions']) == partitions, f"分区数不匹配。实际：{len(item['partitions'])}，" \
                                                                  f"期望：{partitions}"
        with allure.step("TEARDOWN: 删除TOPIC"):
            delete_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, [topic_name])

    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_update_topic'])
    @allure.description("更新TOPIC -- 增加分区")
    def test_update_topic(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("SETUP: 创建TOPIC"):
            topic_name = "auto" + get_random_string(5, char_type=0)
            partitions = 1
            replications = 1
            create_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name, partitions, replications)
            topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name)
            assert topic_info, f"未找到TOPIC：{topic_name}"
            # 分区状态页面确认TOPIC创建成功，分区数正确
            partitions_status_info = get_kafka_partitions_status(paas_admin_login, self.kafka_name, topic_name)
            act_partitions = partitions_status_info['total']
            assert act_partitions == partitions, f"分区数不匹配。实际：{act_partitions}，期望：{partitions}"
        with allure.step("1. 增加分区数"):
            steps = args['steps']
            alter_kafka_topic_partitions(paas_admin_login, self.kafka_name, topic_name, steps)
        with allure.step("2. 列表页面确认TOPIC修改成功"):
            topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name)
            assert topic_info, f"未找到TOPIC：{topic_name}"
            act_partitions = topic_info['partitions']
            assert act_partitions == (partitions + steps), f"分区数不匹配。实际：{act_partitions}，期望：{partitions + steps}"
        with allure.step("3. 分区状态页面确认TOPIC修改成功，分区数正确"):
            partitions_status_info = get_kafka_partitions_status(paas_admin_login, self.kafka_name, topic_name)
            act_partitions = partitions_status_info['total']
            assert act_partitions == (partitions + steps), f"分区数不匹配。实际：{act_partitions}，期望：{partitions + steps}"
        with allure.step("4. 后台确认TOPIC修改成功，分区数正确"):
            kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.kafka_name)
            kafka_url = kafka_info['data']['serviceProperties']['url']
            admin_client = KafkaAdminClient(bootstrap_servers=kafka_url)
            topics = admin_client.list_topics()
            assert topic_name in topics, f"未找到TOPIC：{topic_name}"
            for item in admin_client.describe_topics():
                if item['topic'] == topic_name:
                    assert len(item['partitions']) == (partitions + steps), f"分区数不匹配。实际：{len(item['partitions'])}，" \
                                                                  f"期望：{partitions + steps}"
        with allure.step("TEARDOWN: 删除TOPIC"):
            delete_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, [topic_name])

    @pytest.mark.L5
    @allure.description("批量删除TOPIC")
    def test_patch_delete_topics(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 批量删除TOPIC")
        with allure.step("SETUP: 创建TOPIC"):
            topic_names = []
            count = random.randint(1, 5)
            for i in range(1, count + 1):
                topic_name = "auto" + get_random_string(5, char_type=0)
                create_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name, partitions=1,
                                   replications=1)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name)
                assert topic_info, f"未找到TOPIC：{topic_name}"
                topic_names.append(topic_name)
        with allure.step("批量删除TOPIC"):
            delete_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_names)

    @pytest.mark.L5
    @allure.description("消息查询")
    def test_query_message(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 消息查询")
        with allure.step("SETUP: 创建TOPIC"):
            topic_name = "auto" + get_random_string(5, char_type=0)
            partitions = 1
            replications = 1
            create_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name, partitions, replications)
            topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name)
            assert topic_info, f"未找到TOPIC：{topic_name}"
            kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.kafka_name)
            kafka_url = kafka_info['data']['serviceProperties']['url']
        with allure.step("1. 生产者产生消息"):
            producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
            count = random.randint(1, 10)
            for i in range(0, count):
                k = bytes("k" + str(i), encoding='utf8')
                v = bytes("v" + str(i), encoding='utf8')
                producer.send(topic_name, key=k, value=v)
        with allure.step("2. 消息查询"):
            query_info = query_kafka_message(paas_admin_login, self.kafka_name, topic_name, 0)
            assert len(query_info['data']) > 0, f"消息未正常生产"
            assert len(query_info['data']) == count, f"消息未正常生产"
        with allure.step("3. 分区状态页面查询消息总量"):
            partitions_status_info = get_kafka_partitions_status(paas_admin_login, self.kafka_name, topic_name)
            msg_total = partitions_status_info['data'][0]['massageTotal']
            assert count == msg_total, f"分区数不匹配。实际：{count}，期望：{msg_total}"
        with allure.step("TEARDOWN: 删除TOPIC"):
            delete_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, [topic_name])

    @pytest.mark.L5
    @allure.description("消息者组")
    def test_consumer_group(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 消费者组")
        with allure.step("SETUP: "):
            with allure.step("1.创建TOPIC"):
                topic_name = "auto" + get_random_string(5, char_type=0)
                partitions = 1
                replications = 1
                create_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name, partitions, replications)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name)
                assert topic_info, f"未找到TOPIC：{topic_name}"
                kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.kafka_name)
                kafka_url = kafka_info['data']['serviceProperties']['url']
            with allure.step("2.生产者产生消息"):
                producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
                count = random.randint(1, 10)
                for i in range(0, count):
                    k = bytes("k" + str(i), encoding='utf8')
                    v = bytes("v" + str(i), encoding='utf8')
                    producer.send(topic_name, key=k, value=v)
            with allure.step("3.消费者订阅消息"):
                group_id = "auto" + get_random_string(3, char_type=0)
                consumer = KafkaConsumer(topic_name, group_id=group_id, bootstrap_servers=kafka_url,
                                         auto_offset_reset='earliest')  # , consumer_timeout_ms=1000
                consumer.subscribe(topics=[topic_name])
                tp = TopicPartition(topic_name, 0)
                for message in consumer:
                    # print(message)
                    if message.offset == consumer.end_offsets([tp])[tp] - 1:
                        break
        with allure.step("1.查询消费者组"):
            temp = 10
            cnt = 1
            while cnt <= temp:
                cg_info = get_kafka_consumer_group(paas_admin_login, self.kafka_name, filterKey=group_id)
                if len(cg_info['data']) > 0:
                    cg_info = get_kafka_consumer_group(paas_admin_login, self.kafka_name, filterKey=group_id)
                    assert len(cg_info['data']) > 0, f"未找到消费者组：{group_id}"
                    assert cg_info['data'][0]['subTopic'] == topic_name, \
                        f"TOPIC不一致：实际：{cg_info['data'][0]['subTopic']}， 期望：{topic_name}"
                    assert cg_info['data'][0]['numberSubTopic'] == 1, \
                        f"TOPIC数量不一致：实际：{cg_info['data'][0]['numberSubTopic']}， 期望：1"
                    assert cg_info['data'][0]['consumerGroupId'] == group_id, \
                        f"GroupID不一致：实际：{cg_info['data'][0]['consumerGroupId']}， 期望：{group_id}"
                    break
                time.sleep(1)
                cnt = cnt + 1
            if cnt > temp:
                raise Exception(f"订阅TOPIC：{topic_name} 中无GroupID：{group_id}")
        with allure.step("2.查询订阅关系"):
            subscribes = get_subscribe_by_name(paas_admin_login, self.kafka_name, topic_name, group_id)
            assert len(subscribes['data']) > 0, f"无订阅关系：{group_id}"
            assert group_id in subscribes['data'], f"无订阅关系：{group_id}"
        with allure.step("TEARDOWN: 删除TOPIC"):
            delete_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, [topic_name])

    @pytest.mark.flaky(reruns=3)
    @pytest.mark.L5
    @allure.description("消息重置")
    def test_reset_message(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 消息重置（从最新偏移量开始消费）")
        with allure.step("SETUP："):
            with allure.step("1.创建TOPIC"):
                topic_name = "auto" + get_random_string(5, char_type=0)
                partitions = 1
                replications = 1
                create_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name, partitions, replications)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, self.kafka_name, topic_name)
                assert topic_info, f"未找到TOPIC：{topic_name}"
                kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.kafka_name)
                kafka_url = kafka_info['data']['serviceProperties']['url']
            with allure.step("2.生产者产生消息"):
                producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
                k = bytes("k" + str(0), encoding='utf8')
                v = bytes("v" + str(0), encoding='utf8')
                producer.send(topic_name, key=k, value=v)
                producer.flush()
            with allure.step("3.消费者订阅消息"):
                group_id = "auto" + get_random_string(3, char_type=0)
                consumer = KafkaConsumer(topic_name, group_id=group_id, bootstrap_servers=kafka_url,
                                         consumer_timeout_ms=1000)
                consumer.subscribe(topics=[topic_name])
                tp = TopicPartition(topic_name, 0)
                for message in consumer:
                    if message.offset == consumer.end_offsets([tp])[tp] - 1:
                        break
                consumer.close()
        with allure.step("1.生产者生产消息，产生堆积消息"):
            k = bytes("k" + str(1), encoding='utf8')
            v = bytes("v" + str(1), encoding='utf8')
            producer.send(topic_name, key=k, value=v)
            producer.flush()
        with allure.step("2.校验堆积总量"):
            cg_info = get_kafka_consumer_group(paas_admin_login, self.kafka_name, filterKey=group_id)
            assert len(cg_info['data']) > 0, f"未找到消费者组：{group_id}"
            assert cg_info['data'][0]['lagCount'] > 0, f"无堆积消息"
        with allure.step("3.重置偏移量"):
            reset_message_offset(paas_admin_login, self.kafka_name, [topic_name], "latest")
        with allure.step("4.校验堆积总量"):
            cg_info = get_kafka_consumer_group(paas_admin_login, self.kafka_name, filterKey=group_id)
            assert cg_info['data'][0]['lagCount'] == 0, f"重置偏移量失败。实际：{cg_info['data'][0]['lagCount']}"
        with allure.step("TEARDOWN: 删除TOPIC"):
            delete_kafka_topic(paas_admin_login, SERVICE_NAME, self.kafka_name, [topic_name])

    @pytest.mark.L5
    @allure.description("运行日志收集")
    def test_download_kafka_server_log(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- KAFKA运行日志收集")
        begin_date = (datetime.datetime.now() - datetime.timedelta(hours=24)).strftime('%Y-%m-%d')
        end_date = datetime.datetime.now().strftime('%Y-%m-%d')
        collect_server_log(paas_admin_login, SERVICE_NAME, begin_date, end_date)

    @pytest.mark.L5
    @allure.description("集群日志收集")
    def test_download_kafka_cluster_log(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- KAFKA集群日志收集")
        collect_cluster_log(paas_admin_login, SERVICE_NAME, self.kafka_name)

    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_create_kafka_connector_cluster'])
    @allure.description("创建数据同步集群")
    def test_create_kafka_connector_cluster(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("1.创建数据同步集群"):
            label_name = settings['LABEL_NAME']
            net_name = settings['NET_NAME']
            kp_name = settings['KP_ADMIN_NAME']
            flavor = settings['KAFKA_FLAVOR']
            kafka_nodes = args['kafka_nodes']
            cluster_name = "auto" + get_random_string(5, char_type=0).lower()
            create_kafka_connector_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor,
                                           kafka_nodes=kafka_nodes)
        with allure.step("2.校验集群状态"):
            temp = 180  # 等待30min
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                assert cluster_info, f"未找到集群：{cluster_name}"
                if cluster_info['status'] == "WAITINGCONFIGURE":
                    break
                cnt = cnt + 1
            if cnt > temp:
                raise Exception("数据同步集群创建超时")
        with allure.step("TEARDOWN：删除集群"):
            delete_specific_cluster(paas_admin_login, SERVICE_NAME1, SERVICE_NAME + ", " + SERVICE_NAME1, cluster_name)

    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_synchronize_kafka_with_all_topics'])
    @allure.description("同步所有TOPIC")
    def test_synchronize_kafka_with_all_topics(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("SETUP"):
            with allure.step("1.创建数据同步集群"):
                cluster_name = "auto" + get_random_string(5, char_type=0).lower()
                label_name = settings['LABEL_NAME']
                net_name = settings['NET_NAME']
                kp_name = settings['KP_ADMIN_NAME']
                flavor = settings['KAFKA_FLAVOR']
                kafka_nodes = args['kafka_nodes']
                create_kafka_connector_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor,
                                               kafka_nodes=kafka_nodes)
                temp = 180
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "WAITINGCONFIGURE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步集群创建超时")
            with allure.step("2.创建源和目的kafka集群"):
                src_cluster = self.kafka_name
                des_cluster = self.des_cluster_name
                # 清理topic
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        src_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        des_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)
        with allure.step("1.同步集群"):
            local_cluster = args['local_cluster']
            synchronize_kafka(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, cluster_name, src_cluster, des_cluster,
                              local_cluster)
            # 等待10min
            temp = 60
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                assert cluster_info, f"未找到集群：{cluster_name}"
                if cluster_info['status'] == "ACTIVE":
                    break
                cnt = cnt + 1
            if cnt > temp:
                raise Exception("数据同步配置超时")
            # 校验固定TOPIC
            base_topics = ["connect-configs", "connect-status", "connect-offsets"]
            for topic in base_topics:
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, topic)
                assert topic_info, f"数据同步失败。未找到TOPIC：{topic}"
        with allure.step("2.源kafka集群创建TOPIC和消息"):
            topic_name = "auto" + get_random_string(5, char_type=0)
            create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1, replications=1)
            topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
            assert topic_info, f"未找到TOPIC：{topic_name}"
            kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
            kafka_url = kafka_info['data']['serviceProperties']['url']
            producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
            count = random.randint(1, 3)
            for i in range(0, count):
                k = bytes("k" + str(i), encoding='utf8')
                v = bytes("v" + str(i), encoding='utf8')
                producer.send(topic_name, key=k, value=v)
        with allure.step("3.目的kafka集群同步TOPIC和消息"):
            des_topic_name = "src" + src_cluster + "." + topic_name     # 目的端topic名称 = 源别名+"."+topic名称
            # 等待10min
            temp = 60
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                if topic_info:
                    break
                cnt = cnt + 1
            if cnt > temp:
                raise Exception(f"数据同步配置超时，未同步源TOPIC：{topic_name}")
            # 校验消息同步结果
            query_info = query_kafka_message(paas_admin_login, des_cluster, des_topic_name, 0)
            assert len(query_info['data']) > 0, f"消息未正常同步"
            assert len(query_info['data']) == count, f"消息未正常同步"
        with allure.step("TEARDOWN"):
            with allure.step("1.删除数据同步集群"):
                delete_specific_cluster(paas_admin_login, SERVICE_NAME1, SERVICE_NAME + "," + SERVICE_NAME1,
                                        cluster_name)
            with allure.step("2.删除源kafka集群中的TOPIC"):
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                for topic in topics_info['data']:
                    src_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
            with allure.step("3.删除目的kafka集群中的TOPIC"):
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                for topic in topics_info['data']:
                    des_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)

    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_synchronize_kafka_with_part_of_topics'])
    @allure.description("同步部分TOPIC")
    def test_synchronize_kafka_with_part_of_topics(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("SETUP"):
            with allure.step("1.创建数据同步集群"):
                cluster_name = "auto" + get_random_string(5, char_type=0).lower()
                label_name = settings['LABEL_NAME']
                net_name = settings['NET_NAME']
                kp_name = settings['KP_ADMIN_NAME']
                flavor = settings['KAFKA_FLAVOR']
                kafka_nodes = args['kafka_nodes']
                create_kafka_connector_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor,
                                               kafka_nodes=kafka_nodes)
                temp = 180
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "WAITINGCONFIGURE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步集群创建超时")
            with allure.step("2.创建源和目的kafka集群"):
                src_cluster = self.kafka_name
                des_cluster = self.des_cluster_name
                # 清理topic
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        src_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        des_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)
            with allure.step("3.源kafka集群创建TOPIC和消息"):
                topics_list = []
                count = random.randint(1, 3)
                for num in range(0, count):
                    topic_name = "auto" + get_random_string(5, char_type=0)
                    topics_list.append(topic_name)
                    create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1, replications=1)
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
                    assert topic_info, f"未找到TOPIC：{topic_name}"
                    kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
                    kafka_url = kafka_info['data']['serviceProperties']['url']
                    producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
                    for i in range(0, count):
                        k = bytes("k" + str(i), encoding='utf8')
                        v = bytes("v" + str(i), encoding='utf8')
                        producer.send(topic_name, key=k, value=v)
            with allure.step("1.同步集群"):
                local_cluster = args['local_cluster']
                topics = ""
                for i in topics_list:
                    topics += i + ","
                synchronize_kafka(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, cluster_name, src_cluster, des_cluster,
                                  local_cluster, kafka_sync_all=False, topics=topics[:-1])
                # 等待10min
                temp = 60
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "ACTIVE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步配置超时")
            with allure.step("2.校验固定TOPIC"):
                base_topics = ["connect-configs", "connect-status", "connect-offsets"]
                for topic in base_topics:
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, topic)
                    assert topic_info, f"数据同步失败。未找到TOPIC：{topic}"
            with allure.step("3.校验指定同步的TOPIC"):
                for topic in topics_list:
                    des_topic_name = "src" + src_cluster + "." + topic     # 目的端topic名称 = 源别名+"."+topic名称
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                    assert topic_info, f"数据同步失败。未找到TOPIC：{topic}"
                    # 校验消息同步结果
                    query_info = query_kafka_message(paas_admin_login, des_cluster, des_topic_name, 0)
                    assert len(query_info['data']) > 0, f"消息未正常同步"
                    assert len(query_info['data']) == count, f"消息未正常同步"
            with allure.step("4.源kafka集群创建TOPIC和消息"):
                topic_name = "auto" + get_random_string(5, char_type=0)
                create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1, replications=1)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
                assert topic_info, f"未找到TOPIC：{topic_name}"
                kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
                kafka_url = kafka_info['data']['serviceProperties']['url']
                producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
                count = random.randint(1, 3)
                for i in range(0, count):
                    k = bytes("k" + str(i), encoding='utf8')
                    v = bytes("v" + str(i), encoding='utf8')
                    producer.send(topic_name, key=k, value=v)
            with allure.step("5.目的kafka集群不同步新建的TOPIC和消息"):
                des_topic_name = "src" + src_cluster + "." + topic_name     # 目的端topic名称 = 源别名+"."+topic名称
                # 等待10min
                temp = 30
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                    if topic_info:
                        raise Exception(f"数据同步配置失败，出现未指定的源TOPIC：{topic_name}")
                    cnt = cnt + 1
        with allure.step("TEARDOWN"):
            with allure.step("1.删除数据同步集群"):
                delete_specific_cluster(paas_admin_login, SERVICE_NAME1, SERVICE_NAME + "," + SERVICE_NAME1,
                                        cluster_name)
            with allure.step("2.删除源kafka集群中的TOPIC"):
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                for topic in topics_info['data']:
                    src_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
            with allure.step("3.删除目的kafka集群中的TOPIC"):
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                for topic in topics_info['data']:
                    des_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)

    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_create_sync_task_with_all_topics'])
    @allure.description("创建同步任务同步全部TOPIC")
    def test_create_sync_task_with_all_topics(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("SETUP"):
            with allure.step("1.创建数据同步集群"):
                cluster_name = "auto" + get_random_string(5, char_type=0).lower()
                label_name = settings['LABEL_NAME']
                net_name = settings['NET_NAME']
                kp_name = settings['KP_ADMIN_NAME']
                flavor = settings['KAFKA_FLAVOR']
                kafka_nodes = args['kafka_nodes']
                create_kafka_connector_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor,
                                               kafka_nodes=kafka_nodes)
                temp = 180
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "WAITINGCONFIGURE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步集群创建超时")
            with allure.step("2.创建源和目的kafka集群"):
                src_cluster = self.kafka_name
                des_cluster = self.des_cluster_name
                # 清理topic
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        src_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        des_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)
            with allure.step("3.同步集群"):
                local_cluster = args['local_cluster']
                synchronize_kafka(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, cluster_name, src_cluster, des_cluster,
                                  local_cluster, sync_task=False)
                # 等待10min
                temp = 60
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "ACTIVE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步配置超时")
                # 校验固定TOPIC
                base_topics = ["connect-configs", "connect-status", "connect-offsets"]
                for topic in base_topics:
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, topic)
                    assert topic_info, f"数据同步失败。未找到TOPIC：{topic}"
        with allure.step("1.创建同步任务"):
            task_name = "auto" + get_random_string(5, char_type=0).lower()
            create_kafka_sync_task(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, task_name, cluster_name,
                                   src_cluster, des_cluster)
        with allure.step("2.源kafka集群创建TOPIC和消息"):
            topic_name = "auto" + get_random_string(5, char_type=0)
            create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1, replications=1)
            topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
            assert topic_info, f"未找到TOPIC：{topic_name}"
            kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
            kafka_url = kafka_info['data']['serviceProperties']['url']
            producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
            count = random.randint(1, 3)
            for i in range(0, count):
                k = bytes("k" + str(i), encoding='utf8')
                v = bytes("v" + str(i), encoding='utf8')
                producer.send(topic_name, key=k, value=v)
        with allure.step("3.目的kafka集群同步TOPIC和消息"):
            des_topic_name = "src" + src_cluster + "." + topic_name     # 目的端topic名称 = 源别名+"."+topic名称
            # 等待10min
            temp = 60
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                if topic_info:
                    break
                cnt = cnt + 1
            if cnt > temp:
                raise Exception(f"数据同步配置超时，未同步源TOPIC：{topic_name}")
            # 校验消息同步结果
            query_info = query_kafka_message(paas_admin_login, des_cluster, des_topic_name, 0)
            assert len(query_info['data']) > 0, f"消息未正常同步"
            assert len(query_info['data']) == count, f"消息未正常同步"
        with allure.step("TEARDOWN"):
            with allure.step("1.删除数据同步集群"):
                delete_specific_cluster(paas_admin_login, SERVICE_NAME1, SERVICE_NAME + "," + SERVICE_NAME1,
                                        cluster_name)
            with allure.step("2.删除源kafka集群中的TOPIC"):
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                for topic in topics_info['data']:
                    src_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
            with allure.step("3.删除目的kafka集群中的TOPIC"):
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                for topic in topics_info['data']:
                    des_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)

    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_create_sync_task_with_part_of_topics'])
    @allure.description("创建同步任务同步部分TOPIC")
    def test_create_sync_task_with_part_of_topics(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("SETUP"):
            with allure.step("1.创建数据同步集群"):
                cluster_name = "auto" + get_random_string(5, char_type=0).lower()
                label_name = settings['LABEL_NAME']
                net_name = settings['NET_NAME']
                kp_name = settings['KP_ADMIN_NAME']
                flavor = settings['KAFKA_FLAVOR']
                kafka_nodes = args['kafka_nodes']
                create_kafka_connector_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor,
                                               kafka_nodes=kafka_nodes)
                temp = 180
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "WAITINGCONFIGURE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步集群创建超时")
            with allure.step("2.创建源和目的kafka集群"):
                src_cluster = self.kafka_name
                des_cluster = self.des_cluster_name
                # 清理topic
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        src_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        des_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)
            with allure.step("3.同步集群"):
                local_cluster = args['local_cluster']
                synchronize_kafka(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, cluster_name, src_cluster, des_cluster,
                                  local_cluster, sync_task=False)
                # 等待10min
                temp = 60
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "ACTIVE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步配置超时")
                # 校验固定TOPIC
                base_topics = ["connect-configs", "connect-status", "connect-offsets"]
                for topic in base_topics:
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, topic)
                    assert topic_info, f"数据同步失败。未找到TOPIC：{topic}"
            with allure.step("4.源kafka集群创建TOPIC和消息"):
                topics_list = []
                count = random.randint(1, 3)
                for num in range(0, count):
                    topic_name = "auto" + get_random_string(5, char_type=0)
                    topics_list.append(topic_name)
                    create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1, replications=1)
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
                    assert topic_info, f"未找到TOPIC：{topic_name}"
                    kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
                    kafka_url = kafka_info['data']['serviceProperties']['url']
                    producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
                    for i in range(0, count):
                        k = bytes("k" + str(i), encoding='utf8')
                        v = bytes("v" + str(i), encoding='utf8')
                        producer.send(topic_name, key=k, value=v)
        with allure.step("1.创建同步任务"):
            task_name = "auto" + get_random_string(5, char_type=0).lower()
            topics = ""
            for i in topics_list:
                topics += i + ","
            create_kafka_sync_task(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, task_name, cluster_name,
                                   src_cluster, des_cluster, kafka_sync_all=False, topics=topics[:-1])
        with allure.step("2.目的kafka集群校验指定同步的TOPIC"):
            for topic in topics_list:
                des_topic_name = "src" + src_cluster + "." + topic  # 目的端topic名称 = 源别名+"."+topic名称
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster,
                                                     des_topic_name)
                assert topic_info, f"数据同步失败。未找到TOPIC：{topic}"
                # 校验消息同步结果
                query_info = query_kafka_message(paas_admin_login, des_cluster, des_topic_name, 0)
                assert len(query_info['data']) > 0, f"消息未正常同步"
                assert len(query_info['data']) == count, f"消息未正常同步"
        with allure.step("3.源kafka集群创建TOPIC和消息"):
            topic_name = "auto" + get_random_string(5, char_type=0)
            create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1, replications=1)
            topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
            assert topic_info, f"未找到TOPIC：{topic_name}"
            kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
            kafka_url = kafka_info['data']['serviceProperties']['url']
            producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
            count = random.randint(1, 3)
            for i in range(0, count):
                k = bytes("k" + str(i), encoding='utf8')
                v = bytes("v" + str(i), encoding='utf8')
                producer.send(topic_name, key=k, value=v)
        with allure.step("4.目的kafka集群不同步新建的TOPIC和消息"):
            des_topic_name = "src" + src_cluster + "." + topic_name  # 目的端topic名称 = 源别名+"."+topic名称
            # 等待10min
            temp = 30
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                if topic_info:
                    raise Exception(f"数据同步配置失败，出现未指定的源TOPIC：{topic_name}")
                cnt = cnt + 1
        with allure.step("TEARDOWN"):
            with allure.step("1.删除数据同步集群"):
                delete_specific_cluster(paas_admin_login, SERVICE_NAME1, SERVICE_NAME + "," + SERVICE_NAME1,
                                        cluster_name)
            with allure.step("2.删除源kafka集群中的TOPIC"):
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                for topic in topics_info['data']:
                    src_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
            with allure.step("3.删除目的kafka集群中的TOPIC"):
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                for topic in topics_info['data']:
                    des_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)

    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_delete_sync_task_with_all_topics'])
    @allure.description("删除同步任务同步全部TOPIC")
    def test_delete_sync_task_with_all_topics(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("SETUP"):
            with allure.step("1.创建数据同步集群"):
                cluster_name = "auto" + get_random_string(5, char_type=0).lower()
                label_name = settings['LABEL_NAME']
                net_name = settings['NET_NAME']
                kp_name = settings['KP_ADMIN_NAME']
                flavor = settings['KAFKA_FLAVOR']
                kafka_nodes = args['kafka_nodes']
                create_kafka_connector_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor,
                                               kafka_nodes=kafka_nodes)
                temp = 180
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "WAITINGCONFIGURE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步集群创建超时")
            with allure.step("2.创建源和目的kafka集群"):
                src_cluster = self.kafka_name
                des_cluster = self.des_cluster_name
                # 清理topic
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        src_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        des_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)
            with allure.step("3.同步集群"):
                local_cluster = args['local_cluster']
                synchronize_kafka(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, cluster_name, src_cluster, des_cluster,
                                  local_cluster, sync_task=False)
                # 等待10min
                temp = 60
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "ACTIVE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步配置超时")
                # 校验固定TOPIC
                base_topics = ["connect-configs", "connect-status", "connect-offsets"]
                for topic in base_topics:
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, topic)
                    assert topic_info, f"数据同步失败。未找到TOPIC：{topic}"
            with allure.step("4.创建同步任务"):
                task_name = "auto" + get_random_string(5, char_type=0).lower()
                create_kafka_sync_task(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, task_name, cluster_name,
                                       src_cluster, des_cluster)
            with allure.step("5.源kafka集群创建TOPIC和消息"):
                topic_name = "auto" + get_random_string(5, char_type=0)
                create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1, replications=1)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
                assert topic_info, f"未找到TOPIC：{topic_name}"
                kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
                kafka_url = kafka_info['data']['serviceProperties']['url']
                producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
                count = random.randint(1, 3)
                for i in range(0, count):
                    k = bytes("k" + str(i), encoding='utf8')
                    v = bytes("v" + str(i), encoding='utf8')
                    producer.send(topic_name, key=k, value=v)
            with allure.step("6.目的kafka集群同步TOPIC和消息"):
                des_topic_name = "src" + src_cluster + "." + topic_name     # 目的端topic名称 = 源别名+"."+topic名称
                # 等待10min
                temp = 60
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                    if topic_info:
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception(f"数据同步配置超时，未同步源TOPIC：{topic_name}")
                # 校验消息同步结果
                query_info = query_kafka_message(paas_admin_login, des_cluster, des_topic_name, 0)
                assert len(query_info['data']) > 0, f"消息未正常同步"
                assert len(query_info['data']) == count, f"消息未正常同步"
        with allure.step("1.删除同步任务"):
            delete_kafka_sync_task(paas_admin_login, SERVICE_NAME1, task_name, cluster_name)
        with allure.step("2.源kafka集群创建TOPIC和消息"):
            topics_list = []
            count = random.randint(1, 3)
            for num in range(0, count):
                topic_name = "auto" + get_random_string(5, char_type=0)
                topics_list.append(topic_name)
                create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1,
                                   replications=1)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
                assert topic_info, f"未找到TOPIC：{topic_name}"
                kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
                kafka_url = kafka_info['data']['serviceProperties']['url']
                producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
                for i in range(0, count):
                    k = bytes("k" + str(i), encoding='utf8')
                    v = bytes("v" + str(i), encoding='utf8')
                    producer.send(topic_name, key=k, value=v)
        with allure.step("3.目的kafka集群不再收到新的TOPIC和消息"):
            des_topic_name = "src" + src_cluster + "." + topic_name  # 目的端topic名称 = 源别名+"."+topic名称
            # 等待10min
            temp = 30
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                if topic_info:
                    raise Exception(f"数据同步配置失败，出现未指定的源TOPIC：{topic_name}")
                cnt = cnt + 1
        with allure.step("TEARDOWN"):
            with allure.step("1.删除数据同步集群"):
                delete_specific_cluster(paas_admin_login, SERVICE_NAME1, SERVICE_NAME + "," + SERVICE_NAME1,
                                        cluster_name)
            with allure.step("2.删除源kafka集群中的TOPIC"):
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                for topic in topics_info['data']:
                    src_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
            with allure.step("3.删除目的kafka集群中的TOPIC"):
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                for topic in topics_info['data']:
                    des_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)

    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_restart_sync_task_with_all_topics'])
    @allure.description("重启同步任务同步全部TOPIC")
    def test_restart_sync_task_with_all_topics(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("SETUP"):
            with allure.step("1.创建数据同步集群"):
                cluster_name = "auto" + get_random_string(5, char_type=0).lower()
                label_name = settings['LABEL_NAME']
                net_name = settings['NET_NAME']
                kp_name = settings['KP_ADMIN_NAME']
                flavor = settings['KAFKA_FLAVOR']
                kafka_nodes = args['kafka_nodes']
                create_kafka_connector_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor,
                                               kafka_nodes=kafka_nodes)
                temp = 180
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "WAITINGCONFIGURE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步集群创建超时")
            with allure.step("2.创建源和目的kafka集群"):
                src_cluster = self.kafka_name
                des_cluster = self.des_cluster_name
                # 清理topic
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        src_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        des_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)
            with allure.step("3.同步集群"):
                local_cluster = args['local_cluster']
                synchronize_kafka(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, cluster_name, src_cluster, des_cluster,
                                  local_cluster, sync_task=False)
                # 等待10min
                temp = 60
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "ACTIVE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步配置超时")
                # 校验固定TOPIC
                base_topics = ["connect-configs", "connect-status", "connect-offsets"]
                for topic in base_topics:
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, topic)
                    assert topic_info, f"数据同步失败。未找到TOPIC：{topic}"
            with allure.step("4.创建同步任务"):
                task_name = "auto" + get_random_string(5, char_type=0).lower()
                create_kafka_sync_task(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, task_name, cluster_name,
                                       src_cluster, des_cluster)
            with allure.step("5.源kafka集群创建TOPIC和消息"):
                topic_name = "auto" + get_random_string(5, char_type=0)
                create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1, replications=1)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
                assert topic_info, f"未找到TOPIC：{topic_name}"
                kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
                kafka_url = kafka_info['data']['serviceProperties']['url']
                producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
                count = random.randint(1, 3)
                for i in range(0, count):
                    k = bytes("k" + str(i), encoding='utf8')
                    v = bytes("v" + str(i), encoding='utf8')
                    producer.send(topic_name, key=k, value=v)
            with allure.step("6.目的kafka集群同步TOPIC和消息"):
                des_topic_name = "src" + src_cluster + "." + topic_name     # 目的端topic名称 = 源别名+"."+topic名称
                # 等待10min
                temp = 60
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                    if topic_info:
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception(f"数据同步配置超时，未同步源TOPIC：{topic_name}")
                # 校验消息同步结果
                query_info = query_kafka_message(paas_admin_login, des_cluster, des_topic_name, 0)
                assert len(query_info['data']) > 0, f"消息未正常同步"
                assert len(query_info['data']) == count, f"消息未正常同步"
        with allure.step("1.重启同步任务"):
            restart_kafka_sync_task(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, task_name, cluster_name, src_cluster)
        with allure.step("2.源kafka集群创建TOPIC和消息"):
            topics_list = []
            count = random.randint(1, 3)
            for num in range(0, count):
                topic_name = "auto" + get_random_string(5, char_type=0)
                topics_list.append(topic_name)
                create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1,
                                   replications=1)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
                assert topic_info, f"未找到TOPIC：{topic_name}"
                kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
                kafka_url = kafka_info['data']['serviceProperties']['url']
                producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
                for i in range(0, count):
                    k = bytes("k" + str(i), encoding='utf8')
                    v = bytes("v" + str(i), encoding='utf8')
                    producer.send(topic_name, key=k, value=v)
        with allure.step("3.目的kafka集群不再收到新的TOPIC和消息"):
            des_topic_name = "src" + src_cluster + "." + topic_name  # 目的端topic名称 = 源别名+"."+topic名称
            # 等待10min
            temp = 60
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                if topic_info:
                    break
                cnt = cnt + 1
            if cnt > temp:
                raise Exception(f"数据同步配置超时，未同步源TOPIC：{topic_name}")
            # 校验消息同步结果
            query_info = query_kafka_message(paas_admin_login, des_cluster, des_topic_name, 0)
            assert len(query_info['data']) > 0, f"消息未正常同步"
            assert len(query_info['data']) == count, f"消息未正常同步"
        with allure.step("TEARDOWN"):
            with allure.step("1.删除数据同步集群"):
                delete_specific_cluster(paas_admin_login, SERVICE_NAME1, SERVICE_NAME + "," + SERVICE_NAME1,
                                        cluster_name)
            with allure.step("2.删除源kafka集群中的TOPIC"):
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                for topic in topics_info['data']:
                    src_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
            with allure.step("3.删除目的kafka集群中的TOPIC"):
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                for topic in topics_info['data']:
                    des_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)

    @pytest.mark.L5
    @pytest.mark.parametrize('args', data_file['test_action_sync_components_with_all_topics'])
    @allure.description("停止/开启/重启同步组件同步全部TOPIC")
    def test_action_sync_components_with_all_topics(self, paas_admin_login: PAASClient, args):
        show_testcase_title(args['title'])
        with allure.step("SETUP"):
            with allure.step("1.创建数据同步集群"):
                cluster_name = "auto" + get_random_string(5, char_type=0).lower()
                label_name = settings['LABEL_NAME']
                net_name = settings['NET_NAME']
                kp_name = settings['KP_ADMIN_NAME']
                flavor = settings['KAFKA_FLAVOR']
                kafka_nodes = args['kafka_nodes']
                create_kafka_connector_cluster(paas_admin_login, cluster_name, label_name, net_name, kp_name, flavor,
                                               kafka_nodes=kafka_nodes)
                temp = 180
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "WAITINGCONFIGURE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步集群创建超时")
            with allure.step("2.创建源和目的kafka集群"):
                src_cluster = self.kafka_name
                des_cluster = self.des_cluster_name
                # 清理topic
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        src_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                if len(topics_info['data']) > 0:
                    for topic in topics_info['data']:
                        des_topics.append(topic['topicName'])
                    delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)
            with allure.step("3.同步集群"):
                local_cluster = args['local_cluster']
                synchronize_kafka(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, cluster_name, src_cluster, des_cluster,
                                  local_cluster)
                # 等待10min
                temp = 60
                cnt = 1
                while cnt <= temp:
                    time.sleep(10)
                    cluster_info = get_specific_cluster_by_name(paas_admin_login, SERVICE_NAME1, cluster_name)
                    assert cluster_info, f"未找到集群：{cluster_name}"
                    if cluster_info['status'] == "ACTIVE":
                        break
                    cnt = cnt + 1
                if cnt > temp:
                    raise Exception("数据同步配置超时")
                # 校验固定TOPIC
                base_topics = ["connect-configs", "connect-status", "connect-offsets"]
                for topic in base_topics:
                    topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, topic)
                    assert topic_info, f"数据同步失败。未找到TOPIC：{topic}"
        with allure.step("1.停止同步组件"):
            stop_kafka_sync_connector(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, cluster_name)
        with allure.step("2.源kafka集群创建TOPIC和消息"):
            topic_name = "auto" + get_random_string(5, char_type=0)
            create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1, replications=1)
            topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
            assert topic_info, f"未找到TOPIC：{topic_name}"
            kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
            kafka_url = kafka_info['data']['serviceProperties']['url']
            producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
            count = random.randint(1, 3)
            for i in range(0, count):
                k = bytes("k" + str(i), encoding='utf8')
                v = bytes("v" + str(i), encoding='utf8')
                producer.send(topic_name, key=k, value=v)
        with allure.step("3.目的kafka集群不同步新建的TOPIC和消息"):
            des_topic_name = "src" + src_cluster + "." + topic_name     # 目的端topic名称 = 源别名+"."+topic名称
            # 等待10min
            temp = 30
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                if topic_info:
                    raise Exception(f"数据同步配置失败，出现未指定的源TOPIC：{topic_name}")
                cnt = cnt + 1
        with allure.step("4.开启同步组件"):
            start_kafka_sync_connector(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, cluster_name)
        with allure.step("5.目的kafka集群同步TOPIC和消息"):
            temp = 60
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                if topic_info:
                    break
                cnt = cnt + 1
            if cnt > temp:
                raise Exception(f"数据同步配置超时，未同步源TOPIC：{topic_name}")
            # 校验消息同步结果
            query_info = query_kafka_message(paas_admin_login, des_cluster, des_topic_name, 0)
            assert len(query_info['data']) > 0, f"消息未正常同步"
            assert len(query_info['data']) == count, f"消息未正常同步"
        with allure.step("6.重启同步组件"):
            restart_kafka_sync_connector(paas_admin_login, SERVICE_NAME, SERVICE_NAME1, cluster_name)
        with allure.step("7.源kafka集群创建TOPIC和消息"):
            topic_name = "auto" + get_random_string(5, char_type=0)
            create_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, topic_name, partitions=1, replications=1)
            topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster, topic_name)
            assert topic_info, f"未找到TOPIC：{topic_name}"
            kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, src_cluster)
            kafka_url = kafka_info['data']['serviceProperties']['url']
            producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
            count = random.randint(1, 3)
            for i in range(0, count):
                k = bytes("k" + str(i), encoding='utf8')
                v = bytes("v" + str(i), encoding='utf8')
                producer.send(topic_name, key=k, value=v)
        with allure.step("8.目的kafka集群同步TOPIC和消息"):
            des_topic_name = "src" + src_cluster + "." + topic_name  # 目的端topic名称 = 源别名+"."+topic名称
            # 等待10min
            temp = 60
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                topic_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster, des_topic_name)
                if topic_info:
                    break
                cnt = cnt + 1
            if cnt > temp:
                raise Exception(f"数据同步配置超时，未同步源TOPIC：{topic_name}")
            # 校验消息同步结果
            query_info = query_kafka_message(paas_admin_login, des_cluster, des_topic_name, 0)
            assert len(query_info['data']) > 0, f"消息未正常同步"
            assert len(query_info['data']) == count, f"消息未正常同步"
        with allure.step("TEARDOWN"):
            with allure.step("1.删除数据同步集群"):
                delete_specific_cluster(paas_admin_login, SERVICE_NAME1, SERVICE_NAME + "," + SERVICE_NAME1,
                                        cluster_name)
            with allure.step("2.删除源kafka集群中的TOPIC"):
                src_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, src_cluster)
                for topic in topics_info['data']:
                    src_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, src_cluster, src_topics)
            with allure.step("3.删除目的kafka集群中的TOPIC"):
                des_topics = []
                topics_info = get_kafka_topic_by_name(paas_admin_login, SERVICE_NAME, des_cluster)
                for topic in topics_info['data']:
                    des_topics.append(topic['topicName'])
                delete_kafka_topic(paas_admin_login, SERVICE_NAME, des_cluster, des_topics)

    @pytest.mark.L5
    @allure.description("主机扩容")
    def test_scale_kafka(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- KAFKA主机扩容")
        with allure.step("1. 原有节点数量"):
            time.sleep(5)   # 创建以后立即扩容容易失败，故等待5s
            cluster_info = get_cluster_by_name(paas_admin_login, SERVICE_NAME, self.kafka_name)
            assert cluster_info, f"未找到：{self.kafka_name}"
            origin_node_count = cluster_info['nodeCount']
        with allure.step("2.主机扩容"):
            step_node_count = 1
            scale_kafka_cluster(paas_admin_login, SERVICE_NAME, self.kafka_name, step_node_count)
            temp = 180
            cnt = 1
            while cnt <= temp:
                time.sleep(10)
                cluster_info = get_cluster_by_name(paas_admin_login, SERVICE_NAME, self.kafka_name)
                if cluster_info['status'] == "ACTIVE":
                    break
                cnt = cnt + 1
            if cnt > temp:
                raise Exception("主机扩容超时")
        with allure.step("3.校验扩容结果"):
            cluster_info = get_cluster_by_name(paas_admin_login, SERVICE_NAME, self.kafka_name)
            new_node_count = cluster_info['nodeCount']
            assert (origin_node_count + step_node_count) == new_node_count, \
                f"扩容失败。实际节点数量：{new_node_count}, 期望：{origin_node_count}"

    @pytest.mark.L5
    @allure.description("修改配置（分区数）")
    def test_update_config(self, paas_admin_login: PAASClient):
        show_testcase_title("系统管理员 -- 修改配置（分区数）")
        with allure.step("SETUP：记录原配置"):
            config_info = get_cluster_config_detail(paas_admin_login, SERVICE_NAME, self.kafka_name,
                                                    config_name="num.partitions", service="KAFKA")
            init_partitions = int(config_info['value'])
        with allure.step("1.修改配置，重启集群"):
            for i in range(5):
                new_partitions = random.randint(1, 10)
                if init_partitions != new_partitions:
                    break
            update_kafka_config(paas_admin_login, SERVICE_NAME, self.kafka_name, num_partitions=str(new_partitions))
            restart_kafka_cluster(paas_admin_login, SERVICE_NAME, self.kafka_name)
        with allure.step("2.页面校验配置修改是否生效"):
            config_info = get_cluster_config_detail(paas_admin_login, SERVICE_NAME, self.kafka_name,
                                                    config_name="num.partitions", service="KAFKA")
            num_partitions = config_info['value']
            assert int(num_partitions) == new_partitions, f"修改配置（分区数）失败。实际：{num_partitions}，期望：{new_partitions}"
        # with allure.step("3.后台创建TOPIC后校验新分区数"):
        #     # 暂未实现.修改分区成功，通过代码直接给topic发送消息会失败
        #     topic_name = "auto" + get_random_string(3, char_type=0)
        #     kafka_info = get_cluster_detail(paas_admin_login, SERVICE_NAME, self.kafka_name)
        #     kafka_url = kafka_info['data']['serviceProperties']['url']
        #     producer = KafkaProducer(bootstrap_servers=kafka_url, retries=3, api_version=(0, 10, 2))
        #     count = random.randint(1, 3)
        #     for i in range(0, count):
        #         k = bytes("k" + str(i), encoding='utf8')
        #         v = bytes("v" + str(i), encoding='utf8')
        #         producer.send(topic_name, key=k, value=v)   #
        #     admin_client = KafkaAdminClient(bootstrap_servers=kafka_url)
        #     topics = admin_client.list_topics()
        #     assert topic_name in topics, f"未找到TOPIC：{topic_name}"
        #     for item in admin_client.describe_topics():
        #         if item['topic'] == topic_name:
        #             assert len(item['partitions']) == int(new_partitions), \
        #                 f"分区数不匹配。实际：{len(item['partitions'])}，期望：{int(new_partitions)}"
        with allure.step("TEARDOWN：还原配置，重启集群"):
            update_kafka_config(paas_admin_login, SERVICE_NAME, self.kafka_name, num_partitions=str(init_partitions))
            restart_kafka_cluster(paas_admin_login, SERVICE_NAME, self.kafka_name)
            config_info = get_cluster_config_detail(paas_admin_login, SERVICE_NAME, self.kafka_name,
                                                    config_name="num.partitions", service="KAFKA")
            num_partitions = config_info['value']
            assert int(num_partitions) == init_partitions, f"修改配置（分区数）失败。实际：{new_partitions}，期望：{init_partitions}"