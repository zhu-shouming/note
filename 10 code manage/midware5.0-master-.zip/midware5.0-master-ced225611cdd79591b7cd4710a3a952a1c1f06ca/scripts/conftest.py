import pytest
from config.config import settings
from resource.base.client import *
from resource.utils.user import PAASLogin
from resource.utils.common import logger


def pytest_addoption(parser):
    parser.addoption(
        "--configfile", action="store", default="config/config.py", help="指定环境配置文件"
    )


@pytest.fixture(scope="class")
def paas_admin_login():
    return PAASClient(
        PAASLogin(settings.USERNAME, settings.PASSWORD, settings.HOST, settings.PORT)
    )


@pytest.fixture(scope="class")
def paas_proj_admin_login():
    return PAASClient(
        PAASLogin(settings.PROJ_ADMIN, settings.PASSWORD, settings.HOST, settings.PORT)
    )


@pytest.fixture(scope="class")
def paas_proj_user_login():
    return PAASClient(
        PAASLogin(settings.PROJ_USER, settings.PASSWORD, settings.HOST, settings.PORT)
    )


@pytest.fixture(scope="function", name="teardown_info")
def teardown_func():
    """
    资源teardown函数;
    使用时需在脚本中对teardown_info["func_name"]和teardown_info["func_args"]赋值;
    例如:需要调用func1(a=1,b=2), 则teardown_info["func_name"]=func1, teardown_info["func_args"]={"a":1, "b":2}
        需要调用func1(a=1)和func2(), 则teardown_info["func_name"]=[func1, func2], teardown_info["func_args"]=[{"a":1}, {}]
    """
    teardown_info = {"func_name": None, "func_args": None}
    yield teardown_info
    func_name = teardown_info["func_name"]
    func_args = teardown_info["func_args"]
    try:
        if isinstance(func_name, list) and isinstance(func_args, list):
            for name, args in func_name, func_args:
                logger.info("执行函数{}清除环境, 参数为{}".format(name.__name__, args))
                name(**args)
        elif func_name is not None:
            logger.info("执行函数{}清除环境, 参数为{}".format(func_name.__name__, func_args))
            func_name(**func_args)
    except Exception as e:
        logger.error(
            "清除环境失败: {}, func_name: {}, func_args: {}".format(e, func_name, func_args)
        )
