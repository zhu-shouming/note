import pytest
import os
from resource.base.client import PAASClient
import yaml, datetime
from resource.utils.common import *
from config.config import settings
from resource.utils.user import PAASLogin

cur_path = os.path.dirname(os.path.realpath(__file__))
datafile = os.path.join(cur_path, 'data.yaml')

with open(datafile, encoding='utf-8') as f:
    data = yaml.safe_load(f)


@pytest.mark.rabbitmq
@allure.feature("消息中间件rabbitmq")
@allure.story("消息中间件rabbitmq--组织管理员")
class TestRabbitmq:
    def setup_class(self):
        user = PAASClient(
            PAASLogin(
                settings.PROJ_ADMIN, settings.PASSWORD, settings.HOST, settings.PORT
            )
        )
        name = 'auto' + get_random_string(4).lower()
        r_flavor = user.rabit_client.get_rabbitmq_node_flavor()
        check_status_code(r_flavor, 200)
        flavor = "2*4*40"
        flavor_id = get_value_from_json(
            r_flavor, f"$.data.virtual[?(@.name=='{flavor}')].id"
        )
        assert flavor_id, f"获取规格信息失败，指定的规格{flavor}不存在"
        self.flavor_id = flavor_id
        mq_passwd = encode_str_to_base64("cloud@123")
        servicename = "rabbitmq"
        info_prepare = user.mqs_client.get_prepare_info(servicename)
        check_status_code(info_prepare, 200)
        keypaire = get_value_from_json(info_prepare, "$..keypairs..name")

        zone_name = settings['LABEL_NAME']
        net_name = settings['NET_NAME']
        zone_id = get_value_from_json(
            info_prepare, f"$..azones[?(@.zone=='{zone_name}')].id"
        )
        net_id = get_value_from_json(
            info_prepare,
            f"$..networkAndAzone[?(@.networkName=='{net_name}')].networkId",
        )

        assert net_id, f"获取网络信息失败"
        assert zone_id, f"获取可用域信息失败"
        self.net_id = net_id
        self.zone_id = zone_id
        image_info_response = user.mqs_client.get_default_image_info('rabbitmq')
        check_status_code(image_info_response)

        image_id = image_info_response.json()['data']['imageId']
        monitor_info = {'on': 1, 'interval': '15s'}
        flavor_info = {
            'id': flavor_id,
            'name': flavor,
            'label': '2 核CPU / 4 GB内存 / 40 GB硬盘 普通',
        }
        r = user.rabit_client.creat_rabbitmq_cluster(
            3,
            name,
            mq_passwd,
            net_id,
            monitor_info,
            image_id,
            zone_id,
            flavor_info,
            keypaire,
            "init cluster",
        )

        check_status_code(r, 200)
        check_jsonpath = f"$.data[?(@.name=='{name}')].status"
        result = wait_action_success_until_timeout(
            user.mqs_client.get_bigdata_cluster,
            check_jsonpath,
            "ACTIVE",
            60,
            1800,
            "rabbitmq",
        )
        assert result, "初始化失败：创建rabbitmq集群失败"

        self.cluster_name = name
        check_info = user.mqs_client.get_bigdata_cluster("rabbitmq")
        assert get_value_from_json(
            check_info, f"$.data[?(@.name=='{name}')]"
        ), "初始化失败， 创建rabbitmq集群失败"
        self.cluster_id = get_value_from_json(
            check_info, f"$.data[?(@.name=='{name}')].id"
        )
        self.cluster_vip = get_value_from_json(
            check_info, f"$.data[?(@.name=='{name}')].realIp"
        )
        r = user.active_client.get_nodes_list(self.cluster_vip, self.cluster_name)
        check_status_code(r)
        self.node_ip = get_value_from_json(r, "$..internalIp", list_flag=True)

    def teardown_class(self):
        user = PAASClient(
            PAASLogin(
                settings.USERNAME, settings.PASSWORD, settings.HOST, settings.PORT
            )
        )
        user.mqs_client.delete_bigdata_cluster("rabbitmq", self.cluster_name)

    @pytest.mark.L5
    @pytest.mark.Smoke
    @allure.title("查询rabbitmq集群列表")
    def test_get_rabbitmq_cluster_list(self, paas_proj_admin_login: PAASClient):
        r = paas_proj_admin_login.mqs_client.get_bigdata_cluster("rabbitmq")
        check_status_code(r, 200)

    @pytest.mark.L0
    @pytest.mark.parametrize("args", data['create_rabbit_mq'])
    def test_create_mq(self, paas_proj_admin_login: PAASClient, args):
        allure.dynamic.title(args['title'])
        name = "auto" + get_random_string(4).lower()
        r_flavor = paas_proj_admin_login.rabit_client.get_rabbitmq_node_flavor()
        check_status_code(r_flavor, 200)
        flavor = args['flavor']
        flavor_id = get_value_from_json(
            r_flavor, f"$.data.virtual[?(@.name=='{flavor}')].id"
        )
        assert flavor_id, f"获取规格信息失败，指定的规格{flavor}不存在"
        mq_passwd = encode_str_to_base64(args['passwd'])
        servicename = "rabbitmq"
        info_prepare = paas_proj_admin_login.mqs_client.get_prepare_info(servicename)
        check_status_code(info_prepare, 200)
        keypaire = get_value_from_json(info_prepare, "$..keypairs..name")
        zone_name = settings['LABEL_NAME']
        net_name = settings['NET_NAME']
        zone_id = get_value_from_json(
            info_prepare, f"$..azones[?(@.zone=='{zone_name}')].id"
        )
        net_id = get_value_from_json(
            info_prepare,
            f"$..networkAndAzone[?(@.networkName=='{net_name}')].networkId",
        )

        assert net_id, f"获取网络信息失败"
        assert zone_id, f"获取可用域信息失败"
        image_info_response = paas_proj_admin_login.mqs_client.get_default_image_info(
            'rabbitmq'
        )
        check_status_code(image_info_response)
        image_id = image_info_response.json()['data']['imageId']
        node_num = int(args['node_num'])
        monitor_info = {
            'on': int(args['monitor_on']),
            'interval': args['monitor_interval'],
        }
        flavor_info = {
            'id': flavor_id,
            'name': args['flavor'],
            'label': args['flavor_label'],
        }
        r = paas_proj_admin_login.rabit_client.creat_rabbitmq_cluster(
            node_num,
            name,
            mq_passwd,
            net_id,
            monitor_info,
            image_id,
            zone_id,
            flavor_info,
            keypaire,
            args['desc'],
        )

        check_status_code(r, 200)
        check_jsonpath = f"$.data[?(@.name=='{name}')].status"
        result = wait_action_success_until_timeout(
            paas_proj_admin_login.mqs_client.get_bigdata_cluster,
            check_jsonpath,
            "ACTIVE",
            60,
            1800,
            "rabbitmq",
        )
        assert result, "创建rabbitmq集群失败"
        logger.info('清理测试环境')
        paas_proj_admin_login.mqs_client.delete_bigdata_cluster('rabbitmq', name)

    @pytest.mark.L5
    @allure.title("停止和启动rabbitmq组件")
    def test_stop_and_start_rabbitmq_service(self, paas_proj_admin_login: PAASClient):
        with allure.step("校验预制rabbitmq集群组件状态是否正常"):
            response = paas_proj_admin_login.rabit_client.get_service_status(
                self.cluster_vip, self.cluster_name
            )
            assert get_value_from_json(response, "$.status") == "success"
            assert get_value_from_json(response, "$.errorCode") == 0
            assert get_value_from_json(response, "$..serviceState") == "STARTED"
        with allure.step("停止rabbitmq组件然后检验组件状态"):
            stop_resp = (
                paas_proj_admin_login.rabit_client.start_or_start_rabiitmq_service(
                    self.cluster_name, "stop"
                )
            )
            check_status_code(stop_resp, 200)
            result = wait_action_success_until_timeout(
                paas_proj_admin_login.rabit_client.get_service_status,
                "$..serviceState",
                "STOPPED",
                5,
                60,
                self.cluster_vip,
                self.cluster_name,
            )
            assert result, f"停止rabbitmq组件操作失败"
        with allure.step("启动rabbitmq组件然后检验状态"):
            time.sleep(5)
            start_resp = (
                paas_proj_admin_login.rabit_client.start_or_start_rabiitmq_service(
                    self.cluster_name, "start"
                )
            )
            check_status_code(start_resp, 200)
            result = wait_action_success_until_timeout(
                paas_proj_admin_login.rabit_client.get_service_status,
                "$..serviceState",
                "STARTED",
                5,
                60,
                self.cluster_vip,
                self.cluster_name,
            )
            assert result, f"启动rabbitmq组件操作失败"

    @pytest.mark.L5
    @allure.title("重启rabbitmq组件")
    def test_restart_rabbitmq_service(self, paas_proj_admin_login: PAASClient):
        with allure.step("校验预制rabbitmq集群组件状态是否正常"):
            response = paas_proj_admin_login.rabit_client.get_service_status(
                self.cluster_vip, self.cluster_name
            )
            assert get_value_from_json(response, "$.status") == "success"
            assert get_value_from_json(response, "$.errorCode") == 0
            assert get_value_from_json(response, "$..serviceState") == "STARTED"
        with allure.step("重启组件"):
            act_resp = paas_proj_admin_login.rabit_client.restart_rabiitmq_service(
                self.cluster_name
            )
            check_status_code(act_resp, 200)
            assert get_value_from_json(act_resp, "$..Requests.status") == "Accepted"
            result = wait_action_success_until_timeout(
                paas_proj_admin_login.rabit_client.get_service_status,
                "$..serviceState",
                "STARTED",
                5,
                60,
                self.cluster_vip,
                self.cluster_name,
            )
            assert result, f"重启rabbitmq组件操作失败"

    @pytest.mark.L5
    @allure.title("admin用户给rabbitmq集群扩容")
    @pytest.mark.parametrize("args", data['scale_mq_cluster'])
    def test_scale_rabbitmq_cluster(self, paas_proj_admin_login: PAASClient, args):
        with allure.step("校验预制rabbitmq集群组件状态是否正常"):
            response = paas_proj_admin_login.rabit_client.get_service_status(
                self.cluster_vip, self.cluster_name
            )
            assert get_value_from_json(response, "$.status") == "success"
            assert get_value_from_json(response, "$.errorCode") == 0
            assert get_value_from_json(response, "$..serviceState") == "STARTED"
        with allure.step("给集群扩容"):
            net = settings['NET_NAME']
            net_id = self.net_id
            resp = paas_proj_admin_login.rabit_client.expand_rabbitmq_cluster(
                self.cluster_id,
                self.cluster_name,
                2,
                net,
                net_id,
                self.zone_id,
                args['flavor'],
                self.flavor_id,
                args['flavor_label'],
            )

            check_status_code(resp, 200)
            result = wait_action_success_until_timeout(
                paas_proj_admin_login.rabit_client.get_nodes_list,
                "$..total",
                5,
                20,
                600,
                self.cluster_vip,
                self.cluster_name,
            )
            assert result, "扩容rabbitmq集群失败"

    @pytest.mark.L5
    @allure.title('删除rabbitmq集群')
    def test_delete_mq(self, paas_proj_admin_login: PAASClient):
        logger.info("teardown部分已多次覆盖删除集群， 此处不再重复")
        # name = 'xzpo'

        # r =paas_proj_admin_login.mqs_client.delete_bigdata_cluster(
        #     "rabbitmq", name)
        # check_status_code(r, 200)
        # check_jsonpath = f"$.data[?(@.name=='{name}')]"
        # result = wait_action_success_until_timeout(
        #    paas_proj_admin_login.mqs_client.get_bigdata_cluster,
        #     check_jsonpath,
        #     False,
        #     10,
        #     200,
        #     "rabbitmq",
        # )
        # assert result, "操作超时， 删除rabbitmq 集群失败"

    @pytest.mark.L5
    @allure.title("用户新建rabbitmq集群告警联系人")
    @pytest.mark.parametrize("args", data['create_alert_contact'])
    def test_create_alert_contact(self, paas_proj_admin_login: PAASClient, args):
        name = get_random_string(5)
        resp = paas_proj_admin_login.rabit_client.create_alert_contact(
            name, args['tel'], args['email']
        )
        check_status_code(resp, 200)
        assert get_value_from_json(resp, "$.data.success"), "给rabbitmq集群新建告警联系人失败"
        check_resp = paas_proj_admin_login.rabit_client.get_alert_contacts(name=name)
        check_status_code(check_resp, 200)
        assert get_value_from_json(check_resp, "$..total") == 1, "新建告警联系人失败"

    @pytest.mark.L5
    @allure.title("新建告警联系组")
    def test_create_alert_group(self, paas_proj_admin_login: PAASClient):
        person1 = "p1" + get_random_string(4).lower()
        person2 = "p2" + get_random_string(4).lower()
        resp = paas_proj_admin_login.rabit_client.create_alert_contact(
            person1, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        resp = paas_proj_admin_login.rabit_client.create_alert_contact(
            person2, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        check_r = paas_proj_admin_login.rabit_client.get_alert_contacts()
        user1 = get_value_from_json(check_r, f"$.data[?(@.name=='{person1}')].id")
        user2 = get_value_from_json(check_r, f"$.data[?(@.name=='{person2}')].id")
        assert user1 and user2, "初始化工作--新建告警联系人失败"
        group_name = "test" + get_random_string(4).lower()
        users_list = [user1, user2]
        result = paas_proj_admin_login.rabit_client.create_alert_group(
            group_name, users_list
        )
        check_status_code(result, 200)

    @pytest.mark.L5
    @allure.title("删除告警联系组")
    def test_delete_aleret_group(self, paas_proj_admin_login: PAASClient):
        person1 = "p1" + get_random_string(4).lower()
        person2 = "p2" + get_random_string(4).lower()
        resp = paas_proj_admin_login.rabit_client.create_alert_contact(
            person1, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        resp = paas_proj_admin_login.rabit_client.create_alert_contact(
            person2, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        check_r = paas_proj_admin_login.rabit_client.get_alert_contacts()
        user1 = get_value_from_json(check_r, f"$.data[?(@.name=='{person1}')].id")
        user2 = get_value_from_json(check_r, f"$.data[?(@.name=='{person2}')].id")
        assert user1 and user2, "初始化工作--新建告警联系人失败"
        group_name = "test" + get_random_string(4).lower()
        users_list = [user1, user2]
        result = paas_proj_admin_login.rabit_client.create_alert_group(
            group_name, users_list
        )
        check_status_code(result, 200)
        time.sleep(3)
        r = paas_proj_admin_login.rabit_client.get_alert_group_list(group_name)
        group_id = get_value_from_json(r, "$..id")
        del_r = paas_proj_admin_login.rabit_client.delete__alert_group(group_id)
        check_status_code(del_r, 200)
        time.sleep(1)
        check_resp = paas_proj_admin_login.rabit_client.get_alert_group_list(group_name)
        assert get_value_from_json(check_resp, "$..total") == 0, "删除告警联系组失败"
