from resource.base.rest_api_base import RestAPIBase
from urllib.parse import urlencode
from config.config import settings
from requests import get


class RabbitmqAPI(RestAPIBase):
    def get_rabbitmq_node_flavor(self):
        """获取rabbitmq虚拟机节点规格"""
        uri = (
            '/api/mqs/app/v1.0/iaasCluster/v1/bigdata/prepare/flavor?wheCloudDisk=false'
        )
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        response = self._get(uri=uri, headers=headers)
        return response

    def get_service_status(self, vip, cluster_name):
        """
        获取rabbitmq组件的状态
        :param vip: 集群虚IP
        :param cluster_name: 集群名称

        """
        uri = f"/api/mqs/app/v1.0/omc/operationAndMaintenanceCenter/clusterManagement/serviceList?hostIp={vip}&clusterName={cluster_name}"
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        response = self._get(uri=uri, headers=headers)
        return response

    def start_or_start_rabiitmq_service(self, cluster_name, action):
        """启动或停止rabiitmq组件

        Args:
            cluster_name (_type_): 集群名字
            action (_type_): 动作 取值为： stop 或start
        """
        uri = f'/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/service/RABBITMQ/{action}'
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._put(uri, headers=headers)

    def restart_rabiitmq_service(self, cluster_name):
        """重启 rabbitmq 组件"""
        uri = f'/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/service/RABBITMQ/restart'
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._post(uri, headers=headers)

    def expand_rabbitmq_cluster(
        self,
        cluster_id,
        cluster_name,
        node_num,
        net_name,
        net_id,
        zone_id,
        flavor_name,
        flavor_id,
        flavor_label,
    ):
        """扩容rabbitmq集群
        Args:
            cluster_id (_type_): 集群id
            node_num (_type_): 扩容的节点数量 可取值 2   4   6
        """
        uri = f'/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster/{cluster_id}'
        scale_nodes_info = []
        for i in range(1, node_num + 1):
            node = {
                "roleNameList": ["extend-" + str(i)],
                "title": "RabbitMQ实例",
                "azoneId": zone_id,
                "azoneName": settings['LABEL_NAME'],
                "virtType": "CAS",
                "flavorId": flavor_id,
                "name": flavor_name,
                "label": flavor_label,
                "storageTypeId": None,
                "onlyId": flavor_id + "_",
                "fixIp": "",
                "fixManagementIp": "",
                "nodeSelectDisabled": False,
            }
            scale_nodes_info.append(node)
        post_data = {
            "expand": True,
            "cluster_name": cluster_name,
            "node_count": node_num,
            "flavor_id": "",
            "node_processes": ["RABBITMQ"],
            "instanceInfo": scale_nodes_info,
            "clusterData": scale_nodes_info,
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "neutron_management_network_id": net_id,
            "neutron_management_network_name": net_name,
            "managerNetwork": net_id,
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "quota": 99,
            "quotaText": "可用999969800G / 全部1000000000G",
        }
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._post(uri=uri, json=post_data, headers=headers)

    def creat_rabbitmq_cluster(
        self,
        node_num,
        name,
        mq_passwd,
        network_id,
        monitor_info,
        img_id,
        zone_id,
        flavor_info,
        keypaire,
        desc,
        **kwargs,
    ):
        uri = '/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster'
        role_list = [
            "master-1",
            "master-2",
            "core-1",
            "core-2",
            "core-3",
            "core-4",
            "core-5",
            "core-6",
            "core-7",
        ]
        zone_name = settings['LABEL_NAME']
        instance_info = []
        for i in range(node_num):
            instance = {
                "roleNameList": [role_list[i]],
                "title": "RabbitMQ实例",
                "azoneId": zone_id,
                "labelName": zone_name,
                "azoneName": zone_name,
                "virtType": "CAS",
                "flavorId": flavor_info['id'],
                "name": flavor_info['name'],
                "label": flavor_info['label'],
                "storageTypeId": None,
                "onlyId": flavor_info['id'] + '_',
                "nodeSelectDisabled": False,
                "fixIp": "",
                "fixManagementIp": "",
            }
            instance_info.append(instance)
        data = {
            "type": "rabbitmq",
            "name": name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": "",
            "rabbitmq_user_name": "admin",
            "rabbitmq_password": mq_passwd,
            "rabbitmq_policy": "",
            "description": desc,
            "whether_ha": False,
            "availability_zone": {
                "id": zone_id,
                "name": zone_name,
                "virtType": "CAS",
            },
            "neutron_management_network_id": network_id,
            "keypair_name": keypaire,
            "anti_affinity": False,
            "manager_virtual_ip": "",
            "service": [
                {
                    "display": True,
                    "component": "RABBITMQ",
                    "relation": "",
                    "host_roles_default": ["master"]
                    if node_num == 1
                    else ['master', 'core'],
                    "optional_host_roles": [],
                    "hosts": role_list[0:node_num],
                    "service": "RABBITMQ",
                },
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"],
                },
            ],
            "monitor_interval": monitor_info['interval'],
            "monitor_on": monitor_info['on'],
            "master": {
                "size": 1 if node_num == 1 else 2,
                "flavor_id": flavor_info['id'],
            },
            "core": {"size": 0 if node_num == 1 else node_num - 2, "flavor_id": ""},
            "task": {"size": "0", "flavor_id": ""},
            "instanceInfo": instance_info,
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "imageId": img_id,
            "data_path": "/var/lib/rabbitmq",
            "log_path": "/var/log/rabbitmq",
            "version": {"RABBITMQ": "3.7.4"},
            "neutron_management_network_name": settings['NET_NAME'],
        }
        service_slave = {
            "component": "AMBARI_SLAVE",
            "display": False,
            "service": "AMBARI",
            "relation": "",
            "host_roles_default": ["master"],
            "hosts": ["master-2"],
        }
        if node_num > 1:
            data['service'].append(service_slave)
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._post(uri, json=data, headers=headers)

    def download_cluster_log(self, cluster_id, cluster_name, node_ip):
        """下载rabbitmq集群日志

        Args:
            cluster_id (_type_): _description_
            cluster_name (_type_): _description_
            node_ip (_type_): _description_

        Returns:
            _type_: _description_
        """
        uri = '/api/mqs/app/v1.0/log/v1/mqs/syslog/collect/clusterLog'
        data = {
            "cluster_id": cluster_id,
            "service_type": "rabbitmq",
            "virt_type": "CAS",
            "log_path": "/var/log/rabbitmq",
            "cluster_name": cluster_name,
            "node_ip": node_ip,
        }
        return self._post(uri, data)

    def get_nodes_list(self, master_ip, cluster_name, page=1, size=10):
        """获取指定 rabbitmq 集群的主机列表"""
        uri = f'/api/mqs/app/v1.0/omc/operationAndMaintenanceCenter/nodeManagement/list?masterIp={master_ip}&clusterName={cluster_name}&page={page}&size={size}&orderByField=onLine&order=descending'
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        url = 'http://' + settings['HOST'] + uri
        return get(url, headers=headers)

    def create_alert_contact(self, name, tel, email):
        """创建告警联系人"""
        uri = '/api/mqs/app/v1.0/alert/v1/alert/person'
        data = {"name": name, "phone": tel, "email": email}
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._post(uri, data)

    def get_alert_contacts(self, page=1, size=10, name=None):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/person?page={page}&pageSize={size}'
        if name:
            uri = uri + '&name=' + name
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._get(uri, headers=headers)

    def create_alert_group(self, name, user_id_list, desc=""):
        """新建告警联系组

        Args:
            name (_type_): _description_
            user_id_list (_type_): _description_
            desc (_type_): _description_
        """

        uri = '/api/mqs/app/v1.0/alert/v1/alert/group'
        data = {"name": name, "description": desc, "listUserIds": user_id_list}
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._post(uri, json=data, headers=headers)

    def delete_alert_contact(self, person_id):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/person?id={person_id}'
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._delete(uri, headers=headers)

    def delete__alert_group(self, group_id):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/group?id={group_id}'
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._delete(uri, headers=headers)

    def get_alert_group_list(self, name=None):
        uri = '/api/mqs/app/v1.0/alert/v1/alert/group?page=1&pageSize=10'
        if name:
            uri = uri + '&name=' + name
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._get(uri, headers=headers)

    def modify_alert_group(self, name, user_id_list, desc, group_id):
        uri = '/api/mqs/app/v1.0/alert/v1/alert/group'
        data = {
            "name": name,
            "description": desc,
            "listUserIds": user_id_list,
            "id": group_id,
        }
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._put(uri, data, headers=headers)

    def get_alerts_list(self, cluster_id='', host='', level='', status=''):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/info/list?page=1&pageSize=10&clusterId={cluster_id}&host={host}&level={level}&status={status}'
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._get(uri)

    def delete_alerts_message(self, message_id_list):
        uri = '/api/mqs/app/v1.0/alert/v1/alert/info/clear'
        data = {"alertId": message_id_list}
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._delete(uri, data, headers=headers)

    def apply_rabbitmq_cluster(
        self,
        node_num,
        name,
        mq_passwd,
        network_id,
        monitor_info,
        img_id,
        zone_id,
        flavor_info,
        keypaire,
        desc,
        **kwargs,
    ):
        uri = '/api/mqs/app/v1.0/cluster/deployment/v1/deployment/cluster/iaas/process'
        role_list = [
            "master-1",
            "master-2",
            "core-1",
            "core-2",
            "core-3",
            "core-4",
            "core-5",
            "core-6",
            "core-7",
        ]
        zone_name = settings['LABEL_NAME']
        instance_info = []
        for i in range(node_num):
            instance = {
                "roleNameList": [role_list[i]],
                "title": "RabbitMQ实例",
                "azoneId": zone_id,
                "labelName": zone_name,
                "azoneName": zone_name,
                "virtType": "CAS",
                "flavorId": flavor_info['id'],
                "name": flavor_info['name'],
                "label": flavor_info['label'],
                "storageTypeId": None,
                "onlyId": flavor_info['id'] + '_',
                "nodeSelectDisabled": False,
                "fixIp": "",
                "fixManagementIp": "",
            }
            instance_info.append(instance)
        data = {
            "type": "rabbitmq",
            "name": name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": "",
            "rabbitmq_user_name": "admin",
            "rabbitmq_password": mq_passwd,
            "rabbitmq_policy": "",
            "description": desc,
            "whether_ha": False,
            "availability_zone": {
                "id": zone_id,
                "name": zone_name,
                "virtType": "CAS",
            },
            "neutron_management_network_id": network_id,
            "keypair_name": keypaire,
            "anti_affinity": False,
            "manager_virtual_ip": "",
            "service": [
                {
                    "display": True,
                    "component": "RABBITMQ",
                    "relation": "",
                    "host_roles_default": ["master"]
                    if node_num == 1
                    else ['master', 'core'],
                    "optional_host_roles": [],
                    "hosts": role_list[0:node_num],
                    "service": "RABBITMQ",
                },
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"],
                },
            ],
            "monitor_interval": monitor_info['interval'],
            "monitor_on": monitor_info['on'],
            "master": {
                "size": 1 if node_num == 1 else 2,
                "flavor_id": flavor_info['id'],
            },
            "core": {"size": 0 if node_num == 1 else node_num - 2, "flavor_id": ""},
            "task": {"size": "0", "flavor_id": ""},
            "instanceInfo": instance_info,
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "imageId": img_id,
            "data_path": "/var/lib/rabbitmq",
            "log_path": "/var/log/rabbitmq",
            "version": {"RABBITMQ": "3.7.4"},
            "neutron_management_network_name": settings['NET_NAME'],
        }
        service_slave = {
            "component": "AMBARI_SLAVE",
            "display": False,
            "service": "AMBARI",
            "relation": "",
            "host_roles_default": ["master"],
            "hosts": ["master-2"],
        }
        if node_num > 1:
            data['service'].append(service_slave)
        headers = self.ss.headers
        headers['servicename'] = "rabbitmq"
        return self._post(uri, json=data, headers=headers)

    def apply_expand_cluster(self, cluster_name):
        uri = f'/api/mqs/app/v1.0/cluster/deployment/v1/deployment/cluster/{cluster_name}%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20/iaas/host/proces'
