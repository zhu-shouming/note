from resource.base.client import PAASClient
from resource.utils.user import PAASLogin
from config.config import settings
from resource.utils.common import *
import pika


def manager_agree_cluster_apply(cluster_name):
    proj_admin = PAASClient(
        PAASLogin(settings.PROJ_ADMIN, settings.PASSWORD, settings.HOST, settings.PORT)
    )
    user_id = proj_admin.login_info.user_id
    resp = proj_admin.sys_client.get_process_by_name(cluster_name, user_id)
    check_status_code(resp, 200)
    process_id = get_value_from_json(resp, '$.data[0].id')
    assert process_id, "获取审批流程失败"
    proj_admin.sys_client.deal_with_process(process_id, True)


class RabbitProducer:
    def __init__(self):
        self.connection = None
        self.channel = None

    def connet_to_cluster(self, host, port, user, passwd):
        credentials = pika.PlainCredentials(user, passwd)
        conne_para = pika.ConnectionParameters(host, port, credentials=credentials)
        self.connection = pika.BlockingConnection(conne_para)

    def send_message(self, message, queue):
        self.channel = self.connection.channel()
        self.channel.queue_declare(queue=queue)
        self.channel.basic_publish(exchange='', routing_key='hello', body=message)

    def close(self):
        self.connection.close()


class RabbitConsumer:
    def __init__(self) -> None:
        self.connection = None
        self.channel = None

    def connet_to_cluster(self, host, port, user, passwd):
        credentials = pika.PlainCredentials(user, passwd)
        conne_para = pika.ConnectionParameters(host, port, credentials=credentials)
        self.connection = pika.BlockingConnection(conne_para)


def check_rabbitmq_access(
    cluster_name, ip, port='5672', user='admin', passwd='cloud@123'
):
    """检查rabbitmq集群是否可以正常访问

    Args:
        ip (_type_): 集群vip
        port (_type_): _description_
        user (_type_, optional):  用户名 Defaults to 'admin'.
        passwd (_type_, optional): 密码 Defaults to 'cloud@123'.
    """
    mq_connet = RabbitProducer()
    try:
        mq_connet.connet_to_cluster(ip, port, user, passwd)
    except Exception:
        pass
    assert mq_connet.connection, f"访问rabbitmq集群 {cluster_name}失败"
    mq_connet.close()