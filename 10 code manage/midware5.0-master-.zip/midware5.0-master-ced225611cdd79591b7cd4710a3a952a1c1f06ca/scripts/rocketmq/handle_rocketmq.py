from resource.base.client import PAASClient
from resource.utils.user import PAASLogin
from config.config import settings
from resource.utils.common import *

# from rocketmq.client import Producer, Message, PushConsumer


def manager_agree_cluster_apply(cluster_name):
    proj_admin = PAASClient(
        PAASLogin(settings.PROJ_ADMIN, settings.PASSWORD, settings.HOST, settings.PORT)
    )
    user_id = proj_admin.login_info.user_id
    resp = proj_admin.sys_client.get_process_by_name(cluster_name, user_id)
    check_status_code(resp, 200)
    process_id = get_value_from_json(resp, '$.data[0].id')
    assert process_id, "获取审批流程失败"
    proj_admin.sys_client.deal_with_process(process_id, True)


# class RocketmqProducer:
#     def __init__(self, pid):
#         self.producer = Producer(pid)

#     def start_a_connect(self, host, port, user, passwd):
#         addr = host + ':' + port
#         self.producer.set_name_server_address(addr)
#         self.producer.set_session_credentials(user, passwd)
#         self.producer.start()

#     def send_message(self, message, key, tag, topic):
#         ss = json.dumps(message).encode('utf-8')
#         msg = Message(topic)
#         msg.set_keys(key)
#         msg.set_tags(tag)
#         msg.set_body(ss)
#         self.producer.send_sync(msg)

#     def shutdown(self):
#         self.producer.shutdown()


# class RocketmqConsumer:
#     def __init__(self, cid):
#         self.consumer = PushConsumer(cid)
#         self.msg_cnt = 0

#     def start_a_consumer(self, host, port, user, passwd, topic):
#         addr = host + ':' + port
#         self.consumer.set_name_server_address(addr)
#         self.consumer.set_session_credentials(user, passwd)
#         self.consumer.subscribe(topic, self._callback)
#         self.consumer.start()

#     def _callback(self, msg):
#         logger.info(msg.id, msg.body)
#         self.msg_cnt = self.msg_cnt + 1

#     def shutdown(self):
#         self.consumer.shutdown()
