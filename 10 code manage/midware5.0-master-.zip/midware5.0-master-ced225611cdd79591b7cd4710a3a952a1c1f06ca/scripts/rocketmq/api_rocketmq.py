from resource.base.rest_api_base import RestAPIBase
from urllib.parse import urlencode
from config.config import settings


class RocketmqAPI(RestAPIBase):
    def create_rocketmq_cluster(
        self,
        master_node,
        cluster_name,
        zone_id,
        net_id,
        keypaire,
        monitor_info,
        flavor_info,
        image_id,
        slave_node=0,
        **kwargs,
    ):

        uri = '/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster'
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"

        node_list = []
        host_list = []
        for i in range(1, master_node + slave_node + 1):
            node = {
                "roleNameList": ["master-" + str(i)],
                "title": "RocketMQ实例",
                "azoneId": zone_id,
                "labelName": settings['LABEL_NAME'],
                "azoneName": settings['LABEL_NAME'],
                "virtType": "CAS",
                "flavorId": flavor_info['id'],
                "name": flavor_info['name'],
                "storageTypeId": None,
                "fixIp": "",
                "fixManagementIp": "",
            }
            node_list.append(node)
            host = "master-" + str(i)
            host_list.append(host)
        data = {
            "administrator": "",
            "administrator_password": "",
            "task": {"size": "0", "flavor_id": ""},
            "type": "rocketmq",
            "name": cluster_name,
            "cluster_mode": "0",
            "description": "",
            "whether_ha": True if master_node + slave_node > 1 else False,
            "availability_zone": {
                "id": zone_id,
                "name": settings['LABEL_NAME'],
                "virtType": "CAS",
            },
            "manager_virtual_ip": "",
            "neutron_management_network_id": net_id,
            "neutron_management_network_name": settings['NET_NAME'],
            "keypair_name": keypaire,
            "anti_affinity": False,
            "monitor_on": monitor_info['on'],
            "monitor_interval": monitor_info['interval'],
            "master": {"size": master_node + slave_node},
            "core": {"size": 0, "flavor_id": ""},
            "service": [
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"],
                },
                {
                    "display": True,
                    "component": "ROCKETMQ_NAMESRV",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "optional_host_roles": [
                        "core",
                        "task",
                        "zookeeper",
                        "redis",
                        "kafka",
                        "elasticsearch",
                        "solr",
                    ],
                    "hosts": host_list,
                    "service": "ROCKETMQ",
                },
                {
                    "display": True,
                    "component": "ROCKETMQ_BROKER",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "optional_host_roles": [],
                    "hosts": host_list,
                    "service": "ROCKETMQ",
                },
                {
                    "display": True,
                    "component": "ROCKETMQ_CONSOLE",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "optional_host_roles": [],
                    "hosts": host_list,
                    "service": "ROCKETMQ",
                },
                {
                    "component": "AMBARI_SLAVE",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": host_list[1:],
                },
            ],
            "instanceInfo": node_list,
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "rocket_extension": {
                "administrator_username": "os_admin",
                "administrator_password": "Y2xvdWRAMTIz",
                "replicates": slave_node + 1,
                "disk_sync_type": "SYNC",
                "cluster_sync_type": "SYNC",
            },
            "imageId": image_id,
            "version": {"ROCKETMQ": "4.8"},
        }
        if master_node + slave_node == 1:
            del data['service'][-1]
        return self._post(uri, data, headers=headers)

    def get_rocketmq_node_flavor(self):
        """获取rocketmq虚拟机节点规格"""
        uri = (
            '/api/mqs/app/v1.0/iaasCluster/v1/bigdata/prepare/flavor?wheCloudDisk=false'
        )
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        response = self._get(uri=uri, headers=headers)
        return response

    def get_service_status(self, vip, cluster_name):
        """
        获取rocketmq组件的状态
        :param vip: 集群虚IP
        :param cluster_name: 集群名称

        """
        uri = f"/api/mqs/app/v1.0/omc/operationAndMaintenanceCenter/clusterManagement/serviceList?hostIp={vip}&clusterName={cluster_name}"
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        response = self._get(uri=uri, headers=headers)
        return response

    def get_cluster_state(self, cluster_name):
        """
        获取rocketmq 集群状态
        :param cluster_name:
        :return:
        """
        uri = f'/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/state'
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._get(uri=uri, headers=headers)

    def start_or_start_rocketmq_service(self, cluster_name, action):
        """启动或停止rocketmq组件

        Args:
            cluster_name (_type_): 集群名字
            action (_type_): 动作 取值为： stop 或start
        """
        uri = f'/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/service/ROCKETMQ/{action}'
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._put(uri, headers=headers)

    def restart_rocketmq_service(self, cluster_name):
        """重启 rocketmq 组件"""
        uri = f'/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/service/rocketmq/restart'
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._post(uri, headers=headers)

    def expand_rocketmq_cluster(
        self,
        cluster_id,
        cluster_name,
        net_name,
        net_id,
        zone_id,
        flavor_name,
        flavor_id,
        scale_num: int,
    ):
        """扩容rocketmq集群
        Args:
            cluster_id (_type_): 集群id
            node_num (_type_): 扩容的节点数量 可取值 2   4   6
        """
        uri = f'/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster/{cluster_id}'

        node_list = []
        for i in range(1, scale_num + 1):
            node = {
                "roleNameList": ["extend-" + str(i)],
                "title": "RocketMQ实例",
                "azoneId": zone_id,
                "azoneName": settings['LABEL_NAME'],
                "virtType": "CAS",
                "flavorId": flavor_id,
                "storageTypeId": None,
                "onlyId": flavor_id + "_",
                "name": flavor_name,
                "fixIp": "",
                "fixManagementIp": "",
            }
            node_list.append(node)
        post_data = {
            "expand": True,
            "node_count": scale_num,
            "cluster_name": cluster_name,
            "flavor_id": flavor_id,
            "storageTypeId": None,
            "node_processes": ["ROCKETMQ_BROKER", "ROCKETMQ_NAMESRV"],
            "instanceInfo": node_list,
            "clusterData": node_list,
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "neutron_management_network_id": net_id,
            "neutron_management_network_name": net_name,
            "managerNetwork": net_id,
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "quota": 99,
            "quotaText": "可用999969800G / 全部1000000000G",
            "replicates": 1,
            "leader_count": 0,
            "extend_observer_count": 0,
        }

        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._post(uri=uri, json=post_data, headers=headers)

    def download_cluster_log(self, cluster_id, cluster_name, node_ip):
        """下载rocketmq集群日志

        Args:
            cluster_id (_type_): _description_
            cluster_name (_type_): _description_
            node_ip (_type_): _description_

        Returns:
            _type_: _description_
        """
        uri = '/api/mqs/app/v1.0/log/v1/mqs/syslog/collect/clusterLog'
        data = {
            "cluster_id": cluster_id,
            "service_type": "rocketmq",
            "virt_type": "CAS",
            "log_path": "/var/log/rocketmq",
            "cluster_name": cluster_name,
            "node_ip": node_ip,
        }
        return self._post(uri, data)

    def get_nodes_list(self, master_ip, cluster_name, page=1, size=10):
        """获取指定 rocketmq 集群的主机列表"""
        uri = f'/api/mqs/app/v1.0/omc/operationAndMaintenanceCenter/nodeManagement/list?masterIp={master_ip}&clusterName={cluster_name}&page={page}&size={size}&orderByField=onLine&order=descending'
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._get(uri, headers=headers)

    def create_alert_contact(self, name, tel, email):
        """创建告警联系人"""
        uri = '/api/mqs/app/v1.0/alert/v1/alert/person'
        data = {"name": name, "phone": tel, "email": email}
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._post(uri, data)

    def get_alert_contacts(self, page=1, size=10, name=None):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/person?page={page}&pageSize={size}'
        if name:
            uri = uri + '&name=' + name
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._get(uri, headers=headers)

    def create_alert_group(self, name, user_id_list, desc=""):
        """新建告警联系组

        Args:
            name (_type_): _description_
            user_id_list (_type_): _description_
            desc (_type_): _description_
        """

        uri = '/api/mqs/app/v1.0/alert/v1/alert/group'
        data = {"name": name, "description": desc, "listUserIds": user_id_list}
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._post(uri, json=data, headers=headers)

    def delete_alert_contact(self, person_id):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/person?id={person_id}'
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._delete(uri, headers=headers)

    def delete__alert_group(self, group_id):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/group?id={group_id}'
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._delete(uri, headers=headers)

    def get_alert_group_list(self, name=None):
        uri = '/api/mqs/app/v1.0/alert/v1/alert/group?page=1&pageSize=10'
        if name:
            uri = uri + '&name=' + name
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._get(uri, headers=headers)

    def modify_alert_group(self, name, user_id_list, desc, group_id):
        uri = '/api/mqs/app/v1.0/alert/v1/alert/group'
        data = {
            "name": name,
            "description": desc,
            "listUserIds": user_id_list,
            "id": group_id,
        }
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._put(uri, data, headers=headers)

    def get_alerts_list(self, cluster_id='', host='', level='', status=''):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/info/list?page=1&pageSize=10&clusterId={cluster_id}&host={host}&level={level}&status={status}'
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._get(uri, headers=headers)

    def delete_alerts_message(self, message_id_list):
        uri = '/api/mqs/app/v1.0/alert/v1/alert/info/clear'
        data = {"alertId": message_id_list}
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._delete(uri, data, headers=headers)

    def apply_rocketmq_cluster(
        self,
        master_node,
        cluster_name,
        zone_id,
        net_id,
        keypaire,
        monitor_info,
        flavor_info,
        image_id,
        slave_node=0,
        **kwargs,
    ):

        uri = '/api/mqs/app/v1.0/cluster/deployment/v1/deployment/cluster/iaas/process'
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"

        node_list = []
        host_list = []
        for i in range(1, master_node + slave_node + 1):
            node = {
                "roleNameList": ["master-" + str(i)],
                "title": "RocketMQ实例",
                "azoneId": zone_id,
                "labelName": settings['LABEL_NAME'],
                "azoneName": settings['LABEL_NAME'],
                "virtType": "CAS",
                "flavorId": flavor_info['id'],
                "name": flavor_info['name'],
                "storageTypeId": None,
                "fixIp": "",
                "fixManagementIp": "",
            }
            node_list.append(node)
            host = "master-" + str(i)
            host_list.append(host)
        data = {
            "administrator": "",
            "administrator_password": "",
            "task": {"size": "0", "flavor_id": ""},
            "type": "rocketmq",
            "name": cluster_name,
            "cluster_mode": "0",
            "description": "",
            "whether_ha": True if master_node + slave_node > 1 else False,
            "availability_zone": {
                "id": zone_id,
                "name": settings['LABEL_NAME'],
                "virtType": "CAS",
            },
            "manager_virtual_ip": "",
            "neutron_management_network_id": net_id,
            "neutron_management_network_name": settings['NET_NAME'],
            "keypair_name": keypaire,
            "anti_affinity": False,
            "monitor_on": monitor_info['on'],
            "monitor_interval": monitor_info['interval'],
            "master": {"size": master_node + slave_node},
            "core": {"size": 0, "flavor_id": ""},
            "service": [
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"],
                },
                {
                    "display": True,
                    "component": "ROCKETMQ_NAMESRV",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "optional_host_roles": [
                        "core",
                        "task",
                        "zookeeper",
                        "redis",
                        "kafka",
                        "elasticsearch",
                        "solr",
                    ],
                    "hosts": host_list,
                    "service": "ROCKETMQ",
                },
                {
                    "display": True,
                    "component": "ROCKETMQ_BROKER",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "optional_host_roles": [],
                    "hosts": host_list,
                    "service": "ROCKETMQ",
                },
                {
                    "display": True,
                    "component": "ROCKETMQ_CONSOLE",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "optional_host_roles": [],
                    "hosts": host_list,
                    "service": "ROCKETMQ",
                },
                {
                    "component": "AMBARI_SLAVE",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": host_list[1:],
                },
            ],
            "instanceInfo": node_list,
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "rocket_extension": {
                "administrator_username": "os_admin",
                "administrator_password": "Y2xvdWRAMTIz",
                "replicates": slave_node + 1,
                "disk_sync_type": "SYNC",
                "cluster_sync_type": "SYNC",
            },
            "imageId": image_id,
            "version": {"ROCKETMQ": "4.8"},
        }
        if master_node + slave_node == 1:
            del data['service'][-1]
        return self._post(uri, data, headers=headers)

    def add_rocketmq_user(self, user_name, passwd, cluster_id):
        """新建rocketmq用户"""
        uri = f'/api/mqs/app/v1.0/rocketmq/manage/api/v1/acl?clusterId={cluster_id}'
        data = {
            "accessKey": user_name,
            "secretKey": passwd,
            "defaultTopicPermission": 12,
            "defaultGroupPermission": 12,
        }
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._post(uri, data, headers=headers)

    def delete_rocketmq_user(self, user_name, cluster_id):
        uri = f'/api/mqs/app/v1.0/rocketmq/manage/api/v1/acl?clusterId={cluster_id}&accessKey={user_name}'
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._delete(uri, headers=headers)

    def get_rocketmq_user(self, cluster_id, page=1, size=10, **kwargs):
        uri = f'/api/mqs/app/v1.0/rocketmq/manage/api/v1/acl?clusterId={cluster_id}&page={page}&size={size}'
        if kwargs:
            uri = uri + '&' + urlencode(kwargs)
        headers = self.ss.headers
        headers['servicename'] = "rocketmq"
        return self._get(uri, headers=headers)
