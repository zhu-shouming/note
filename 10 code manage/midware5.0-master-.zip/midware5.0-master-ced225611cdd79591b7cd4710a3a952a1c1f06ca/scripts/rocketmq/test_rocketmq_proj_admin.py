import pytest
import os
from resource.base.client import PAASClient
import yaml, datetime
from resource.utils.common import *
from config.config import settings
from resource.utils.user import PAASLogin

cur_path = os.path.dirname(os.path.realpath(__file__))
datafile = os.path.join(cur_path, 'data.yaml')

with open(datafile, encoding='utf-8') as f:
    data = yaml.safe_load(f)


@pytest.mark.rocketmq
@allure.feature("消息中间件rocketmq")
@allure.story("消息中间件rocketmq--组织管理员")
class TestRocketmq:
    def setup_class(self):
        user = PAASClient(
            PAASLogin(
                settings.PROJ_ADMIN, settings.PASSWORD, settings.HOST, settings.PORT
            )
        )
        name = 'auto' + get_random_string(4).lower()
        r_flavor = user.rocket_client.get_rocketmq_node_flavor()
        check_status_code(r_flavor, 200)
        flavor = "2*8*40"
        flavor_id = get_value_from_json(
            r_flavor, f"$.data.virtual[?(@.name=='{flavor}')].id"
        )
        assert flavor_id, f"获取规格信息失败，指定的规格{flavor}不存在"
        self.flavor_id = flavor_id
        mq_passwd = encode_str_to_base64("cloud@123")
        servicename = "rocketmq"
        info_prepare = user.mqs_client.get_prepare_info(servicename)
        check_status_code(info_prepare, 200)
        keypaire = get_value_from_json(info_prepare, "$..keypairs..name")

        zone_name = settings['LABEL_NAME']
        net_name = settings['NET_NAME']
        zone_id = get_value_from_json(
            info_prepare, f"$..azones[?(@.zone=='{zone_name}')].id"
        )
        net_id = get_value_from_json(
            info_prepare,
            f"$..networkAndAzone[?(@.networkName=='{net_name}')].networkId",
        )
        image_info_response = user.mqs_client.get_default_image_info('rocketmq')
        check_status_code(image_info_response)
        image_id = image_info_response.json()['data']['imageId']
        assert image_id, "获取rocketmq默认镜像失败"
        assert net_id, f"获取网络信息失败"
        assert zone_id, f"获取可用域信息失败"
        self.net_id = net_id
        self.zone_id = zone_id
        self.image_id = image_id
        monitor_info = {'on': 1, 'interval': '15s'}
        flavor_info = {'id': flavor_id, 'name': flavor}
        resp = user.rocket_client.create_rocketmq_cluster(
            2, name, zone_id, net_id, keypaire, monitor_info, flavor_info, image_id
        )
        check_status_code(resp, 200)
        check_jsonpath = f"$.data[?(@.name=='{name}')].status"
        result = wait_action_success_until_timeout(
            user.mqs_client.get_bigdata_cluster,
            check_jsonpath,
            "ACTIVE",
            60,
            1800,
            "rocketmq",
        )
        assert result, "创建rocketmq集群失败"

        self.cluster_name = name
        check_info = user.mqs_client.get_bigdata_cluster("rocketmq")
        assert get_value_from_json(
            check_info, f"$.data[?(@.name=='{name}')]"
        ), "初始化失败， 创建rocketmq集群失败"
        self.cluster_id = get_value_from_json(
            check_info, f"$.data[?(@.name=='{name}')].id"
        )
        self.cluster_vip = get_value_from_json(
            check_info, f"$.data[?(@.name=='{name}')].realIp"
        )
        r = user.active_client.get_nodes_list(self.cluster_vip, self.cluster_name)
        check_status_code(r)
        self.node_ip = get_value_from_json(r, "$..internalIp", list_flag=True)
    
    def teardown_class(self):
        user = PAASClient(
            PAASLogin(
                settings.USERNAME, settings.PASSWORD, settings.HOST, settings.PORT
            )
        )
        user.mqs_client.delete_bigdata_cluster("rocketmq", self.cluster_name)

    @pytest.mark.L5
    @pytest.mark.parametrize("args", data['create_rocketmq'])
    def test_create_rocketmq_cluster(self, paas_proj_admin_login: PAASClient, args):
        allure.dynamic.title(args['title'])
        cluster_name = 'auto' + get_random_string(4).lower()
        r_flavor = paas_proj_admin_login.rocket_client.get_rocketmq_node_flavor()
        check_status_code(r_flavor, 200)
        flavor = args['flavor']
        flavor_id = get_value_from_json(
            r_flavor, f"$.data.virtual[?(@.name=='{flavor}')].id"
        )
        assert flavor_id, f"获取规格信息失败，指定的规格{flavor}不存在"
        self.flavor_id = flavor_id
        mq_passwd = encode_str_to_base64("cloud@123")
        servicename = "rocketmq"
        info_prepare = paas_proj_admin_login.mqs_client.get_prepare_info(servicename)
        check_status_code(info_prepare, 200)
        keypaire = get_value_from_json(info_prepare, "$..keypairs..name")

        zone_name = settings['LABEL_NAME']
        net_name = settings['NET_NAME']
        zone_id = get_value_from_json(
            info_prepare, f"$..azones[?(@.zone=='{zone_name}')].id"
        )
        net_id = get_value_from_json(
            info_prepare,
            f"$..networkAndAzone[?(@.networkName=='{net_name}')].networkId",
        )
        image_info_response = paas_proj_admin_login.mqs_client.get_default_image_info(
            'rocketmq'
        )
        check_status_code(image_info_response)
        image_id = image_info_response.json()['data']['imageId']
        assert image_id, "获取rocketmq默认镜像失败"
        assert net_id, f"获取网络信息失败"
        assert zone_id, f"获取可用域信息失败"
        monitor_info = {'on': args['monitor_on'], 'interval': args['monitor_interval']}
        flavor_info = {'id': flavor_id, 'name': flavor}
        slave_node = args['slave_num'] if 'slave_num' in args else 0
        resp = paas_proj_admin_login.rocket_client.create_rocketmq_cluster(
            args['node_num'],
            cluster_name,
            zone_id,
            net_id,
            keypaire,
            monitor_info,
            flavor_info,
            image_id,
            slave_node,
        )
        check_status_code(resp, 200)
        check_jsonpath = f"$.data[?(@.name=='{cluster_name}')].status"
        result = wait_action_success_until_timeout(
            paas_proj_admin_login.mqs_client.get_bigdata_cluster,
            check_jsonpath,
            "ACTIVE",
            60,
            1800,
            "rocketmq",
        )
        assert result, "创建rabbitmq集群失败"
        logger.info('清理测试环境')
        paas_proj_admin_login.mqs_client.delete_bigdata_cluster(
            'rocketmq', cluster_name
        )

    @pytest.mark.L5
    @allure.title("停止和启动rocketmq组件")
    def test_stop_and_start_rocketmq_service(self, paas_proj_admin_login: PAASClient):
        with allure.step("校验预制rocketmq集群组件状态是否正常"):
            r1 = paas_proj_admin_login.rocket_client.get_cluster_state(
                self.cluster_name
            )
            assert get_value_from_json(r1, "$..state") == "STARTED"
        with allure.step("停止rocketmq组件然后检验组件状态"):
            stop_resp = (
                paas_proj_admin_login.rocket_client.start_or_start_rocketmq_service(
                    self.cluster_name, "stop"
                )
            )
            check_status_code(stop_resp, 200)
            result = wait_action_success_until_timeout(
                paas_proj_admin_login.rocket_client.get_cluster_state,
                "$..state",
                "INSTALLED",
                5,
                60,
                self.cluster_name,
            )
            assert result, f"停止rocketmq组件操作失败"
        with allure.step("启动rocketmq组件然后检验状态"):
            time.sleep(5)
            start_resp = (
                paas_proj_admin_login.rocket_client.start_or_start_rocketmq_service(
                    self.cluster_name, "start"
                )
            )
            check_status_code(start_resp, 200)
            result = wait_action_success_until_timeout(
                paas_proj_admin_login.rocket_client.get_cluster_state,
                "$..state",
                "STARTED",
                5,
                60,
                self.cluster_name,
            )
            assert result, f"启动rocketmq组件操作失败"

    @pytest.mark.L5
    @allure.title("重启rocketmq组件")
    def test_restart_rocketmq_service(self, paas_proj_admin_login: PAASClient):
        with allure.step("校验预制rocketmq集群组件状态是否正常"):
            response = paas_proj_admin_login.rocket_client.get_cluster_state(
                self.cluster_name
            )
            assert get_value_from_json(response, "$..state") == "STARTED"
        with allure.step("重启组件"):
            act_resp = paas_proj_admin_login.rocket_client.restart_rocketmq_service(
                self.cluster_name
            )
            check_status_code(act_resp, 200)
            assert get_value_from_json(act_resp, "$..Requests.status") == "Accepted"
            result = wait_action_success_until_timeout(
                paas_proj_admin_login.rocket_client.get_cluster_state,
                "$..state",
                "STARTED",
                5,
                60,
                self.cluster_name,
            )
            assert result, f"重启rocketmq组件操作失败"

    # @pytest.mark.L5
    # @allure.title("给rocketmq集群扩容")
    # @pytest.mark.parametrize("args", data['scale_mq_cluster'])
    # def test_scale_rocketmq_cluster(self, paas_proj_admin_login: PAASClient, args):
    #     with allure.step("校验预制rocketmq集群组件状态是否正常"):
    #         response = paas_proj_admin_login.rocket_client.get_service_status(
    #             self.cluster_vip, self.cluster_name
    #         )
    #         assert get_value_from_json(response, "$.status") == "success"
    #         assert get_value_from_json(response, "$.errorCode") == 0
    #         assert get_value_from_json(response, "$..serviceState") == "STARTED"
    #     with allure.step("给集群扩容"):
    #         net = settings['NET_NAME']
    #         net_id = self.net_id
    #         resp = paas_proj_admin_login.rocket_client.expand_rocketmq_cluster(
    #             self.cluster_id,
    #             self.cluster_name,
    #             net,
    #             net_id,
    #             self.zone_id,
    #             args['flavor'],
    #             self.flavor_id,
    #             args['node_num'],
    #         )

    #         check_status_code(resp, 200)
    #         result = wait_action_success_until_timeout(
    #             paas_proj_admin_login.rocket_client.get_nodes_list,
    #             "$..total",
    #             3,
    #             20,
    #             600,
    #             self.cluster_vip,
    #             self.cluster_name,
    #         )
    #         assert result, "扩容rocketmq集群失败"

    @pytest.mark.L5
    @allure.title('admin删除rocketmq集群')
    def test_delete_mq(self, paas_proj_admin_login: PAASClient):
        logger.info("teardown部分已多次覆盖删除集群， 此处不再重复")
        # name = 'xzpo'

        # r = paas_proj_admin_login.mqs_client.delete_bigdata_cluster(
        #     "rocketmq", name)
        # check_status_code(r, 200)
        # check_jsonpath = f"$.data[?(@.name=='{name}')]"
        # result = wait_action_success_until_timeout(
        #     paas_proj_admin_login.mqs_client.get_bigdata_cluster,
        #     check_jsonpath,
        #     False,
        #     10,
        #     200,
        #     "rocketmq",
        # )
        # assert result, "操作超时， 删除rocketmq 集群失败"

    @pytest.mark.L5
    @allure.title('运行日志收集')
    def test_download_running_log(self, paas_proj_admin_login: PAASClient):
        with allure.step("选择时间段开始收集日志"):
            begin = (datetime.datetime.now() - datetime.timedelta(hours=24)).strftime(
                '%Y-%m-%d'
            )
            end = datetime.datetime.now().strftime('%Y-%m-%d')
            r = paas_proj_admin_login.mqs_client.check_downloaded_server_log(
                "rocketmq", "22", "Passw0rd@_", begin, end
            )
            check_status_code(r, 200)
            log_id = get_value_from_json(r, "$.data")
            assert log_id, f"运行日志收集失败"
        with allure.step("确认日志下载进度"):
            result = wait_action_success_until_timeout(
                paas_proj_admin_login.mqs_client.check_download_log_progress,
                "$.data",
                "Completed",
                10,
                300,
                "rocketmq",
                log_id,
            )
            assert result, "运行日志下载失败"

    @pytest.mark.L5
    @allure.title('集群日志收集')
    def test_download_cluster_log(self, paas_proj_admin_login: PAASClient):
        with allure.step("选择集群中的某个节点开始收集日志"):
            r = paas_proj_admin_login.rocket_client.download_cluster_log(
                self.cluster_id, self.cluster_name, self.node_ip[0]
            )
            check_status_code(r, 200)
            log_id = get_value_from_json(r, "$.data")
            assert log_id, f"运行日志收集失败"
        with allure.step("确认日志下载进度"):
            result = wait_action_success_until_timeout(
                paas_proj_admin_login.mqs_client.check_download_log_progress,
                "$.data",
                "Completed",
                10,
                300,
                "rocketmq",
                log_id,
            )
            assert result, "集群日志下载失败"

    @pytest.mark.L5
    @allure.title("admin用户新建rocketmq集群告警联系人")
    @pytest.mark.parametrize("args", data['create_alert_contact'])
    def test_create_alert_contact(self, paas_proj_admin_login: PAASClient, args):
        name = get_random_string(5)
        resp = paas_proj_admin_login.rocket_client.create_alert_contact(
            name, args['tel'], args['email']
        )
        check_status_code(resp, 200)
        assert get_value_from_json(resp, "$.data.success"), "给rocketmq集群新建告警联系人失败"
        check_resp = paas_proj_admin_login.rocket_client.get_alert_contacts(name=name)
        check_status_code(check_resp, 200)
        assert get_value_from_json(check_resp, "$..total") == 1, "新建告警联系人失败"

    @pytest.mark.L5
    @allure.title("新建告警联系组")
    def test_create_alert_group(self, paas_proj_admin_login: PAASClient):
        person1 = "p1" + get_random_string(4).lower()
        person2 = "p2" + get_random_string(4).lower()
        resp = paas_proj_admin_login.rocket_client.create_alert_contact(
            person1, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        resp = paas_proj_admin_login.rocket_client.create_alert_contact(
            person2, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        check_r = paas_proj_admin_login.rocket_client.get_alert_contacts()
        user1 = get_value_from_json(check_r, f"$.data[?(@.name=='{person1}')].id")
        user2 = get_value_from_json(check_r, f"$.data[?(@.name=='{person2}')].id")
        assert user1 and user2, "初始化工作--新建告警联系人失败"
        group_name = "test" + get_random_string(4).lower()
        users_list = [user1, user2]
        result = paas_proj_admin_login.rocket_client.create_alert_group(
            group_name, users_list
        )
        check_status_code(result, 200)

    @pytest.mark.L5
    @allure.title("删除告警联系组")
    def test_delete_aleret_group(self, paas_proj_admin_login: PAASClient):
        person1 = "p1" + get_random_string(4).lower()
        person2 = "p2" + get_random_string(4).lower()
        resp = paas_proj_admin_login.rocket_client.create_alert_contact(
            person1, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        resp = paas_proj_admin_login.rocket_client.create_alert_contact(
            person2, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        check_r = paas_proj_admin_login.rocket_client.get_alert_contacts()
        user1 = get_value_from_json(check_r, f"$.data[?(@.name=='{person1}')].id")
        user2 = get_value_from_json(check_r, f"$.data[?(@.name=='{person2}')].id")
        assert user1 and user2, "初始化工作--新建告警联系人失败"
        group_name = "test" + get_random_string(4).lower()
        users_list = [user1, user2]
        result = paas_proj_admin_login.rocket_client.create_alert_group(
            group_name, users_list
        )
        check_status_code(result, 200)
        time.sleep(3)
        r = paas_proj_admin_login.rocket_client.get_alert_group_list(group_name)
        group_id = get_value_from_json(r, "$..id")
        del_r = paas_proj_admin_login.rocket_client.delete__alert_group(group_id)
        check_status_code(del_r, 200)
        time.sleep(1)
        check_resp = paas_proj_admin_login.rocket_client.get_alert_group_list(
            group_name
        )
        assert get_value_from_json(check_resp, "$..total") == 0, "删除告警联系组失败"

    @pytest.mark.L5
    @allure.title("组织管理员新建rocketmq用户")
    def test_add_rockermq_user(self, paas_proj_admin_login: PAASClient):
        user_name = 'auto' + get_random_string(4).lower()
        passwd = 'cloud@23'
        resp = paas_proj_admin_login.rocket_client.add_rocketmq_user(
            user_name, passwd, self.cluster_id
        )
        check_status_code(resp, 200)
        time.sleep(3)
        check_resp = paas_proj_admin_login.rocket_client.get_rocketmq_user(
            self.cluster_id, accessKey=user_name
        )
        check_status_code(check_resp)
        assert get_value_from_json(check_resp, "$..total") == 1, "新建rocketmq用户失败"
        logger.info('清理测试环境')
        paas_proj_admin_login.rocket_client.delete_rocketmq_user(
            user_name, self.cluster_id
        )

    @pytest.mark.L5
    @allure.title("组织管理员删除rocketmq用户")
    def test_del_rocketmq_user(self, paas_proj_admin_login: PAASClient):
        with allure.step('初始化， 先新建一个rocketmq用户'):
            user_name = 'auto' + get_random_string(4).lower()
            passwd = 'cloud@23'
            resp = paas_proj_admin_login.rocket_client.add_rocketmq_user(
                user_name, passwd, self.cluster_id
            )
            check_status_code(resp, 200)
            time.sleep(3)
            check_resp = paas_proj_admin_login.rocket_client.get_rocketmq_user(
                self.cluster_id, accessKey=user_name
            )
            check_status_code(check_resp)
            assert get_value_from_json(check_resp, "$..total") == 1, "新建rocketmq用户失败"
        with allure.step('删除用户'):
            r = paas_proj_admin_login.rocket_client.delete_rocketmq_user(
                user_name, self.cluster_id
            )
            check_status_code(r, 200)
            check_del = paas_proj_admin_login.rocket_client.get_rocketmq_user(
                self.cluster_id, accessKey=user_name
            )
            check_status_code(check_del)
            assert get_value_from_json(check_del, "$..total") == 0, "删除rocketmq用户失败"
