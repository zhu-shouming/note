from resource.base.client import PAASClient
from resource.utils.user import PAASLogin
from config.config import settings
from resource.utils.common import *


def manager_agree_cluster_apply(cluster_name):
    proj_admin = PAASClient(
        PAASLogin(settings.PROJ_ADMIN, settings.PASSWORD, settings.HOST, settings.PORT)
    )
    user_id = proj_admin.login_info.user_id
    resp = proj_admin.sys_client.get_process_by_name(cluster_name, user_id)
    check_status_code(resp, 200)
    process_id = get_value_from_json(resp, '$.data[0].id')
    assert process_id, "获取审批流程失败"
    proj_admin.sys_client.deal_with_process(process_id, True)
