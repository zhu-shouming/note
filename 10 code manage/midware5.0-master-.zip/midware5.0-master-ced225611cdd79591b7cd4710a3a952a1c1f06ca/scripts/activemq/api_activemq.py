from resource.base.rest_api_base import RestAPIBase
from urllib.parse import urlencode
from config.config import settings


class ActivemqAPI(RestAPIBase):
    def create_activemq_cluster(
        self,
        node_num,
        cluster_name,
        zone_id,
        net_id,
        image_id,
        flavor_info,
        monitor_info,
        keypair,
        desc,
        **kwargs,
    ):
        uri = '/api/mqs/app/v1.0/iaasCluster/v1/bigdata/cluster'
        data = {
            "task": {"size": "0", "flavor_id": ""},
            "type": "activemq",
            "name": cluster_name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": "cloud@123",
            "description": desc,
            "whether_ha": True if node_num == 3 else False,
            "availability_zone": {
                "id": zone_id,
                "name": settings['LABEL_NAME'],
                "virtType": "CAS",
            },
            "manager_virtual_ip": "",
            "neutron_management_network_id": net_id,
            "neutron_management_network_name": settings['NET_NAME'],
            "keypair_name": keypair,
            "anti_affinity": False,
            "monitor_on": monitor_info['on'],
            "monitor_interval": monitor_info['interval'],
            "master": {"size": 2 if node_num == 3 else 1},
            "core": {"size": 1 if node_num == 3 else 0, "flavor_id": ""},
            "service": [
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"],
                },
                {
                    "display": True,
                    "component": "ACTIVEMQ",
                    "relation": "",
                    "host_roles_default": ["master", "core"]
                    if node_num == 3
                    else ["master"],
                    "optional_host_roles": [],
                    "hosts": ["master-1", "master-2", "core-1"]
                    if node_num == 3
                    else ["master-1"],
                    "service": "ACTIVEMQ",
                },
                {
                    "component": "AMBARI_SLAVE",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-2"],
                },
            ],
            "instanceInfo": [
                {
                    "roleNameList": ["master-1"],
                    "title": "ActiveMQ实例",
                    "azoneId": zone_id,
                    "labelName": settings['LABEL_NAME'],
                    "azoneName": settings['LABEL_NAME'],
                    "virtType": "CAS",
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                },
                {
                    "roleNameList": ["master-2"],
                    "title": "ActiveMQ实例",
                    "azoneId": zone_id,
                    "labelName": settings['LABEL_NAME'],
                    "azoneName": settings['LABEL_NAME'],
                    "virtType": "CAS",
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                },
                {
                    "roleNameList": ["core-1"],
                    "title": "ActiveMQ实例",
                    "azoneId": zone_id,
                    "labelName": settings['LABEL_NAME'],
                    "azoneName": settings['LABEL_NAME'],
                    "virtType": "CAS",
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                },
            ],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "db_schema": "follower",
            "activemq_config": {
                "activemqPort": "61616",
                "activemqManagementPort": "8161",
                "activemqManagementPassword": "cloud@123",
            },
            "imageId": image_id,
            "version": {"ACTIVEMQ": "5.15.9"},
        }
        if node_num == 1:
            del data['service'][-1]
            del data['instanceInfo'][-2:]
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._post(uri, data, headers=headers)


    def get_activemq_node_flavor(self):
        """获取activemq虚拟机节点规格"""
        uri = (
            '/api/mqs/app/v1.0/iaasCluster/v1/bigdata/prepare/flavor?wheCloudDisk=false'
        )
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        response = self._get(uri=uri, headers=headers)
        return response

    def get_service_status(self, vip, cluster_name):
        """
        获取activemq组件的状态
        :param vip: 集群虚IP
        :param cluster_name: 集群名称

        """
        uri = f"/api/mqs/app/v1.0/omc/operationAndMaintenanceCenter/clusterManagement/serviceList?hostIp={vip}&clusterName={cluster_name}"
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        response = self._get(uri=uri, headers=headers)
        return response

    def start_or_start_activemq_service(self, cluster_name, action):
        """启动或停止activemq组件

        Args:
            cluster_name (_type_): 集群名字
            action (_type_): 动作 取值为： stop 或start
        """
        uri = f'/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/service/ACTIVEMQ/{action}'
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._put(uri, headers=headers)

    def restart_activemq_service(self, cluster_name):
        """重启 activemq 组件"""
        uri = f'/api/mqs/app/v1.0/cluster/deployment/v1/cluster/{cluster_name}/service/activemq/restart'
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._post(uri, headers=headers)

    def download_cluster_log(self, cluster_id, cluster_name, node_ip):
        """下载activemq集群日志

        Args:
            cluster_id (_type_): _description_
            cluster_name (_type_): _description_
            node_ip (_type_): _description_

        Returns:
            _type_: _description_
        """
        uri = '/api/mqs/app/v1.0/log/v1/mqs/syslog/collect/clusterLog'
        data = {
            "cluster_id": cluster_id,
            "service_type": "activemq",
            "virt_type": "CAS",
            "log_path": "/var/log/activemq",
            "cluster_name": cluster_name,
            "node_ip": node_ip,
        }
        return self._post(uri, data)

    def get_nodes_list(self, master_ip, cluster_name, page=1, size=10):
        """获取指定 activemq 集群的主机列表"""
        uri = f'/api/mqs/app/v1.0/omc/operationAndMaintenanceCenter/nodeManagement/list?masterIp={master_ip}&clusterName={cluster_name}&page={page}&size={size}&orderByField=onLine&order=descending'
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._get(uri, headers=headers)

    def create_alert_contact(self, name, tel, email):
        """创建告警联系人"""
        uri = '/api/mqs/app/v1.0/alert/v1/alert/person'
        data = {"name": name, "phone": tel, "email": email}
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._post(uri, data, headers=headers)

    def get_alert_contacts(self, page=1, size=10, name=None):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/person?page={page}&pageSize={size}'
        if name:
            uri = uri + '&name=' + name
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._get(uri, headers=headers)

    def create_alert_group(self, name, user_id_list, desc=""):
        """新建告警联系组

        Args:
            name (_type_): _description_
            user_id_list (_type_): _description_
            desc (_type_): _description_
        """

        uri = '/api/mqs/app/v1.0/alert/v1/alert/group'
        data = {"name": name, "description": desc, "listUserIds": user_id_list}
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._post(uri, json=data, headers=headers)

    def delete_alert_contact(self, person_id):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/person?id={person_id}'
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._delete(uri, headers=headers)

    def delete__alert_group(self, group_id):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/group?id={group_id}'
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._delete(uri, headers=headers)

    def get_alert_group_list(self, name=None):
        uri = '/api/mqs/app/v1.0/alert/v1/alert/group?page=1&pageSize=10'
        if name:
            uri = uri + '&name=' + name
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._get(uri, headers=headers)

    def modify_alert_group(self, name, user_id_list, desc, group_id):
        uri = '/api/mqs/app/v1.0/alert/v1/alert/group'
        data = {
            "name": name,
            "description": desc,
            "listUserIds": user_id_list,
            "id": group_id,
        }
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._put(uri, data, headers=headers)

    def get_alerts_list(self, cluster_id='', host='', level='', status=''):
        uri = f'/api/mqs/app/v1.0/alert/v1/alert/info/list?page=1&pageSize=10&clusterId={cluster_id}&host={host}&level={level}&status={status}'
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._get(uri, headers=headers)

    def delete_alerts_message(self, message_id_list):
        uri = '/api/mqs/app/v1.0/alert/v1/alert/info/clear'
        data = {"alertId": message_id_list}
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._delete(uri, data, headers=headers)

    def apply_activemq_cluster(
        self,
        node_num,
        cluster_name,
        zone_id,
        net_id,
        image_id,
        flavor_info,
        monitor_info,
        keypair,
        desc,
        **kwargs,
    ):
        uri = '/api/mqs/app/v1.0/cluster/deployment/v1/deployment/cluster/iaas/process'
        data = {
            "task": {"size": "0", "flavor_id": ""},
            "type": "activemq",
            "name": cluster_name,
            "cluster_mode": "0",
            "administrator": "admin",
            "administrator_password": "cloud@123",
            "description": desc,
            "whether_ha": True if node_num == 3 else False,
            "availability_zone": {
                "id": zone_id,
                "name": settings['LABEL_NAME'],
                "virtType": "CAS",
            },
            "manager_virtual_ip": "",
            "neutron_management_network_id": net_id,
            "neutron_management_network_name": settings['NET_NAME'],
            "keypair_name": keypair,
            "anti_affinity": False,
            "monitor_on": monitor_info['on'],
            "monitor_interval": monitor_info['interval'],
            "master": {"size": 2 if node_num == 3 else 1},
            "core": {"size": 1 if node_num == 3 else 0, "flavor_id": ""},
            "service": [
                {
                    "component": "AMBARI",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-1"],
                },
                {
                    "display": True,
                    "component": "ACTIVEMQ",
                    "relation": "",
                    "host_roles_default": ["master", "core"]
                    if node_num == 3
                    else ["master"],
                    "optional_host_roles": [],
                    "hosts": ["master-1", "master-2", "core-1"]
                    if node_num == 3
                    else ["master-1"],
                    "service": "ACTIVEMQ",
                },
                {
                    "component": "AMBARI_SLAVE",
                    "display": False,
                    "service": "AMBARI",
                    "relation": "",
                    "host_roles_default": ["master"],
                    "hosts": ["master-2"],
                },
            ],
            "instanceInfo": [
                {
                    "roleNameList": ["master-1"],
                    "title": "ActiveMQ实例",
                    "azoneId": zone_id,
                    "labelName": settings['LABEL_NAME'],
                    "azoneName": settings['LABEL_NAME'],
                    "virtType": "CAS",
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                },
                {
                    "roleNameList": ["master-2"],
                    "title": "ActiveMQ实例",
                    "azoneId": zone_id,
                    "labelName": settings['LABEL_NAME'],
                    "azoneName": settings['LABEL_NAME'],
                    "virtType": "CAS",
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                },
                {
                    "roleNameList": ["core-1"],
                    "title": "ActiveMQ实例",
                    "azoneId": zone_id,
                    "labelName": settings['LABEL_NAME'],
                    "azoneName": settings['LABEL_NAME'],
                    "virtType": "CAS",
                    "flavorId": flavor_info['id'],
                    "name": flavor_info['name'],
                    "storageTypeId": None,
                    "fixIp": "",
                    "fixManagementIp": "",
                },
            ],
            "independentManagementNetworkId": "",
            "independentManagementNetworkName": "",
            "cloudDiskType": "",
            "cloudDiskCapacity": 0,
            "storageResourceZone": [],
            "db_schema": "follower",
            "activemq_config": {
                "activemqPort": "61616",
                "activemqManagementPort": "8161",
                "activemqManagementPassword": "cloud@123",
            },
            "imageId": image_id,
            "version": {"ACTIVEMQ": "5.15.9"},
        }
        if node_num == 1:
            del data['service'][-1]
            del data['instanceInfo'][-2:]
        headers = self.ss.headers
        headers['servicename'] = "activemq"
        return self._post(uri, data, headers=headers)
