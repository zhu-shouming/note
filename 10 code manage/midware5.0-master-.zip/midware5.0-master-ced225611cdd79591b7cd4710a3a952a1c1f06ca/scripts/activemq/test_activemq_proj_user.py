import pytest
import os
from resource.base.client import PAASClient
import yaml, datetime
from resource.utils.common import *
from config.config import settings
from resource.utils.user import PAASLogin
from scripts.activemq.handler_activemq import *

cur_path = os.path.dirname(os.path.realpath(__file__))
datafile = os.path.join(cur_path, 'data.yaml')

with open(datafile, encoding='utf-8') as f:
    data = yaml.safe_load(f)


@pytest.mark.activemq
@allure.feature("消息中间件activemq")
@allure.story("消息中间件activemq--普通用户")
class TestActivemq:
    def setup_class(self):
        user = PAASClient(
            PAASLogin(
                settings.PROJ_USER, settings.PASSWORD, settings.HOST, settings.PORT
            )
        )
        cluster_name = 'auto' + get_random_string(4).lower()
        r_flavor = user.active_client.get_activemq_node_flavor()
        check_status_code(r_flavor, 200)
        flavor = "2*4*40"
        flavor_id = get_value_from_json(
            r_flavor, f"$.data.virtual[?(@.name=='{flavor}')].id"
        )
        assert flavor_id, f"获取规格信息失败，指定的规格{flavor}不存在"
        # mq_passwd = encode_str_to_base64(args['passwd'])
        servicename = "activemq"
        info_prepare = user.mqs_client.get_prepare_info(servicename)
        check_status_code(info_prepare, 200)
        keypaire = get_value_from_json(info_prepare, "$..keypairs..name")
        assert keypaire, f"获取秘钥对信息失败"
        zone_name = settings['LABEL_NAME']
        net_name = settings['NET_NAME']
        zone_id = get_value_from_json(
            info_prepare, f"$..azones[?(@.zone=='{zone_name}')].id"
        )
        net_id = get_value_from_json(
            info_prepare,
            f"$..networkAndAzone[?(@.networkName=='{net_name}')].networkId",
        )

        assert net_id, f"获取网络信息失败"
        assert zone_id, f"获取可用域信息失败"
        image_info_response = user.mqs_client.get_default_image_info('activemq')
        check_status_code(image_info_response)
        image_id = image_info_response.json()['data']['imageId']
        assert image_id, "获取activemq集群默认镜像失败"
        monitor_info = {'on': 1, 'interval': "15s"}
        flavor_info = {'id': flavor_id, 'name': flavor}
        desc = "init cluster"
        resp = user.active_client.apply_activemq_cluster(
            3,
            cluster_name,
            zone_id,
            net_id,
            image_id,
            flavor_info,
            monitor_info,
            keypaire,
            desc,
        )
        time.sleep(3)
        manager_agree_cluster_apply(cluster_name)

        check_status_code(resp, 200)
        check_jsonpath = f"$.data[?(@.name=='{cluster_name}')].status"
        result = wait_action_success_until_timeout(
            user.mqs_client.get_bigdata_cluster,
            check_jsonpath,
            "ACTIVE",
            60,
            1800,
            "activemq",
        )
        assert result, "初始化失败：创建activemq集群失败"

        self.cluster_name = cluster_name
        check_info = user.mqs_client.get_bigdata_cluster("activemq")
        assert get_value_from_json(
            check_info, f"$.data[?(@.name=='{cluster_name}')]"
        ), "初始化失败， 创建rabbitmq集群失败"
        self.cluster_id = get_value_from_json(
            check_info, f"$.data[?(@.name=='{cluster_name}')].id"
        )
        self.cluster_vip = get_value_from_json(
            check_info, f"$.data[?(@.name=='{cluster_name}')].realIp"
        )
        r = user.active_client.get_nodes_list(self.cluster_vip, self.cluster_name)
        check_status_code(r)
        self.node_ip = get_value_from_json(r, "$..internalIp", list_flag=True)

    def teardown_class(self):
        user = PAASClient(
            PAASLogin(
                settings.PROJ_USER, settings.PASSWORD, settings.HOST, settings.PORT
            )
        )
        user.mqs_client.delete_bigdata_cluster("activemq", self.cluster_name)

    @pytest.mark.L5
    @pytest.mark.parametrize("args", data['create_activemq'])
    def test_create_active_mq(self, paas_proj_user_login: PAASClient, args):
        allure.dynamic.title(args['title'])
        cluster_name = 'auto' + get_random_string(4).lower()
        r_flavor = paas_proj_user_login.active_client.get_activemq_node_flavor()
        check_status_code(r_flavor, 200)
        flavor = args['flavor']
        flavor_id = get_value_from_json(
            r_flavor, f"$.data.virtual[?(@.name=='{flavor}')].id"
        )
        assert flavor_id, f"获取规格信息失败，指定的规格{flavor}不存在"
        mq_passwd = encode_str_to_base64(args['passwd'])
        servicename = "activemq"
        info_prepare = paas_proj_user_login.mqs_client.get_prepare_info(servicename)
        check_status_code(info_prepare, 200)
        keypaire = get_value_from_json(info_prepare, "$..keypairs..name")
        zone_name = settings['LABEL_NAME']
        net_name = settings['NET_NAME']
        zone_id = get_value_from_json(
            info_prepare, f"$..azones[?(@.zone=='{zone_name}')].id"
        )
        net_id = get_value_from_json(
            info_prepare,
            f"$..networkAndAzone[?(@.networkName=='{net_name}')].networkId",
        )

        assert net_id, f"获取网络信息失败"
        assert zone_id, f"获取可用域信息失败"
        image_info_response = paas_proj_user_login.mqs_client.get_default_image_info(
            'activemq'
        )
        check_status_code(image_info_response)
        image_id = image_info_response.json()['data']['imageId']
        assert image_id, "获取activemq集群默认镜像失败"
        monitor_info = {'on': args['monitor_on'], 'interval': args['monitor_interval']}
        flavor_info = {'id': flavor_id, 'name': flavor}
        desc = args['desc']
        node_num = int(args['node_num'])
        resp = paas_proj_user_login.active_client.apply_activemq_cluster(
            node_num,
            cluster_name,
            zone_id,
            net_id,
            image_id,
            flavor_info,
            monitor_info,
            keypaire,
            desc,
        )
        check_status_code(resp, 200)
        time.sleep(3)
        manager_agree_cluster_apply(cluster_name)

        check_jsonpath = f"$.data[?(@.name=='{cluster_name}')].status"
        result = wait_action_success_until_timeout(
            paas_proj_user_login.mqs_client.get_bigdata_cluster,
            check_jsonpath,
            "ACTIVE",
            60,
            1800,
            "activemq",
        )
        assert result, "初始化失败：创建activemq集群失败"
        time.sleep(4)
        logger.info('清理测试环境')
        paas_proj_user_login.mqs_client.delete_bigdata_cluster("activemq", cluster_name)

    @pytest.mark.L5
    @allure.title("停止和启动activemq组件")
    def test_stop_and_start_activemq_service(self, paas_proj_user_login: PAASClient):
        with allure.step("校验预制activemq集群组件状态是否正常"):
            response = paas_proj_user_login.active_client.get_service_status(
                self.cluster_vip, self.cluster_name
            )
            assert get_value_from_json(response, "$.status") == "success"
            assert get_value_from_json(response, "$.errorCode") == 0
            assert get_value_from_json(response, "$..serviceState") == "STARTED"
        with allure.step("停止activemq组件然后检验组件状态"):
            stop_resp = (
                paas_proj_user_login.active_client.start_or_start_activemq_service(
                    self.cluster_name, "stop"
                )
            )
            check_status_code(stop_resp, 200)
            result = wait_action_success_until_timeout(
                paas_proj_user_login.active_client.get_service_status,
                "$..serviceState",
                "STOPPED",
                5,
                60,
                self.cluster_vip,
                self.cluster_name,
            )
            assert result, f"停止activemq组件操作失败"
        with allure.step("启动activemq组件然后检验状态"):
            time.sleep(5)
            start_resp = (
                paas_proj_user_login.active_client.start_or_start_activemq_service(
                    self.cluster_name, "start"
                )
            )
            check_status_code(start_resp, 200)
            result = wait_action_success_until_timeout(
                paas_proj_user_login.active_client.get_service_status,
                "$..serviceState",
                "STARTED",
                5,
                60,
                self.cluster_vip,
                self.cluster_name,
            )
            assert result, f"启动activemq组件操作失败"

    @pytest.mark.L0
    @allure.title("重启activemq组件")
    def test_restart_activemq_service(self, paas_proj_user_login: PAASClient):
        with allure.step("校验预制activemq集群组件状态是否正常"):
            response = paas_proj_user_login.active_client.get_service_status(
                self.cluster_vip, self.cluster_name
            )
            assert get_value_from_json(response, "$.status") == "success"
            assert get_value_from_json(response, "$.errorCode") == 0
            assert get_value_from_json(response, "$..serviceState") == "STARTED"
        with allure.step("重启组件"):
            act_resp = paas_proj_user_login.active_client.restart_activemq_service(
                self.cluster_name
            )
            check_status_code(act_resp, 200)
            assert get_value_from_json(act_resp, "$..Requests.status") == "Accepted"
            result = wait_action_success_until_timeout(
                paas_proj_user_login.active_client.get_service_status,
                "$..serviceState",
                "STARTED",
                5,
                60,
                self.cluster_vip,
                self.cluster_name,
            )
            assert result, f"重启activemq组件操作失败"

    @pytest.mark.L5
    @allure.title("admin用户新建activemq集群告警联系人")
    @pytest.mark.parametrize("args", data['create_alert_contact'])
    def test_create_alert_contact(self, paas_proj_user_login: PAASClient, args):
        name = get_random_string(5)
        resp = paas_proj_user_login.active_client.create_alert_contact(
            name, args['tel'], args['email']
        )
        check_status_code(resp, 200)
        assert get_value_from_json(resp, "$.data.success"), "给activemq集群新建告警联系人失败"
        check_resp = paas_proj_user_login.active_client.get_alert_contacts(name=name)
        check_status_code(check_resp, 200)
        assert get_value_from_json(check_resp, "$..total") == 1, "新建告警联系人失败"

    @pytest.mark.L5
    @allure.title("新建告警联系组")
    def test_create_alert_group(self, paas_proj_user_login: PAASClient):
        person1 = "p1" + get_random_string(4).lower()
        person2 = "p2" + get_random_string(4).lower()
        resp = paas_proj_user_login.active_client.create_alert_contact(
            person1, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        resp = paas_proj_user_login.active_client.create_alert_contact(
            person2, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        check_r = paas_proj_user_login.active_client.get_alert_contacts()
        user1 = get_value_from_json(check_r, f"$.data[?(@.name=='{person1}')].id")
        user2 = get_value_from_json(check_r, f"$.data[?(@.name=='{person2}')].id")
        assert user1 and user2, "初始化工作--新建告警联系人失败"
        group_name = "test" + get_random_string(4).lower()
        users_list = [user1, user2]
        result = paas_proj_user_login.active_client.create_alert_group(
            group_name, users_list
        )
        check_status_code(result, 200)

    @pytest.mark.L5
    @allure.title("删除告警联系组")
    def test_delete_aleret_group(self, paas_proj_user_login: PAASClient):
        person1 = "p1" + get_random_string(4).lower()
        person2 = "p2" + get_random_string(4).lower()
        resp = paas_proj_user_login.active_client.create_alert_contact(
            person1, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        resp = paas_proj_user_login.active_client.create_alert_contact(
            person2, "18423472456", "asdf@124.com"
        )
        check_status_code(resp, 200)
        check_r = paas_proj_user_login.active_client.get_alert_contacts()
        user1 = get_value_from_json(check_r, f"$.data[?(@.name=='{person1}')].id")
        user2 = get_value_from_json(check_r, f"$.data[?(@.name=='{person2}')].id")
        assert user1 and user2, "初始化工作--新建告警联系人失败"
        group_name = "test" + get_random_string(4).lower()
        users_list = [user1, user2]
        result = paas_proj_user_login.active_client.create_alert_group(
            group_name, users_list
        )
        check_status_code(result, 200)
        time.sleep(3)
        r = paas_proj_user_login.active_client.get_alert_group_list(group_name)
        group_id = get_value_from_json(r, "$..id")
        del_r = paas_proj_user_login.active_client.delete__alert_group(group_id)
        check_status_code(del_r, 200)
        time.sleep(1)
        check_resp = paas_proj_user_login.active_client.get_alert_group_list(group_name)
        assert get_value_from_json(check_resp, "$..total") == 0, "删除告警联系组失败"
