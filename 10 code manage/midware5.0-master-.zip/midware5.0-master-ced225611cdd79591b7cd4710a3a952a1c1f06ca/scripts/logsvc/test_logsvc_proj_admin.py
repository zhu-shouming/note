import pytest
import os
from resource.base.client import PAASClient
import yaml

from resource.utils.common import *

cur_path = os.path.dirname(os.path.realpath(__file__))
datafile = os.path.join(cur_path, 'data_admin.yaml')

with open(datafile, encoding='utf-8') as f:
    data = yaml.safe_load(f)


@pytest.mark.zk
@allure.feature("系统")
@allure.story("系统")
class TestZookeeper:
    @pytest.mark.L5
    @pytest.mark.Smoke
    def test_create_project(self, paas_proj_admin_login: PAASClient):
        # allure.dynamic.title(args['title'])
        with allure.step(" 设置项目名称 和描述"):
            pass
        pass
