import urllib3

from config.config import settings
from resource.utils.common import *
from resource.utils.log import logger

import base64
from Crypto.Cipher import PKCS1_v1_5 as Cipher_pksc1_v1_5
from Crypto.PublicKey import RSA

urllib3.disable_warnings()


class PAASLogin:
    """
    登录用户控制台用户类
    用户的身份信息包括：用户名，密码，登录IP和登录端口
    """

    def __init__(self, username, password, login_ip, login_port):
        self.username = username
        self.password = password
        self.login_ip = login_ip
        self.login_port = login_port
        self.ss = requests.Session()
        self.ss.trust_env = False
        self.user_id = None
        self.user_role = None
        self.default_project_id = None
        self._login()

    def _login(self):
        logger.info("登录")
        url = (
            'https://'
            + self.login_ip
            + ":"
            + self.login_port
            + '/api/sys/oapi/v1/double_factor/login'
        )

        payload = {
            "domain": "default",
            "password": self._gen_pwd(self.password),
            "rsa": True,
            "userId": "",
            "username": self.username,
        }

        login_response = self.ss.post(url, json=payload, verify=False)
        check_status_code(login_response)
        token = get_value_from_json(login_response, "$..token")
        self.ss.headers.update({"X-Auth-Token": token})
        self.user_id = get_value_from_json(login_response, "$.res.user.id")
        self.user_role = get_value_from_json(login_response, "$.res.user.role_name")
        self.default_project_id = get_value_from_json(
            login_response, "$.res.user.default_project_id"
        )

    def _gen_pwd(self, pwd):
        """
        生成加密后的登录密码

        :param pwd: 明文密码
        :return:
        """
        public_key = settings['PUBLIC_KEY']
        key = '-----BEGIN PUBLIC KEY-----\n' + public_key + '\n-----END PUBLIC KEY-----'
        rsakey = RSA.importKey(key)
        cipher = Cipher_pksc1_v1_5.new(rsakey)
        encrypt_text = cipher.encrypt(pwd.encode())
        cipher_text_tmp = base64.b64encode(encrypt_text)
        encrypt_res = cipher_text_tmp.decode()
        return encrypt_res
