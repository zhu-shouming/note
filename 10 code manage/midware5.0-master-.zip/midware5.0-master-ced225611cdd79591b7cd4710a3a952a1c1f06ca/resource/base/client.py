from resource.utils.user import PAASLogin
from scripts.apis.api_mqs import MqsAPI
from scripts.apis.api_sys import SysAPI
from scripts.es.api_es import EsAPI
from scripts.kafka.api_kafka import KafkaAPI
from scripts.zookeeper.api_zookeeper import ZooKeeperAPI
from scripts.rabbitmq.api_rabbitmq import RabbitmqAPI
from scripts.rocketmq.api_rocketmq import RocketmqAPI
from scripts.activemq.api_activemq import ActivemqAPI


class PAASClient(object):
    def __init__(self, login_info: PAASLogin):
        self.user_name = login_info.username
        self.login_info = login_info
        self.mqs_client = MqsAPI(login_info)
        self.sys_client = SysAPI(login_info)
        self.kafka_client = KafkaAPI(login_info)
        self.zk_client = ZooKeeperAPI(login_info)
        self.es_client = EsAPI(login_info)
        self.rabit_client = RabbitmqAPI(login_info)
        self.rocket_client = RocketmqAPI(login_info)
        self.active_client = ActivemqAPI(login_info)
