import re

from config.config import settings
from resource.base.client import PAASClient
from resource.utils.user import PAASLogin
from scripts.apis.handler_mqs import *


def init_env(user: PAASClient):
   pass


def teardown_env(user: PAASClient):
    teardown_delete_es(user)
    teardown_delete_kafka_connector(user)
    teardown_delete_kafka(user)
    teardown_delete_zk(user)
    teardown_delete_mq(user)

def teardown_delete_es(user: PAASClient):
    cluster_list = get_cluster_list(user, "elasticsearch")
    if len(cluster_list['data']) > 0:
        for i in range(len(cluster_list['data'])):
            cluster_name = cluster_list['data'][i]['name']
            if re.match(r"(auto)", cluster_name):
                delete_cluster(user, "elasticsearch", cluster_name)


def teardown_delete_kafka(user: PAASClient):
    cluster_list = get_cluster_list(user, "kafka")
    if len(cluster_list['data']) > 0:
        for i in range(len(cluster_list['data'])):
            cluster_name = cluster_list['data'][i]['name']
            if re.match(r"(auto)", cluster_name):
                delete_cluster(user, "kafka", cluster_name)


def teardown_delete_kafka_connector(user: PAASClient):
    cluster_list_response = user.mqs_client.get_mqs_cluster_list("kafkaconnector")
    check_status_code(cluster_list_response)
    cluster_list = cluster_list_response.json()
    if len(cluster_list['data']) > 0:
        for i in range(len(cluster_list['data'])):
            cluster_name = cluster_list['data'][i]['name']
            if re.match(r"(auto)", cluster_name):
                delete_cluster(user, "kafkaconnector", cluster_name)


def teardown_delete_zk(user: PAASClient):
    cluster_list = get_cluster_list(user, "zookeeper")
    if len(cluster_list['data']) > 0:
        for i in range(len(cluster_list['data'])):
            cluster_name = cluster_list['data'][i]['name']
            if re.match(r"(auto)", cluster_name):
                delete_cluster(user, "zookeeper", cluster_name)


def teardown_delete_mq(user: PAASClient):
    services_list=['rabbitmq', 'rocketmq', 'activemq']
    for svc in services_list:
        resp = user.mqs_client.get_bigdata_cluster(svc)
        check_status_code(resp)
        mqs= get_value_from_json(resp, "$..name", list_flag=True)
        if not mqs:
            continue
        else:
            print(mqs)
        for item in mqs:
            if item.startswith('auto'):
                user.mqs_client.delete_bigdata_cluster(svc, item)


def get_cluster_list(user: PAASClient, service_name):
    cluster_list_response = user.mqs_client.get_bigdata_cluster(service_name)
    check_status_code(cluster_list_response)
    cluster_list = cluster_list_response.json()
    return cluster_list


if __name__ == '__main__':
    user = PAASClient(
        PAASLogin(settings.PROJ_ADMIN, settings.PASSWORD, settings.HOST, settings.PORT)
    )

    teardown_env(user)
